package com.amarkeyboard.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

/** লিখতে শেখার পাতা: প্রতিটি পাতায় ব্যাখ্যা + নিচে টাইপ করে দেখার বক্স */
class TutorialActivity : Activity() {

    companion object {
        val titles: List<Pair<String, String>> = listOf(
            "প্রভাত লেআউটে লিখতে শিখুন" to "প্রভাত লেআউটের কি, কার ও যুক্তাক্ষর",
            "ফোনেটিক (অভ্র-ধাঁচ) এ লিখতে শিখুন" to "ইংরেজি হরফে বাংলা লেখা: ami → আমি",
            "কপি, পেস্ট ও ক্লিপবোর্ড" to "c, x, v কি, ✂ মোড ও ক্লিপবোর্ড",
            "টুলবক্স, ইমোজি ও চিহ্ন" to "☰ মেনুর সব সুবিধা"
        )

        // (শিরোনাম, লেখা) এর তালিকা
        private val pages: List<List<Pair<String, String>>> = listOf(
            listOf(
                "কীভাবে কাজ করে" to "প্রভাতে প্রতিটি কি একটি নির্দিষ্ট বাংলা বর্ণ বা চিহ্ন। সাধারণ চাপে বড় অক্ষরটি বসে, Shift চাপলে বা কি চেপে ধরলে কোণের ছোট অক্ষরটি বসে।",
                "কার" to "আ-কার, ই-কার, ঈ-কার, উ-কার, ঊ-কার, এ-কার, ও-কার আলাদা কি হিসেবে আছে। আগে ব্যঞ্জন লিখে তারপর কার-এর কি চাপুন।\nউদাহরণ: ক + ই-কার = কি",
                "যুক্তাক্ষর" to "ব্যঞ্জনের পরে হসন্ত কি চেপে পরের ব্যঞ্জন লিখুন।\nউদাহরণ: ক + হসন্ত + ষ = ক্ষ",
                "সংখ্যা" to "নম্বর সারিতে বাংলা সংখ্যা বসে। কি চেপে ধরলে ইংরেজি সংখ্যা বসে।",
                "চন্দ্রবিন্দু, দাঁড়ি" to "দাঁড়ি শেষ সারিতে আছে। চন্দ্রবিন্দু হসন্ত কি-র Shift-এ পাওয়া যায়।"
            ),
            listOf(
                "কীভাবে কাজ করে" to "ইংরেজি হরফে উচ্চারণ লিখুন, কিবোর্ড বাংলায় বদলে দেবে। লেখা শেষ হলে স্পেস দিন বা ওপরের সাজেশন চাপুন।",
                "উদাহরণ" to "ami → আমি\nbangla → বাংলা\nkotha → কথা\nca^d → চাঁদ\nkkhoma → ক্ষমা\ntOmar → তোমার",
                "নিয়ম" to "• ব্যঞ্জনের পরে o দিলে কিছু বসে না (kotha = কথা)।\n• বড় হাতের O = ও-কার, T D N S R = ট ড ণ ষ ড়\n• ng = অনুস্বার, Ng = ঙ, ^ = চন্দ্রবিন্দু, : = বিসর্গ\n• Z = য-ফলা, rri = ঋ\n• দুটো ব্যঞ্জন পরপর লিখলে যুক্তাক্ষর হয় (kt = ক্ত)",
                "সংখ্যা" to "ফোনেটিক মোডে নম্বর সারি বাংলা সংখ্যা দেয়। ইংরেজি সংখ্যা চাইলে কি চেপে ধরুন।"
            ),
            listOf(
                "কপি, কাট, পেস্ট" to "লেখা সিলেক্ট থাকলে কিবোর্ডে c = কপি, x = কাট, v = পেস্ট, a = সব সিলেক্ট হয়ে যায় (কিগুলোতে নাম দেখাবে)। সিলেক্ট ছাড়া পেস্ট করতে চাইলে ☰ মেনু থেকে ✂ চাপুন।",
                "ক্লিপবোর্ড" to "☰ → 📋 চাপলে কপি করা সব লেখা দেখা যায়। লেখায় চাপলে বসে যায়, 📌 চাপলে পিন হয়ে যায় (পিন করা লেখা মোছা হয় না)।",
                "অ্যাপের নিজের মেনু" to "লেখা সিলেক্ট করলে অ্যাপের নিজের মেনুতে (Cut, Copy, Paste) থেকেও কপি-কাট করা যায়। তখন কিবোর্ড \"কপি হয়েছে\" বা \"কাট হয়েছে\" জানিয়ে দেয় ও লেখাটা ক্লিপবোর্ডে জমা রাখে।",
                "অ্যাপ থেকে" to "হোমের ক্লিপবোর্ড বাটনে পুরো তালিকা দেখা, পিন করা, মোছা আর নিজে লেখা যোগ করা যায়।",
                "গোপনীয়তা" to "পাসওয়ার্ড ঘরে কিছুই জমানো হয় না। সেটিংসে ক্লিপবোর্ড জমানো বন্ধ করা বা ইনকগনিটো চালু করা যায়।"
            ),
            listOf(
                "☰ মেনু" to "কিবোর্ডের বাঁ-ওপরের ☰ চাপলে আইকনের সারি খোলে: ইমোজি, ক্লিপবোর্ড, টুলবক্স, চিহ্ন, ✂ কপি-পেস্ট মোড, ইনকগনিটো, ?123, এক হাতে ব্যবহার ও সেটিংস।",
                "টুলবক্স 🧰" to "সম্পাদনা (কার্সর, শব্দ সিলেক্ট বা মোছা), ক্যালকুলেটর, বড়-ছোট হাতের অক্ষর, শব্দ গণনা, তারিখ-সময়, পাসওয়ার্ড জেনারেটর ও স্নিপেট।",
                "ক্যালকুলেটর সাজেশন" to "250+350 লিখলে সাজেশন বারে \"= 600\" আসে, চাপলে উত্তর বসে।",
                "স্নিপেট" to "সেটিংস → টুলবক্স ও গোপনীয়তা থেকে শর্টকাট যোগ করুন। শর্টকাট লিখে স্পেস দিলে পুরো লেখা বসে যায়।",
                "স্পেসবার" to "স্পেসবারে বাঁয়ে বা ডানে সোয়াইপ করলে লেআউট (ভাষা) বদলায়। স্পেসবার চেপে ধরে (প্রায় ১ সেকেন্ড) তারপর টানলে কার্সর সরে।"
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        val idx = intent.getIntExtra("page", 0).coerceIn(0, pages.size - 1)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        root.addView(Ui.appBar(this, titles[idx].first))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 24))

        for ((h, body) in pages[idx]) {
            val c = Ui.card(this)
            c.addView(Ui.text(this, h, 16f, Ui.primary, true))
            val t = Ui.text(this, body, 15f, Ui.ink)
            t.setPadding(0, Ui.dp(this, 6), 0, 0)
            t.setLineSpacing(0f, 1.15f)
            c.addView(t)
            col.addView(c, Ui.cardParams(this))
        }

        val tryCard = Ui.card(this)
        tryCard.addView(Ui.text(this, "নিজে করে দেখুন", 16f, Ui.primary, true))
        val et = EditText(this)
        et.hint = "এখানে লিখুন..."
        et.minLines = 3
        et.gravity = Gravity.TOP
        tryCard.addView(et)
        col.addView(tryCard, Ui.cardParams(this))

        val sv = ScrollView(this)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
    }
}

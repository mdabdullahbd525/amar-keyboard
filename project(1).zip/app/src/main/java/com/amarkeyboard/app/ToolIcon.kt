package com.amarkeyboard.app

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable

/**
 * টুলবারের আইকন: সব একই ধরনের সরু রেখার (আউটলাইন) আইকন, ২৪×২৪ গ্রিডে আঁকা।
 * ইমোজির বদলে এগুলো ব্যবহার হয়, তাই সব থিমে রঙ মানিয়ে যায় আর দেখতে সমান ও পরিচ্ছন্ন।
 */
class ToolIcon(private val kind: String, private val color: Int) : Drawable() {

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()).toFloat()
        if (s <= 0f) return
        val u = s / 24f
        line.strokeWidth = u * 1.9f
        line.color = color
        fill.color = color
        txt.color = color

        c.save()
        c.translate(b.exactCenterX() - 12f * u, b.exactCenterY() - 12f * u)
        when (kind) {
            "menu" -> {
                c.drawLine(4 * u, 6 * u, 20 * u, 6 * u, line)
                c.drawLine(4 * u, 12 * u, 20 * u, 12 * u, line)
                c.drawLine(4 * u, 18 * u, 20 * u, 18 * u, line)
            }
            "close" -> {
                c.drawLine(6 * u, 6 * u, 18 * u, 18 * u, line)
                c.drawLine(18 * u, 6 * u, 6 * u, 18 * u, line)
            }
            "emoji" -> {
                c.drawCircle(12 * u, 12 * u, 9 * u, line)
                c.drawCircle(9 * u, 10 * u, 1.2f * u, fill)
                c.drawCircle(15 * u, 10 * u, 1.2f * u, fill)
                c.drawArc(RectF(7 * u, 7.5f * u, 17 * u, 17 * u), 25f, 130f, false, line)
            }
            "clip" -> {
                c.drawRoundRect(RectF(5 * u, 5 * u, 19 * u, 21 * u), 2.2f * u, 2.2f * u, line)
                c.drawRoundRect(RectF(9 * u, 2.5f * u, 15 * u, 7 * u), 1.6f * u, 1.6f * u, fill)
                c.drawLine(8.5f * u, 12 * u, 15.5f * u, 12 * u, line)
                c.drawLine(8.5f * u, 16 * u, 13.5f * u, 16 * u, line)
            }
            "edit" -> {
                // টেক্সট কার্সর (I) আর দুই পাশে তীর
                c.drawLine(12 * u, 5 * u, 12 * u, 19 * u, line)
                c.drawLine(9.5f * u, 5 * u, 14.5f * u, 5 * u, line)
                c.drawLine(9.5f * u, 19 * u, 14.5f * u, 19 * u, line)
                val l = Path()
                l.moveTo(7 * u, 9 * u); l.lineTo(3.5f * u, 12 * u); l.lineTo(7 * u, 15 * u)
                c.drawPath(l, line)
                val r = Path()
                r.moveTo(17 * u, 9 * u); r.lineTo(20.5f * u, 12 * u); r.lineTo(17 * u, 15 * u)
                c.drawPath(r, line)
            }
            "tools" -> {
                c.drawRoundRect(RectF(3 * u, 8 * u, 21 * u, 20 * u), 2.2f * u, 2.2f * u, line)
                val h = Path()
                h.moveTo(9 * u, 8 * u); h.lineTo(9 * u, 5 * u); h.lineTo(15 * u, 5 * u); h.lineTo(15 * u, 8 * u)
                c.drawPath(h, line)
                c.drawLine(3 * u, 13.5f * u, 21 * u, 13.5f * u, line)
            }
            "copy" -> {
                c.drawRoundRect(RectF(8.5f * u, 8.5f * u, 20 * u, 21 * u), 2 * u, 2 * u, line)
                val back = Path()
                back.moveTo(5.5f * u, 15.5f * u)
                back.lineTo(5.5f * u, 5 * u)
                back.quadTo(5.5f * u, 3.5f * u, 7 * u, 3.5f * u)
                back.lineTo(15 * u, 3.5f * u)
                c.drawPath(back, line)
            }
            "glasses" -> {
                c.drawCircle(7 * u, 15.5f * u, 3.6f * u, line)
                c.drawCircle(17 * u, 15.5f * u, 3.6f * u, line)
                c.drawLine(10.6f * u, 15 * u, 13.4f * u, 15 * u, line)
                c.drawLine(3.5f * u, 10.5f * u, 20.5f * u, 10.5f * u, line)
                val h = Path()
                h.moveTo(6.5f * u, 10.5f * u); h.lineTo(9 * u, 4.5f * u); h.lineTo(15 * u, 4.5f * u); h.lineTo(17.5f * u, 10.5f * u)
                c.drawPath(h, line)
            }
            "onehand" -> {
                c.drawRoundRect(RectF(6.5f * u, 2.5f * u, 17.5f * u, 21.5f * u), 2.4f * u, 2.4f * u, line)
                c.drawLine(9.5f * u, 15 * u, 14.5f * u, 15 * u, line)
                val a = Path()
                a.moveTo(12.5f * u, 12.5f * u); a.lineTo(15 * u, 15 * u); a.lineTo(12.5f * u, 17.5f * u)
                c.drawPath(a, line)
            }
            "keyboard" -> {
                c.drawRoundRect(RectF(2 * u, 6 * u, 22 * u, 18 * u), 2.4f * u, 2.4f * u, line)
                for (i in 0 until 4) c.drawCircle((6.5f + i * 3.6f) * u, 10 * u, 0.9f * u, fill)
                for (i in 0 until 3) c.drawCircle((8.3f + i * 3.6f) * u, 13.3f * u, 0.9f * u, fill)
                c.drawLine(8 * u, 16 * u, 16 * u, 16 * u, line)
            }
            "gear" -> {
                c.drawCircle(12 * u, 12 * u, 3.4f * u, line)
                c.drawCircle(12 * u, 12 * u, 7 * u, line)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val x1 = (12 + 7 * Math.cos(a)).toFloat() * u
                    val y1 = (12 + 7 * Math.sin(a)).toFloat() * u
                    val x2 = (12 + 9.8 * Math.cos(a)).toFloat() * u
                    val y2 = (12 + 9.8 * Math.sin(a)).toFloat() * u
                    c.drawLine(x1, y1, x2, y2, line)
                }
            }
            "123", "abc", "omega" -> {
                c.drawRoundRect(RectF(2 * u, 5 * u, 22 * u, 19 * u), 3.2f * u, 3.2f * u, line)
                val label = when (kind) {
                    "123" -> "123"
                    "abc" -> "ABC"
                    else -> "Ω"
                }
                txt.textSize = if (kind == "omega") 11f * u else 8f * u
                c.drawText(label, 12 * u, if (kind == "omega") 15.8f * u else 15f * u, txt)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

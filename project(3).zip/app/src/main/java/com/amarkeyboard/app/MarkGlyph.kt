package com.amarkeyboard.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/**
 * একা পড়ে থাকা বাংলা কার/চিহ্ন (ি ু ো ঁ ...) কোনো গোল (◌) ছাড়া আঁকার জন্য।
 *
 * কেন দরকার: ফোনের টেক্সট ইঞ্জিন (HarfBuzz) ব্যঞ্জন ছাড়া কার পেলে নিজে থেকে একটা ফাঁকা গোল বসিয়ে দেয়।
 * রঙের স্প্যান দিয়ে ব্যঞ্জন লুকানোও কাজ করে না, কারণ স্প্যান টেক্সটকে ভেঙে আলাদা অংশে সাজায়।
 *
 * সমাধান: "ক" + কার একসাথে একটা বিটম্যাপে আঁকা হয় (তাই কারটা সঠিক আকারেই বসে), তারপর শুধু "ক"-এর
 * আঁকা অংশটা মুছে ফেলা হয়। বাকি থাকে শুধু কারের আসল আকার, ফোনের নিজের ফন্টে, কোনো গোল ছাড়া।
 */
object MarkGlyph {
    private val cache = HashMap<String, Bitmap?>()

    fun get(mark: String, sizePx: Float, color: Int): Bitmap? {
        val key = mark + "|" + sizePx.toInt() + "|" + color
        if (cache.containsKey(key)) return cache[key]
        val bmp = try {
            render(mark, sizePx, color)
        } catch (e: Throwable) {
            null
        }
        cache[key] = bmp
        return bmp
    }

    private fun alphaOf(text: String, size: Float, w: Int, h: Int, x: Float, y: Float): IntArray {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = size
        p.color = -1 // সাদা
        c.drawText(text, x, y, p)
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        for (i in px.indices) px[i] = px[i] ushr 24
        return px
    }

    private fun render(mark: String, size: Float, color: Int): Bitmap? {
        val w = (size * 3.4f).toInt()
        val h = (size * 2.8f).toInt()
        val x0 = size * 0.9f
        val y0 = size * 1.75f

        val a = alphaOf("ক" + mark, size, w, h, x0, y0)
        val base = alphaOf("ক", size, w, h, x0, y0)

        // "ক" একা আঁকলে কোথায় পড়ে, আর কার-সহ আঁকলে সেটা কতটা সরে যায় (ি ে ো-র আগে বসে, তাই সরে) তা খুঁজে বের করা
        val bx = ArrayList<Int>()
        val by = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) {
            if (base[y * w + x] > 90) {
                bx.add(x)
                by.add(y)
            }
        }
        if (bx.isEmpty()) return null
        val range = (size * 1.3f).toInt()
        var bestDx = 0
        var bestScore = -1
        for (dx in -range..range) {
            var score = 0
            for (i in bx.indices) {
                val x = bx[i] + dx
                if (x in 0 until w && a[by[i] * w + x] > 90) score++
            }
            if (score > bestScore) {
                bestScore = score
                bestDx = dx
            }
        }

        // ব্যঞ্জনের আঁকা অংশ (সামান্য মোটা করে) মুছে ফেলা
        val r = maxOf(1, (size / 40f).toInt())
        for (i in bx.indices) {
            val cx = bx[i] + bestDx
            val cy = by[i]
            for (dy in -r..r) for (dx in -r..r) {
                val x = cx + dx
                val y = cy + dy
                if (x in 0 until w && y in 0 until h) a[y * w + x] = 0
            }
        }

        // আড়াআড়ি টাইট কাটা, লম্বালম্বি একটা নির্দিষ্ট ব্যান্ডে রাখা (যাতে নিচের কার নিচে, ওপরের কার ওপরে থাকে)
        var minX = w
        var maxX = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (a[y * w + x] > 24) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
            }
        }
        if (maxX < 0) return null
        val top = maxOf(0, (y0 - size * 1.15f).toInt())
        val bottom = minOf(h, (y0 + size * 0.55f).toInt())
        val bw = maxX - minX + 1
        val bh = bottom - top
        if (bw <= 0 || bh <= 0) return null

        val out = IntArray(bw * bh)
        val rgb = color and 0x00FFFFFF
        for (y in 0 until bh) for (x in 0 until bw) {
            val al = a[(y + top) * w + (x + minX)]
            out[y * bw + x] = (al shl 24) or rgb
        }
        val res = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, bw, 0, 0, bw, bh)
        return res
    }
}

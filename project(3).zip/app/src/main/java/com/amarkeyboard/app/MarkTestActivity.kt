package com.amarkeyboard.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** বাংলা কার-চিহ্ন পরীক্ষা: প্রতিটি চিহ্ন কিবোর্ডের পদ্ধতিতে (বাঁয়ে) আর ফোনের সাধারণ টেক্সটে (ডানে) দেখায় */
class MarkTestActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        root.addView(Ui.appBar(this, "কার-চিহ্ন পরীক্ষা"))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 24))

        val info = Ui.card(this)
        info.addView(Ui.text(this, "বাঁ কলাম: কিবোর্ড যেভাবে দেখায় (গোল ছাড়া হওয়ার কথা)।\nডান কলাম: ফোনের সাধারণ টেক্সট (এখানে গোল আসতে পারে)।\nনিচের ঘরে ডান পাশ থেকে একটা স্ক্রিনশট নিয়ে পাঠালে আমি মিলিয়ে দেখতে পারব।", 13f, Ui.sub))
        col.addView(info, Ui.cardParams(this))

        val card = Ui.card(this)
        val names = listOf(
            "ূ" to "ঊ-কার", "ু" to "উ-কার", "ি" to "ই-কার", "ী" to "ঈ-কার",
            "ে" to "এ-কার", "ৈ" to "ঐ-কার", "ো" to "ও-কার", "ৌ" to "ঔ-কার",
            "া" to "আ-কার", "ৃ" to "ঋ-কার", "্" to "হসন্ত", "ঁ" to "চন্দ্রবিন্দু",
            "ং" to "অনুস্বার", "ঃ" to "বিসর্গ"
        )
        for ((m, n) in names) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6))

            val bmp = MarkGlyph.get(m, Ui.dp(this, 1) * 36f, Ui.ink)
            val left = LinearLayout(this)
            left.gravity = Gravity.CENTER
            if (bmp != null) {
                val iv = ImageView(this)
                iv.setImageBitmap(bmp)
                left.addView(iv)
            } else {
                left.addView(Ui.text(this, "(ছবি হয়নি)", 12f, Ui.sub))
            }
            row.addView(left, LinearLayout.LayoutParams(0, Ui.dp(this, 64), 1f))

            val mid = Ui.text(this, n, 14f, Ui.ink)
            mid.gravity = Gravity.CENTER
            row.addView(mid, LinearLayout.LayoutParams(0, Ui.WRAP, 1.3f))

            val raw: TextView = Ui.text(this, m, 36f, Ui.ink)
            raw.gravity = Gravity.CENTER
            row.addView(raw, LinearLayout.LayoutParams(0, Ui.dp(this, 64), 1f))
            card.addView(row)
        }
        col.addView(card, Ui.cardParams(this))

        val sv = ScrollView(this)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
    }
}

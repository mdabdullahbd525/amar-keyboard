package com.amarkeyboard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** প্রথমবারের সেটআপ: ১) চালু করুন ২) বেছে নিন ৩) লেআউট ৪) শেষ */
class SetupActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var step = 1
    private val bn = arrayOf("১", "২", "৩", "৪")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.bg
        step = savedInstanceState?.getInt("step", 1) ?: 1
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("step", step)
    }

    private fun build() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, Ui.dp(this, 20), 0, Ui.dp(this, 28))

        val head = Ui.text(this, "SmartBorno সেট আপ হচ্ছে", 26f, Ui.ink, true)
        head.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 14))
        col.addView(head)

        val ind = LinearLayout(this)
        ind.orientation = LinearLayout.HORIZONTAL
        for (i in 1..4) {
            val t = Ui.text(this, bn[i - 1], 20f, if (i == step) Ui.primary else Ui.sub, i == step)
            t.gravity = Gravity.CENTER
            t.setPadding(0, 0, 0, Ui.dp(this, 6))
            if (i == step) t.background = Ui.round(this, Color.TRANSPARENT, 0)
            ind.addView(t, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
        col.addView(ind)

        val card = Ui.card(this)
        when (step) {
            1 -> step1(card)
            2 -> step2(card)
            3 -> step3(card)
            else -> step4(card)
        }
        col.addView(card, Ui.cardParams(this))

        // গোপনীয়তার আশ্বাস (সত্যি: অ্যাপে কোনো ইন্টারনেট পারমিশন নেই)
        val priv = LinearLayout(this)
        priv.orientation = LinearLayout.HORIZONTAL
        priv.setPadding(Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 20), 0)
        priv.addView(Ui.text(this, "🛡", 40f), LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.WRAP))
        val pt = LinearLayout(this)
        pt.orientation = LinearLayout.VERTICAL
        pt.addView(Ui.text(this, "আপনার ডেটা নিরাপদ", 20f, Ui.ok, true))
        pt.addView(Ui.text(this, "SmartBorno-তে ইন্টারনেট পারমিশনই নেই, তাই আপনার লেখা ফোনের বাইরে যায় না। পাসওয়ার্ড ঘরে কিছুই জমানো হয় না।", 14f, Ui.sub))
        priv.addView(pt, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        col.addView(priv)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.bg)
        sv.addView(col)
        setContentView(sv)
    }

    private fun status(ok: Boolean, yes: String, no: String): TextView {
        val t = Ui.text(this, if (ok) "✓ $yes" else "✗ $no", 14f, if (ok) Ui.ok else Color.parseColor("#C62828"), true)
        t.setPadding(0, Ui.dp(this, 10), 0, 0)
        return t
    }

    private fun nav(card: LinearLayout, canNext: Boolean, nextLabel: String = "পরবর্তী ধাপ") {
        val lp = Ui.buttonParams(this)
        card.addView(Ui.button(this, if (canNext) nextLabel else "এড়িয়ে পরের ধাপে যান", canNext) {
            step++
            build()
        }, lp)
        if (step > 1) {
            card.addView(Ui.button(this, "পেছনে", false) {
                step--
                build()
            }, Ui.buttonParams(this))
        }
    }

    private fun step1(card: LinearLayout) {
        card.addView(Ui.text(this, "SmartBorno অন করুন", 18f, Ui.ink, true))
        val d = Ui.text(this, "ফোনের কিবোর্ড তালিকায় SmartBorno চালু (অন) করতে হবে। নিচের বাটনে চেপে তালিকায় \"SmartBorno\" অন করুন।", 15f, Ui.sub)
        d.setPadding(0, Ui.dp(this, 8), 0, 0)
        card.addView(d)
        val ok = Ui.kbEnabled(this)
        card.addView(status(ok, "চালু আছে", "এখনো চালু হয়নি"))
        card.addView(Ui.button(this, "কিবোর্ড চালু করুন", !ok) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, Ui.buttonParams(this))
        nav(card, ok)
    }

    private fun step2(card: LinearLayout) {
        card.addView(Ui.text(this, "SmartBorno-তে সুইচ করুন", 18f, Ui.ink, true))
        val d = Ui.text(this, "এখন নিচের বাটনে চেপে কিবোর্ডের তালিকা থেকে \"SmartBorno\" বেছে নিন।", 15f, Ui.sub)
        d.setPadding(0, Ui.dp(this, 8), 0, 0)
        card.addView(d)
        val ok = Ui.kbSelected(this)
        card.addView(status(ok, "SmartBorno এখন চালু কিবোর্ড", "এখনো বেছে নেওয়া হয়নি"))
        card.addView(Ui.button(this, "কিবোর্ড বেছে নিন", !ok) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, Ui.buttonParams(this))
        nav(card, ok)
    }

    private fun step3(card: LinearLayout) {
        card.addView(Ui.text(this, "লেখার পদ্ধতি পছন্দ করুন", 18f, Ui.ink, true))
        val d = Ui.text(this, "সর্বোচ্চ তিনটি লেআউট বেছে নিন। কিবোর্ডের 🌐 কি চেপে এগুলোর মধ্যে বদলানো যায়। পরেও অ্যাপের হোম থেকে বদলাতে পারবেন।", 15f, Ui.sub)
        d.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 6))
        card.addView(d)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        Ui.fillLayoutToggles(this, prefs, box) { }
        card.addView(box)
        nav(card, true)
    }

    private fun step4(card: LinearLayout) {
        card.addView(Ui.text(this, "অভিনন্দন, আপনি পুরোপুরি প্রস্তুত!", 18f, Ui.ink, true))
        val d = Ui.text(this, "এখন যেকোনো অ্যাপে SmartBorno দিয়ে লিখতে পারবেন। তার আগে চাইলে নম্বর সারি, কিবোর্ডের উচ্চতা ইত্যাদি ঠিকঠাক করে নিন।", 15f, Ui.sub)
        d.setPadding(0, Ui.dp(this, 8), 0, 0)
        card.addView(d)
        card.addView(Ui.button(this, "সেটিংস ঠিকঠাক করুন", false) {
            val i = Intent(this, SettingsPageActivity::class.java)
            i.putExtra("page", 1)
            startActivity(i)
        }, Ui.buttonParams(this))
        card.addView(Ui.button(this, "শেষ করুন") {
            prefs.edit().putBoolean("setupDone", true).apply()
            finish()
        }, Ui.buttonParams(this))
        card.addView(Ui.button(this, "পেছনে", false) {
            step--
            build()
        }, Ui.buttonParams(this))
    }
}

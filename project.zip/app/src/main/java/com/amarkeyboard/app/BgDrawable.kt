package com.amarkeyboard.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/** ব্যাকগ্রাউন্ড ছবি: কিবোর্ডের মাপে মাঝখান থেকে কেটে বসায়, ওপরে হালকা কালো পর্দা দেয় */
class BgDrawable(private val bmp: Bitmap, dimAlpha: Int) : Drawable() {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dimPaint = Paint().apply { color = Color.argb(dimAlpha, 0, 0, 0) }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val scale = maxOf(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val w = bmp.width * scale
        val h = bmp.height * scale
        val left = b.left + (b.width() - w) / 2f
        val top = b.top + (b.height() - h) / 2f
        val save = canvas.save()
        canvas.clipRect(b)
        canvas.drawBitmap(bmp, null, RectF(left, top, left + w, top + h), paint)
        canvas.drawRect(b, dimPaint)
        canvas.restoreToCount(save)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

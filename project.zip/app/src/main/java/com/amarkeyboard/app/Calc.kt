package com.amarkeyboard.app

import java.math.BigDecimal
import java.math.RoundingMode

/** ছোট নিরাপদ ক্যালকুলেটর: + - * / ( ) আর শতাংশ (%) বোঝে। কোনো eval ব্যবহার করা হয়নি। */
object Calc {
    private class Parser(val s: String) {
        var i = 0

        fun parse(): Double? = try {
            val v = expr()
            if (i != s.length) null else v
        } catch (e: Exception) {
            null
        }

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (peek() == '*' || peek() == '/') {
                val op = s[i++]
                val r = factor()
                if (op == '/' && r == 0.0) throw ArithmeticException("div0")
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            var neg = false
            if (peek() == '-') { neg = true; i++ } else if (peek() == '+') i++
            var v = primary()
            while (peek() == '%') { v /= 100.0; i++ }
            return if (neg) -v else v
        }

        private fun primary(): Double {
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("paren")
                i++
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("num")
            return s.substring(start, i).toDouble()
        }
    }

    fun eval(expr: String): Double? {
        val clean = expr.replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "")
        if (clean.isEmpty()) return null
        return Parser(clean).parse()
    }

    fun format(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "ভুল"
        val bd = BigDecimal(d).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros()
        return bd.toPlainString()
    }
}

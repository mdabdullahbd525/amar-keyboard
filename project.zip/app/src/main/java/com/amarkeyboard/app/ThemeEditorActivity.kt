package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** নতুন থিম: লাইভ প্রিভিউ, রঙের প্রিসেট, ব্যাকগ্রাউন্ড · বাটন · সাজেশন · ফাংশনাল বাটন */
class ThemeEditorActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var sv: ScrollView? = null
    private var tab = 0
    private val pickCode = 202

    private val palette = listOf(
        "#FFFFFF", "#FFFBE6", "#FFF3E0", "#FDE7E7", "#F5F7FA", "#D5D9E3", "#8A8F99", "#1B1B1F", "#000000",
        "#B71C1C", "#F44336", "#E91E63", "#4A148C", "#7B1FA2", "#3F51B5", "#1A237E",
        "#0D47A1", "#2196F3", "#03A9F4", "#00BCD4", "#004D40", "#009688", "#2E7D32", "#8BC34A",
        "#FFEB3B", "#FF9800", "#E65100"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        tab = savedInstanceState?.getInt("tab", 0) ?: 0
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    private fun themeNow(): KbTheme = Themes.byId(prefs.getString("theme", Themes.DEFAULT_ID) ?: Themes.DEFAULT_ID)

    private fun render() {
        val keepY = sv?.scrollY ?: 0
        val bmp = BgImage.load(this)
        val st = KeyStyle.resolve(prefs, themeNow(), bmp != null)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        val save = Ui.text(this, "সেভ করুন", 15f, Ui.primary, true)
        save.setOnClickListener { askName() }
        root.addView(Ui.appBar(this, "নতুন থিম", save))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 28))

        col.addView(Ui.miniKeyboard(this, st, bmp, prefs.getInt("bgDim", 35), true))

        // রঙের প্রিসেট: বেছে নিলে ওই থিম থেকে শুরু হয়
        col.addView(heading("রঙের প্রিসেট"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val pr = LinearLayout(this)
        pr.orientation = LinearLayout.HORIZONTAL
        for (t in Themes.all) {
            val pv = Ui.miniKeyboard(this, KeyStyle.forTheme(t), null, 0, false)
            pv.setOnClickListener {
                val e = prefs.edit()
                KeyStyle.clearPrefs(e)
                e.putString("theme", t.id)
                e.apply()
                render()
            }
            val lp = LinearLayout.LayoutParams(Ui.dp(this, 110), Ui.WRAP)
            lp.rightMargin = Ui.dp(this, 8)
            pr.addView(pv, lp)
        }
        hs.addView(pr)
        col.addView(hs)

        // ট্যাব
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(0, Ui.dp(this, 14), 0, 0)
        listOf("ব্যাকগ্রাউন্ড", "বাটন", "সাজেশন", "ফাংশনাল").forEachIndexed { i, n ->
            val t = Ui.text(this, n, 14f, if (i == tab) Ui.primary else Ui.sub, i == tab)
            t.gravity = Gravity.CENTER
            t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10))
            if (i == tab) t.background = Ui.round(this, Ui.chipBg, 12)
            t.setOnClickListener {
                tab = i
                render()
            }
            tabs.addView(t, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
        col.addView(tabs)

        val card = Ui.card(this)
        when (tab) {
            0 -> {
                card.addView(paletteRow("ব্যাকগ্রাউন্ড রঙ (ছবি না থাকলে)", "ckBg"))
                card.addView(heading("গ্যালারি থেকে সেট করুন"))
                card.addView(Ui.button(this, "গ্যালারি থেকে ছবি বাছুন", false) { pickImage() })
                if (bmp != null) {
                    card.addView(Ui.button(this, "ছবি সরান", false) {
                        BgImage.remove(this)
                        render()
                    }, Ui.buttonParams(this))
                    card.addView(sliderRow("ব্যাকগ্রাউন্ড অন্ধকার ভাব", "bgDim", 0, 80, 35, false))
                }
            }
            1 -> {
                val sw = Ui.switchView(this, prefs.getBoolean("keyBg", true)) { on ->
                    prefs.edit().putBoolean("keyBg", on).apply()
                    render()
                }
                card.addView(Ui.row(this, "কী ব্যাকগ্রাউন্ড", "বন্ধ করলে কিগুলোর বাক্স থাকে না, শুধু অক্ষর দেখায়", sw, null))
                card.addView(paletteRow("বাটন ব্যাকগ্রাউন্ড", "ckKey"))
                card.addView(paletteRow("কী লেখার রঙ", "ckText"))
                card.addView(paletteRow("কী হিন্ট রঙ", "ckHint"))
                card.addView(sliderRow("বাটন স্বচ্ছতা", "keyAlpha", 10, 100, 100, true))
            }
            2 -> {
                card.addView(paletteRow("সাজেশন বার ব্যাকগ্রাউন্ড", "ckSug"))
                card.addView(paletteRow("সাজেশন বার লেখার রঙ", "ckSugText"))
                card.addView(sliderRow("সাজেশন বার স্বচ্ছতা", "sugAlpha", 0, 100, 100, true))
            }
            else -> {
                card.addView(paletteRow("ফাংশনাল বাটন ব্যাকগ্রাউন্ড", "ckSpecial"))
                card.addView(paletteRow("ফাংশনাল বাটন লেখার রঙ", "ckSpText"))
                card.addView(paletteRow("এন্টার বাটনের রঙ", "ckEnter"))
                card.addView(sliderRow("ফাংশনাল বাটন স্বচ্ছতা", "fnAlpha", 10, 100, 100, true))
            }
        }
        val lp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        lp.topMargin = Ui.dp(this, 10)
        col.addView(card, lp)

        val reset = Ui.text(this, "সব রঙ ডিফল্টে ফেরান", 14f, Color.parseColor("#B71C1C"), true)
        reset.gravity = Gravity.CENTER
        reset.setPadding(0, Ui.dp(this, 22), 0, Ui.dp(this, 6))
        reset.setOnClickListener {
            val e = prefs.edit()
            KeyStyle.clearPrefs(e)
            e.apply()
            Ui.toast(this, "রঙ ডিফল্টে ফিরেছে")
            render()
        }
        col.addView(reset)

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        root.addView(s, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun heading(t: String): TextView {
        val h = Ui.text(this, t, 15f, Ui.ink, true)
        h.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 8))
        return h
    }

    private fun circle(color: Int, label: String, selected: Boolean, onClick: () -> Unit): View {
        val t = Ui.text(this, label, 16f, KeyStyle.contrast(color), true)
        t.gravity = Gravity.CENTER
        t.background = Ui.oval(this, color, if (selected) Ui.primary else Color.parseColor("#C5CEDC"), if (selected) 3 else 1)
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40))
        lp.rightMargin = Ui.dp(this, 8)
        val w = LinearLayout(this)
        w.addView(t, lp)
        return w
    }

    private fun paletteRow(title: String, key: String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(heading(title))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cur: Int? = if (prefs.contains(key)) prefs.getInt(key, 0) else null
        row.addView(circle(Color.WHITE, "⟲", cur == null) {
            prefs.edit().remove(key).apply()
            render()
        })
        for (hex in palette) {
            val c = Color.parseColor(hex)
            row.addView(circle(c, if (cur == c) "✓" else "", cur == c) {
                prefs.edit().putInt(key, c).apply()
                render()
            })
        }
        hs.addView(row)
        box.addView(hs)
        return box
    }

    /** স্লাইডার: কিছু স্লাইডারে "স্বয়ংক্রিয়" (ডিফল্ট) অবস্থা থাকে */
    private fun sliderRow(title: String, key: String, min: Int, max: Int, def: Int, hasAuto: Boolean): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(0, Ui.dp(this, 14), 0, 0)
        head.addView(Ui.text(this, title, 15f, Ui.ink, true), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val has = prefs.contains(key)
        val cur = if (has) prefs.getInt(key, def) else def
        val value = Ui.text(this, if (!has && hasAuto) "স্বয়ংক্রিয়" else "$cur%", 14f, Ui.primary, true)
        head.addView(value)
        box.addView(head)
        val sb = SeekBar(this)
        sb.max = (max - min) / 5
        sb.progress = ((cur - min) / 5).coerceIn(0, sb.max)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val v = min + p * 5
                    value.text = "$v%"
                    prefs.edit().putInt(key, v).apply()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                render()
            }
        })
        box.addView(sb)
        if (hasAuto && has) {
            val r = Ui.text(this, "স্বয়ংক্রিয় করুন", 13f, Ui.primary, true)
            r.setPadding(0, Ui.dp(this, 4), 0, 0)
            r.setOnClickListener {
                prefs.edit().remove(key).apply()
                render()
            }
            box.addView(r)
        }
        return box
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "ছবি বাছুন"), pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == pickCode && resultCode == RESULT_OK && uri != null) {
            if (BgImage.save(this, uri)) render()
            else Ui.toast(this, "ছবিটা নেওয়া গেল না, অন্য ছবি চেষ্টা করুন")
        }
    }

    private fun askName() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 4))
        box.addView(Ui.text(this, "আপনার থিমের একটি নাম দিন", 14f, Ui.sub))
        val et = EditText(this)
        et.hint = "থিমের নাম"
        box.addView(et)
        AlertDialog.Builder(this)
            .setTitle("থিম সেভ করুন")
            .setView(box)
            .setPositiveButton("সেভ করুন") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    Ui.toast(this, "নাম লিখুন")
                } else {
                    MyThemes.saveCurrent(prefs, n)
                    Ui.toast(this, "থিম সেভ ও প্রয়োগ করা হয়েছে")
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}

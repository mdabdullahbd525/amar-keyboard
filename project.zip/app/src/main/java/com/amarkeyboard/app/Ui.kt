package com.amarkeyboard.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** পুরো অ্যাপের একই ডিজাইন: রঙ, কার্ড, বাটন, অ্যাপবার, সুইচ */
object Ui {
    val primary = Color.parseColor("#0B5ED7")
    val primaryDark = Color.parseColor("#062B7A")
    val cyan = Color.parseColor("#19C8FF")
    val bg = Color.parseColor("#F3F7FD")
    val ink = Color.parseColor("#12203A")
    val sub = Color.parseColor("#5B6B85")
    val line = Color.parseColor("#E3EAF5")
    val ok = Color.parseColor("#1BA672")
    val chipBg = Color.parseColor("#E6EEFB")

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

    fun round(c: Context, color: Int, r: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(c, r).toFloat()
        g.setColor(color)
        if (stroke != 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun oval(c: Context, color: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        if (stroke != 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun headerGradient(c: Context): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(primaryDark, primary, cyan))
        val r = dp(c, 28).toFloat()
        g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        return g
    }

    fun text(c: Context, t: String, size: Float, color: Int = ink, bold: Boolean = false): TextView {
        val tv = TextView(c)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        tv.setLineSpacing(0f, 1.12f)
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        return tv
    }

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = round(c, Color.WHITE, 16)
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        l.elevation = dp(c, 2).toFloat()
        return l
    }

    fun cardParams(c: Context): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
        return lp
    }

    fun divider(c: Context): View {
        val v = View(c)
        v.setBackgroundColor(line)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, dp(c, 1))
        return v
    }

    fun button(c: Context, label: String, filled: Boolean = true, onClick: () -> Unit): TextView {
        val b = text(c, label, 15f, if (filled) Color.WHITE else primary, true)
        b.gravity = Gravity.CENTER
        b.background = if (filled) round(c, primary, 24) else round(c, Color.WHITE, 24, primary, 1)
        b.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12))
        b.setOnClickListener { onClick() }
        return b
    }

    fun buttonParams(c: Context): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(c, 12)
        return lp
    }

    fun appBar(a: Activity, title: String, right: View? = null): LinearLayout {
        val bar = LinearLayout(a)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.WHITE)
        bar.setPadding(dp(a, 4), dp(a, 4), dp(a, 14), dp(a, 4))
        bar.elevation = dp(a, 3).toFloat()
        val back = text(a, "←", 24f, ink)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { a.finish() }
        bar.addView(back, LinearLayout.LayoutParams(dp(a, 48), dp(a, 48)))
        bar.addView(text(a, title, 19f, ink, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (right != null) bar.addView(right)
        return bar
    }

    fun switchView(c: Context, on: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(c)
        s.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(states, intArrayOf(primary, Color.parseColor("#9AA7BD")))
        s.trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#9CC4FF"), Color.parseColor("#D5DCE8")))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        return s
    }

    /** শিরোনাম + ছোট বর্ণনা (বাঁয়ে) এবং ডানে ঐচ্ছিক ভিউ (সুইচ, তীর ইত্যাদি) */
    fun row(c: Context, title: String, desc: String?, trailing: View?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(c, 16), dp(c, 13), dp(c, 16), dp(c, 13))
        val t = LinearLayout(c)
        t.orientation = LinearLayout.VERTICAL
        t.addView(text(c, title, 16f, ink))
        if (!desc.isNullOrEmpty()) {
            val d = text(c, desc, 13f, sub)
            d.setPadding(0, dp(c, 2), 0, 0)
            t.addView(d)
        }
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) r.addView(trailing)
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    fun chevron(c: Context): TextView = text(c, "›", 24f, sub)

    fun sheet(a: Activity, content: View): Dialog {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val wrap = LinearLayout(a)
        wrap.orientation = LinearLayout.VERTICAL
        val r = dp(a, 24).toFloat()
        val g = GradientDrawable()
        g.setColor(Color.WHITE)
        g.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        wrap.background = g
        wrap.setPadding(dp(a, 8), dp(a, 14), dp(a, 8), dp(a, 18))
        wrap.addView(content)
        d.setContentView(wrap)
        d.window?.apply {
            setLayout(MATCH, WRAP)
            setGravity(Gravity.BOTTOM)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        return d
    }

    // ---------- কিবোর্ড চালু আছে কি না ----------
    fun kbEnabled(c: Context): Boolean = try {
        val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.any { it.packageName == c.packageName }
    } catch (e: Exception) {
        false
    }

    fun kbSelected(c: Context): Boolean = try {
        (Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "")
            .startsWith(c.packageName + "/")
    } catch (e: Exception) {
        false
    }

    // ---------- লেআউট বাছাই (সর্বোচ্চ তিনটি) ----------
    fun fillLayoutToggles(c: Context, p: android.content.SharedPreferences, box: LinearLayout, onChange: () -> Unit) {
        box.removeAllViews()
        val cur = LayoutPrefs.enabled(p)
        for (m in LayoutPrefs.all) {
            val on = m in cur
            val sw = switchView(c, on) { want ->
                val now = LayoutPrefs.enabled(p).toMutableList()
                if (want) {
                    if (now.size >= LayoutPrefs.MAX) {
                        toast(c, "সর্বোচ্চ তিনটি বাছাই করুন")
                    } else if (m !in now) {
                        now.add(m)
                        LayoutPrefs.save(p, now)
                    }
                } else {
                    if (now.size <= 1) toast(c, "অন্তত একটি লেআউট রাখতে হবে")
                    else {
                        now.remove(m)
                        LayoutPrefs.save(p, now)
                    }
                }
                fillLayoutToggles(c, p, box, onChange)
                onChange()
            }
            val title = when (m) {
                Mode.ENGLISH -> "English"
                Mode.AVRO -> "ফোনেটিক (অভ্র-ধাঁচ)"
                Mode.PROBHAT -> "প্রভাত"
                Mode.ARABIC -> "আরবি"
            }
            box.addView(row(c, title, null, sw, null))
        }
    }

    fun layoutSheet(a: Activity, p: android.content.SharedPreferences, onChange: () -> Unit): Dialog {
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(a, "কিবোর্ড লেআউট", 22f, ink, true))
        val s = text(a, "সর্বোচ্চ তিনটি লেআউট বেছে নিন", 13f, sub)
        s.setPadding(0, dp(a, 2), 0, dp(a, 10))
        col.addView(s)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        fillLayoutToggles(a, p, box, onChange)
        col.addView(box)
        return sheet(a, col)
    }

    // ---------- ছোট কিবোর্ডের প্রিভিউ (থিমের ছবি দেখাতে) ----------
    fun miniKeyboard(c: Context, st: Style, bmp: Bitmap?, dimPct: Int, big: Boolean): View {
        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        val pad = dp(c, if (big) 6 else 4)
        box.setPadding(pad, pad, pad, pad)
        if (bmp != null) box.background = BgDrawable(bmp, dimPct * 255 / 100)
        else box.setBackgroundColor(st.bg)

        val barText = st.sugText ?: (if (bmp != null) Color.WHITE else KeyStyle.contrast(st.bg))
        val sug = LinearLayout(c)
        sug.orientation = LinearLayout.HORIZONTAL
        if (Color.alpha(st.sugBg) > 0) sug.setBackgroundColor(st.sugBg)
        for (w in listOf("ভালো", "ভাল", "ভালোবাসা")) {
            val t = text(c, w, if (big) 13f else 10f, barText)
            t.gravity = Gravity.CENTER
            sug.addView(t, LinearLayout.LayoutParams(0, dp(c, if (big) 26 else 18), 1f))
        }
        box.addView(sug)

        val rows = listOf(
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
            listOf("?123", ",", "space", ".", "↵")
        )
        val h = dp(c, if (big) 34 else 22)
        for (r in rows) {
            val line = LinearLayout(c)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in r) {
                val special = k == "⇧" || k == "⌫" || k == "?123"
                val enter = k == "↵"
                val t = text(c, if (k == "space") "" else k, if (big) 15f else 10f,
                    if (enter && st.box) Color.WHITE else if (special) st.spText else st.text)
                t.gravity = Gravity.CENTER
                t.background = round(
                    c,
                    when {
                        !st.box -> Color.TRANSPARENT
                        enter -> st.enter
                        special -> st.special
                        else -> st.key
                    },
                    if (big) 6 else 4
                )
                val w = if (k == "space") 4f else if (k == "?123") 1.5f else 1f
                val lp = LinearLayout.LayoutParams(0, h, w)
                lp.setMargins(dp(c, 1), dp(c, 1), dp(c, 1), dp(c, 1))
                line.addView(t, lp)
            }
            box.addView(line)
        }
        return box
    }
}

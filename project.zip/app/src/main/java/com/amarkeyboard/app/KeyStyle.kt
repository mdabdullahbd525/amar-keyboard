package com.amarkeyboard.app

import android.content.SharedPreferences
import android.graphics.Color

/** কিবোর্ডের সব রঙ: থিম + ইউজারের নিজের বেছে নেওয়া রঙ (থাকলে) মিলিয়ে হিসাব করা */
class Style(
    val bg: Int,       // কিবোর্ডের পেছনের রঙ
    val key: Int,      // সাধারণ কি
    val special: Int,  // Shift, ⌫, ?123, 🌐
    val enter: Int,    // এন্টার কি
    val text: Int,     // কির লেখার রঙ
    val pressed: Int,  // চাপলে
    val box: Boolean   // কি-এর বাক্স দেখাবে কি না ("কী ব্যাকগ্রাউন্ড")
)

object KeyStyle {
    private fun custom(p: SharedPreferences, k: String): Int? =
        if (p.contains(k)) p.getInt(k, 0) else null

    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun opaque(c: Int): Int = Color.argb(255, Color.red(c), Color.green(c), Color.blue(c))

    fun resolve(p: SharedPreferences, theme: KbTheme, photo: Boolean): Style {
        val box = p.getBoolean("keyBg", true)
        val aPct = if (p.contains("keyAlpha")) p.getInt("keyAlpha", 100) else -1
        val cKey = custom(p, "ckKey")
        val cSp = custom(p, "ckSpecial")

        val baseKey = cKey ?: (if (photo) Color.BLACK else theme.key)
        val baseSp = cSp ?: (if (photo) Color.BLACK else theme.special)
        val kA = if (aPct >= 0) aPct * 255 / 100 else if (photo && cKey == null) 105 else 255
        val sA = if (aPct >= 0) aPct * 255 / 100 else if (photo && cSp == null) 150 else 255

        val pressed = when {
            !box -> Color.argb(70, 128, 128, 128)
            photo -> Color.argb(120, 255, 255, 255)
            else -> theme.keyPressed
        }
        return Style(
            bg = custom(p, "ckBg") ?: theme.bg,
            key = withAlpha(baseKey, kA),
            special = withAlpha(baseSp, sA),
            enter = custom(p, "ckEnter") ?: theme.accent,
            text = custom(p, "ckText") ?: (if (photo) Color.WHITE else theme.text),
            pressed = pressed,
            box = box
        )
    }

    /** পেছনের রঙের সাথে মানানসই লেখার রঙ (কিবোর্ডের ওপরের সারি, প্যানেলের লেখা ইত্যাদির জন্য) */
    fun contrast(bg: Int): Int {
        val lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (lum > 0.55) Color.parseColor("#202124") else Color.WHITE
    }
}

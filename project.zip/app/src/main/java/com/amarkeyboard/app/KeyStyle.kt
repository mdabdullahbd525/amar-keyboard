package com.amarkeyboard.app

import android.content.SharedPreferences
import android.graphics.Color

/** কিবোর্ডের সব রঙ: থিম + ইউজারের নিজের বেছে নেওয়া রঙ (থাকলে) মিলিয়ে হিসাব করা */
class Style(
    val bg: Int,        // কিবোর্ডের পেছনের রঙ
    val key: Int,       // সাধারণ কি
    val special: Int,   // Shift, ⌫, ?123, 🌐
    val enter: Int,     // এন্টার কি
    val text: Int,      // কির লেখার রঙ
    val spText: Int,    // ফাংশনাল কির লেখার রঙ
    val hint: Int,      // কোণের ছোট হিন্টের রঙ
    val pressed: Int,   // চাপলে
    val box: Boolean,   // কি-এর বাক্স দেখাবে কি না ("কী ব্যাকগ্রাউন্ড")
    val sugBg: Int,     // সাজেশন বারের ব্যাকগ্রাউন্ড (স্বচ্ছ হলে কিছু নেই)
    val sugText: Int?   // সাজেশন বারের লেখা (null হলে স্বয়ংক্রিয়)
)

object KeyStyle {
    val intKeys = listOf(
        "keyAlpha", "fnAlpha", "sugAlpha",
        "ckKey", "ckSpecial", "ckEnter", "ckText", "ckBg", "ckHint", "ckSug", "ckSugText", "ckSpText"
    )
    val allKeys = intKeys + "keyBg"

    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun opaque(c: Int): Int = Color.argb(255, Color.red(c), Color.green(c), Color.blue(c))

    /** ইউজারের নিজের রঙগুলো (শুধু যেগুলো বেছে নেওয়া হয়েছে) */
    fun fromPrefs(p: SharedPreferences): Map<String, Int> {
        val m = HashMap<String, Int>()
        for (k in intKeys) if (p.contains(k)) m[k] = p.getInt(k, 0)
        if (p.contains("keyBg")) m["keyBg"] = if (p.getBoolean("keyBg", true)) 1 else 0
        return m
    }

    fun clearPrefs(e: SharedPreferences.Editor) {
        for (k in allKeys) e.remove(k)
    }

    fun writePrefs(e: SharedPreferences.Editor, m: Map<String, Int>) {
        clearPrefs(e)
        for ((k, v) in m) {
            if (k == "keyBg") e.putBoolean(k, v == 1) else e.putInt(k, v)
        }
    }

    fun resolveMap(m: Map<String, Int>, theme: KbTheme, photo: Boolean): Style {
        val box = (m["keyBg"] ?: 1) == 1
        val keyA = m["keyAlpha"]
        val fnA = m["fnAlpha"] ?: keyA
        val cKey = m["ckKey"]
        val cSp = m["ckSpecial"]

        val baseKey = cKey ?: (if (photo) Color.BLACK else theme.key)
        val baseSp = cSp ?: (if (photo) Color.BLACK else theme.special)
        val kA = if (keyA != null) keyA * 255 / 100 else if (photo && cKey == null) 105 else 255
        val sA = if (fnA != null) fnA * 255 / 100 else if (photo && cSp == null) 150 else 255

        val text = m["ckText"] ?: (if (photo) Color.WHITE else theme.text)
        val hint = m["ckHint"] ?: Color.argb(170, Color.red(text), Color.green(text), Color.blue(text))
        val sugBg = m["ckSug"]?.let { withAlpha(it, (m["sugAlpha"] ?: 100) * 255 / 100) } ?: Color.TRANSPARENT

        val pressed = when {
            !box -> Color.argb(70, 128, 128, 128)
            photo -> Color.argb(120, 255, 255, 255)
            else -> theme.keyPressed
        }
        return Style(
            bg = m["ckBg"] ?: theme.bg,
            key = withAlpha(baseKey, kA),
            special = withAlpha(baseSp, sA),
            enter = m["ckEnter"] ?: theme.accent,
            text = text,
            spText = m["ckSpText"] ?: text,
            hint = hint,
            pressed = pressed,
            box = box,
            sugBg = sugBg,
            sugText = m["ckSugText"]
        )
    }

    fun resolve(p: SharedPreferences, theme: KbTheme, photo: Boolean): Style =
        resolveMap(fromPrefs(p), theme, photo)

    fun forTheme(theme: KbTheme): Style = resolveMap(emptyMap(), theme, false)

    /** পেছনের রঙের সাথে মানানসই লেখার রঙ */
    fun contrast(bg: Int): Int {
        val lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (lum > 0.55) Color.parseColor("#202124") else Color.WHITE
    }
}

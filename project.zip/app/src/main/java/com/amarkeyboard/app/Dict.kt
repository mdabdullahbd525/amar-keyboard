package com.amarkeyboard.app

/** ছোট বিল্ট-ইন শব্দভাণ্ডার (সাজেশন বারের জন্য)। এর বাইরে ইউজারের টাইপ করা শব্দ নিজে থেকে শেখা হয়। */
object Dict {
    private val bn: List<String> = (
        "আমি আমার আমাকে আমরা আমাদের তুমি তোমার তোমাকে তোমরা তোমাদের সে তার তাকে তারা তাদের আপনি আপনার আপনাকে আপনারা " +
        "এই এটা এটি ওটা ওই সেই কি কী কেন কোথায় কখন কীভাবে কেমন কত কয়টা কোন কে কাকে কার কারণ এবং আর কিন্তু তবে যদি " +
        "তাহলে অথবা যে যা যিনি সব সকল অনেক অল্প খুব বেশি কম একটু একটা একটি দুটি তিনটি প্রথম শেষ ভালো ভালোবাসা ভাল খারাপ " +
        "সুন্দর বড় ছোট নতুন পুরোনো সুখ দুঃখ আনন্দ কষ্ট রাগ ভয় হ্যাঁ না ঠিক আছে আছি আছেন আছো নেই হবে হয় হয়েছে হচ্ছে " +
        "করা করি করো করেন করছি করছে করব করবে করেছি করেছে যাই যাও যান যাব যাবে যাচ্ছি গিয়েছি আসি আসো আসুন আসব আসবে " +
        "এসেছি আসছি দেখা দেখি দেখো দেখুন দেখব বলা বলি বলো বলুন বলব বলছি খাওয়া খাই খাও খাবে খেয়েছি পড়া পড়ি পড়ো " +
        "পড়ছি লেখা লিখি লিখো লিখছি শোনা শুনি শুনো ধন্যবাদ স্বাগতম দুঃখিত ক্ষমা শুভ শুভেচ্ছা সকাল দুপুর বিকাল সন্ধ্যা " +
        "রাত আজ কাল আগামীকাল গতকাল এখন তখন পরে আগে আবার সবসময় কখনো কখনও দিন সপ্তাহ মাস বছর সময় ঘণ্টা মিনিট " +
        "বাংলা বাংলাদেশ ঢাকা চট্টগ্রাম সিলেট রাজশাহী খুলনা বরিশাল রংপুর ময়মনসিংহ দেশ শহর গ্রাম বাড়ি ঘর স্কুল কলেজ " +
        "বিশ্ববিদ্যালয় অফিস দোকান বাজার হাসপাতাল রাস্তা গাড়ি বাস ট্রেন বিমান পরিবার মা বাবা ভাই বোন ছেলে মেয়ে স্বামী " +
        "স্ত্রী বন্ধু বন্ধুরা শিক্ষক ছাত্র ছাত্রী মানুষ জীবন কাজ টাকা পানি খাবার ভাত মাছ মাংস চা কফি ফোন মোবাইল " +
        "কম্পিউটার ইন্টারনেট খবর গান সিনেমা খেলা বই কলম পরীক্ষা প্রশ্ন উত্তর সমস্যা সমাধান সাহায্য প্রয়োজন দরকার চাই " +
        "পারি পারো পারেন পারব পারবে জানি জানো জানেন বুঝি বুঝেছি ভাবি মনে মন হৃদয় চোখ হাত পা মাথা মুখ শরীর স্বাস্থ্য " +
        "ঈদ মোবারক জন্মদিন অভিনন্দন প্রিয় প্রতি সঙ্গে জন্য থেকে পর্যন্ত মধ্যে ভিতরে বাইরে উপর নিচে সামনে পিছনে কাছে দূরে"
    ).split(" ").filter { it.isNotEmpty() }.distinct()

    private val en: List<String> = (
        "the be to of and a in that have I it for not on with he as you do at this but his by from they we say her she or " +
        "an will my one all would there their what so up out if about who get which go me when make can like time no just " +
        "him know take people into year your good some could them see other than then now look only come its over think " +
        "also back after use two how our work first well way even new want because any these give day most us thanks " +
        "please hello welcome sorry today tomorrow tonight morning evening friend family message phone number address"
    ).split(" ").filter { it.isNotEmpty() }.distinct()

    fun complete(prefix: String, english: Boolean, max: Int): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val list = if (english) en else bn
        val p = if (english) prefix.lowercase() else prefix
        return list.filter { it.startsWith(p) && it != p }.take(max)
    }
}

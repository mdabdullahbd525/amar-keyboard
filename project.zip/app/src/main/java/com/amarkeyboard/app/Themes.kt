package com.amarkeyboard.app

import android.graphics.Color

/** একটি থিমের সব রঙ এক জায়গায়। নতুন থিম চাইলে নিচের তালিকায় এক লাইন যোগ করুন। */
class KbTheme(
    val id: String,
    val name: String,
    val bg: Int,          // কিবোর্ডের পেছনের রঙ
    val key: Int,         // সাধারণ কি
    val keyPressed: Int,  // চাপ দিলে কির রঙ
    val special: Int,     // Shift, Delete, ?123, 🌐 কি
    val text: Int,        // লেখার রঙ
    val accent: Int       // Enter কি ও হাইলাইট
)

object Themes {
    private fun c(hex: String) = Color.parseColor(hex)

    const val DEFAULT_ID = "smart"

    val all: List<KbTheme> = listOf(
        KbTheme("smart", "স্মার্টবর্ণ নীল", c("#E6F0FF"), c("#FFFFFF"), c("#BBD3F7"), c("#C7D9F5"), c("#0F2A5C"), c("#0B5ED7")),
        KbTheme("light", "উজ্জ্বল", c("#E8EAED"), c("#FFFFFF"), c("#CFD3D9"), c("#C9CDD3"), c("#202124"), c("#1A73E8")),
        KbTheme("dark", "অন্ধকার", c("#1F1F23"), c("#35353B"), c("#4C4C55"), c("#2A2A2F"), c("#ECECEC"), c("#5B8DEF")),
        KbTheme("amoled", "কালো (AMOLED)", c("#000000"), c("#1A1A1A"), c("#333333"), c("#0F0F0F"), c("#F2F2F2"), c("#00A86B")),
        KbTheme("ocean", "সাগর", c("#0A2A5E"), c("#123F8C"), c("#1D57B5"), c("#0D3274"), c("#EAF3FF"), c("#19C8FF")),
        KbTheme("slate", "স্লেট", c("#2B3036"), c("#3C434B"), c("#55606B"), c("#343A41"), c("#E8ECF0"), c("#4FA3FF")),
        KbTheme("green", "সবুজ", c("#E3F1E7"), c("#FFFFFF"), c("#BFDDC7"), c("#B5D6BF"), c("#1B3A26"), c("#006A4E")),
        KbTheme("mint", "পুদিনা", c("#DDF3EC"), c("#FFFFFF"), c("#B5E2D3"), c("#B7E0D2"), c("#0E3B33"), c("#00A58E")),
        KbTheme("blue", "আকাশি", c("#DCEBFA"), c("#FFFFFF"), c("#B7D3F2"), c("#AFCBEA"), c("#12304F"), c("#1565C0")),
        KbTheme("lavender", "ল্যাভেন্ডার", c("#E9E4F7"), c("#FFFFFF"), c("#CFC4EC"), c("#D3C9F0"), c("#2C1B5C"), c("#6A42D6")),
        KbTheme("rose", "গোলাপি", c("#FBE4EC"), c("#FFFFFF"), c("#F3BCD0"), c("#EFB0C7"), c("#4A1530"), c("#C2185B")),
        KbTheme("sunset", "সূর্যাস্ত", c("#FFE9D6"), c("#FFFFFF"), c("#FFCFA8"), c("#FFD2B0"), c("#4A2208"), c("#E8590C"))
    )

    fun byId(id: String): KbTheme = all.firstOrNull { it.id == id } ?: all[0]
}

package com.amarkeyboard.app

import android.graphics.Color

/** একটি থিমের সব রঙ এক জায়গায়। নতুন থিম চাইলে নিচের তালিকায় এক লাইন যোগ করুন। */
class KbTheme(
    val id: String,
    val name: String,
    val bg: Int,          // কিবোর্ডের পেছনের রঙ
    val key: Int,         // সাধারণ কি
    val keyPressed: Int,  // চাপ দিলে কির রঙ
    val special: Int,     // Shift, Delete, ?123, 🌐 কি
    val text: Int,        // লেখার রঙ
    val accent: Int       // Enter কি ও হাইলাইট
)

object Themes {
    private fun c(hex: String) = Color.parseColor(hex)

    val all: List<KbTheme> = listOf(
        KbTheme("light", "উজ্জ্বল", c("#E8EAED"), c("#FFFFFF"), c("#CFD3D9"), c("#C9CDD3"), c("#202124"), c("#1A73E8")),
        KbTheme("dark", "অন্ধকার", c("#1F1F23"), c("#35353B"), c("#4C4C55"), c("#2A2A2F"), c("#ECECEC"), c("#5B8DEF")),
        KbTheme("amoled", "কালো (AMOLED)", c("#000000"), c("#1A1A1A"), c("#333333"), c("#0F0F0F"), c("#F2F2F2"), c("#00A86B")),
        KbTheme("green", "সবুজ", c("#E3F1E7"), c("#FFFFFF"), c("#BFDDC7"), c("#B5D6BF"), c("#1B3A26"), c("#006A4E")),
        KbTheme("blue", "নীল", c("#DCEBFA"), c("#FFFFFF"), c("#B7D3F2"), c("#AFCBEA"), c("#12304F"), c("#1565C0")),
        KbTheme("rose", "গোলাপি", c("#FBE4EC"), c("#FFFFFF"), c("#F3BCD0"), c("#EFB0C7"), c("#4A1530"), c("#C2185B"))
    )

    fun byId(id: String): KbTheme = all.firstOrNull { it.id == id } ?: all[0]
}

package com.amarkeyboard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** মূল স্ক্রিন: নিচে তিনটি ট্যাব (শুরু · টিউটোরিয়াল · সেটিংস) */
class SettingsActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var tab = 0
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        tab = savedInstanceState?.getInt("tab", 0) ?: 0

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Color.WHITE)
        nav.elevation = Ui.dp(this, 8).toFloat()
        root.addView(nav, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 64)))
        setContentView(root)

        if (!prefs.getBoolean("wizardShown", false)) {
            prefs.edit().putBoolean("wizardShown", true).apply()
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        showTab()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    private fun showTab() {
        nav.removeAllViews()
        val items = listOf("🏠" to "শুরু", "💡" to "টিউটোরিয়াল", "⚙" to "সেটিংস")
        items.forEachIndexed { i, it ->
            val b = LinearLayout(this)
            b.orientation = LinearLayout.VERTICAL
            b.gravity = Gravity.CENTER
            val icon = Ui.text(this, it.first, 20f, Color.BLACK)
            icon.gravity = Gravity.CENTER
            if (i == tab) icon.background = Ui.round(this, Ui.chipBg, 16)
            icon.setPadding(Ui.dp(this, 18), Ui.dp(this, 2), Ui.dp(this, 18), Ui.dp(this, 2))
            b.addView(icon)
            b.addView(Ui.text(this, it.second, 12f, if (i == tab) Ui.primary else Ui.sub, i == tab))
            b.setOnClickListener {
                tab = i
                showTab()
            }
            nav.addView(b, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))
        }
        content.removeAllViews()
        val v = when (tab) {
            0 -> homeView()
            1 -> tutorialView()
            else -> settingsView()
        }
        content.addView(v, LinearLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun go(cls: Class<*>, page: Int = -1) {
        val i = Intent(this, cls)
        if (page >= 0) i.putExtra("page", page)
        startActivity(i)
    }

    // ------------------------------------------------------------------
    // শুরু
    // ------------------------------------------------------------------
    private fun homeView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, Ui.dp(this, 20))

        val active = Ui.kbEnabled(this) && Ui.kbSelected(this)

        // হেডার
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.background = Ui.headerGradient(this)
        head.setPadding(Ui.dp(this, 18), Ui.dp(this, 26), Ui.dp(this, 18), Ui.dp(this, 26))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        head.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 60), Ui.dp(this, 60)))
        val name = LinearLayout(this)
        name.orientation = LinearLayout.VERTICAL
        name.setPadding(Ui.dp(this, 12), 0, 0, 0)
        name.addView(Ui.text(this, "SmartBorno", 24f, Color.WHITE, true))
        name.addView(Ui.text(this, "বাংলা-প্রথম স্মার্ট কিবোর্ড", 13f, Color.parseColor("#D6E8FF")))
        head.addView(name, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val chip = Ui.text(this, if (active) "● সক্রিয়" else "● সেটআপ বাকি", 13f, if (active) Ui.ok else Color.parseColor("#C62828"), true)
        chip.background = Ui.round(this, Color.WHITE, 14)
        chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5))
        head.addView(chip)
        col.addView(head)

        // সেটআপ বাকি থাকলে সতর্কতা
        if (!active) {
            val w = Ui.card(this)
            w.background = Ui.round(this, Color.parseColor("#FFF3D6"), 16)
            w.addView(Ui.text(this, "সেটআপ সম্পূর্ণ করুন", 16f, Ui.ink, true))
            val t = Ui.text(this, "কিবোর্ড ব্যবহার করতে আগে চালু করে বেছে নিতে হবে।", 14f, Ui.sub)
            t.setPadding(0, Ui.dp(this, 4), 0, 0)
            w.addView(t)
            w.addView(Ui.button(this, "সেটআপ শুরু করুন") { go(SetupActivity::class.java) }, Ui.buttonParams(this))
            col.addView(w, Ui.cardParams(this))
        }

        // থিম ও লেআউটের সারসংক্ষেপ
        val sum = Ui.card(this)
        val two = LinearLayout(this)
        two.orientation = LinearLayout.HORIZONTAL
        val themeName = Themes.byId(prefs.getString("theme", Themes.DEFAULT_ID) ?: Themes.DEFAULT_ID).name +
                (if (KeyStyle.fromPrefs(prefs).isNotEmpty()) " (কাস্টম)" else "")
        two.addView(summaryCell("🎨 থিম", themeName) { go(ThemeActivity::class.java) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        two.addView(summaryCell("⌨ লেআউট", LayoutPrefs.summary(prefs)) {
            Ui.layoutSheet(this, prefs) { showTab() }.show()
        }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        sum.addView(two)
        col.addView(sum, Ui.cardParams(this))

        // শর্টকাট গ্রিড
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), 0)
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        r1.addView(shortcut("🎨", "থিম") { go(ThemeActivity::class.java) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r1.addView(shortcut("🖌", "কাস্টমাইজ") { go(ThemeEditorActivity::class.java) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r1.addView(shortcut("⌨", "লেআউট") { Ui.layoutSheet(this, prefs) { showTab() }.show() }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r2.addView(shortcut("⚙", "সেটিংস") { tab = 2; showTab() }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r2.addView(shortcut("📋", "ক্লিপবোর্ড") { go(ClipboardActivity::class.java) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r2.addView(shortcut("🧰", "টুলবক্স") { go(SettingsPageActivity::class.java, 3) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        grid.addView(r1)
        grid.addView(r2)
        col.addView(grid)

        // টাইপ করে দেখুন
        val tryCard = Ui.card(this)
        tryCard.addView(Ui.text(this, "এখানে টাইপ করে দেখুন", 16f, Ui.ink, true))
        val et = EditText(this)
        et.hint = "এখানে লিখুন..."
        et.minLines = 2
        et.gravity = Gravity.TOP
        tryCard.addView(et)
        col.addView(tryCard, Ui.cardParams(this))

        // লিখতে শিখুন ও থিম তৈরি
        col.addView(linkCard("✎", "লিখতে শিখুন", "ফোনেটিক, প্রভাত, কপি-পেস্ট ও টুলবক্স ব্যবহার শিখুন") { tab = 1; showTab() }, Ui.cardParams(this))
        col.addView(linkCard("🖌", "থিম তৈরি করুন", "রঙ, ব্যাকগ্রাউন্ড ও বাটন নিজের মতো সাজান") { go(ThemeEditorActivity::class.java) }, Ui.cardParams(this))

        // গোপনীয়তা
        val priv = Ui.card(this)
        val pr = LinearLayout(this)
        pr.orientation = LinearLayout.HORIZONTAL
        pr.gravity = Gravity.CENTER_VERTICAL
        pr.addView(Ui.text(this, "🛡", 32f), LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.WRAP))
        val pt = LinearLayout(this)
        pt.orientation = LinearLayout.VERTICAL
        pt.addView(Ui.text(this, "আপনার ডেটা নিরাপদ", 16f, Ui.ok, true))
        pt.addView(Ui.text(this, "ইন্টারনেট পারমিশন নেই, বিজ্ঞাপন নেই। শেখা শব্দ ও ক্লিপবোর্ড শুধু আপনার ফোনে থাকে।", 13f, Ui.sub))
        pr.addView(pt, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        priv.addView(pr)
        col.addView(priv, Ui.cardParams(this))

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun summaryCell(title: String, value: String, onClick: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4))
        c.addView(Ui.text(this, title, 14f, Ui.primary, true))
        val v = Ui.text(this, value, 13f, Ui.sub)
        v.setPadding(0, Ui.dp(this, 3), 0, 0)
        c.addView(v)
        c.setOnClickListener { onClick() }
        return c
    }

    private fun shortcut(icon: String, label: String, onClick: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8))
        val i = Ui.text(this, icon, 24f, Color.BLACK)
        i.gravity = Gravity.CENTER
        i.background = Ui.oval(this, Ui.chipBg)
        c.addView(i, LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)))
        val l = Ui.text(this, label, 13f, Ui.ink, true)
        l.setPadding(0, Ui.dp(this, 6), 0, 0)
        c.addView(l)
        c.setOnClickListener { onClick() }
        return c
    }

    private fun linkCard(icon: String, title: String, desc: String, onClick: () -> Unit): View {
        val card = Ui.card(this)
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, icon, 24f, Color.BLACK), LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.WRAP))
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.addView(Ui.text(this, title, 16f, Ui.ink, true))
        t.addView(Ui.text(this, desc, 13f, Ui.sub))
        r.addView(t, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        r.addView(Ui.chevron(this))
        card.addView(r)
        card.setOnClickListener { onClick() }
        return card
    }

    // ------------------------------------------------------------------
    // টিউটোরিয়াল
    // ------------------------------------------------------------------
    private fun tutorialView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(this, "টিউটোরিয়াল", 24f, Ui.ink, true).also {
            it.setPadding(Ui.dp(this, 20), Ui.dp(this, 22), Ui.dp(this, 20), Ui.dp(this, 8))
        })
        val card = Ui.card(this)
        card.setPadding(0, 0, 0, 0)
        TutorialActivity.titles.forEachIndexed { i, p ->
            if (i > 0) card.addView(Ui.divider(this))
            card.addView(Ui.row(this, p.first, p.second, Ui.chevron(this)) {
                val it = Intent(this, TutorialActivity::class.java)
                it.putExtra("page", i)
                startActivity(it)
            })
        }
        col.addView(card, Ui.cardParams(this))
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    // ------------------------------------------------------------------
    // সেটিংস
    // ------------------------------------------------------------------
    private fun settingsView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(this, "সেটিংস", 24f, Ui.ink, true).also {
            it.setPadding(Ui.dp(this, 20), Ui.dp(this, 22), Ui.dp(this, 20), Ui.dp(this, 8))
        })
        val card = Ui.card(this)
        card.setPadding(0, 0, 0, 0)
        val rows = ArrayList<View>()
        for ((i, pg) in SettingsSpecs.pages.withIndex()) {
            rows.add(Ui.row(this, pg.title, pageDesc(i), Ui.chevron(this)) { go(SettingsPageActivity::class.java, i) })
        }
        rows.add(Ui.row(this, "ভাষা ও লেআউট", LayoutPrefs.summary(prefs), Ui.chevron(this)) {
            Ui.layoutSheet(this, prefs) { showTab() }.show()
        })
        rows.add(Ui.row(this, "থিম ও কি-এর রঙ", "থিম বাছুন, নিজের থিম বানান", Ui.chevron(this)) { go(ThemeActivity::class.java) })
        rows.add(Ui.row(this, "ক্লিপবোর্ড", "কপি করা লেখা, পিন করা লেখা", Ui.chevron(this)) { go(ClipboardActivity::class.java) })
        rows.add(Ui.row(this, "সেটআপ আবার দেখুন", "কিবোর্ড চালু ও বেছে নেওয়ার ধাপ", Ui.chevron(this)) { go(SetupActivity::class.java) })
        rows.add(Ui.row(this, "রিলিজ নোট", "ভার্সন অনুযায়ী পরিবর্তন", Ui.chevron(this)) {
            val it = Intent(this, InfoActivity::class.java)
            it.putExtra("kind", "notes")
            startActivity(it)
        })
        rows.add(Ui.row(this, "পরিচিতি", "SmartBorno সম্পর্কে", Ui.chevron(this)) {
            val it = Intent(this, InfoActivity::class.java)
            it.putExtra("kind", "about")
            startActivity(it)
        })
        rows.forEachIndexed { i, r ->
            if (i > 0) card.addView(Ui.divider(this))
            card.addView(r)
        }
        col.addView(card, Ui.cardParams(this))
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun pageDesc(i: Int): String = when (i) {
        0 -> "অটো-ক্যাপিটালাইজেশন, ভাইব্রেশন, শব্দ, ইমোজি বাটন ইত্যাদি"
        1 -> "নম্বর সারি, উচ্চতা, এক হাতে ও স্প্লিট কিবোর্ড"
        2 -> "পরামর্শ, ব্যক্তিগতকৃত শেখা"
        3 -> "ইনকগনিটো, ক্যালকুলেটর, স্নিপেট, তারিখ-সময়"
        else -> "লং-প্রেস, স্পেস কার্সর, পপআপের সময়"
    }
}

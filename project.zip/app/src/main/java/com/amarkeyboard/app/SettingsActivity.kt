package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private val pickCode = 101

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(24), dp(18), dp(32))

        col.addView(title("আমার কিবোর্ড", 26f))
        col.addView(body("ইংরেজি, ফোনেটিক (Avro-ধাঁচ) ও প্রভাত লেআউট। কোনো বিজ্ঞাপন নেই, সাবস্ক্রিপশন নেই, ইন্টারনেট পারমিশনও নেই।"))

        col.addView(heading("চালু করার দুই ধাপ"))
        col.addView(button("১. কিবোর্ড চালু করুন") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button("২. এই কিবোর্ড বেছে নিন") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        col.addView(heading("শুরুর লেআউট"))
        val current = prefs.getString("mode", "AVRO")
        for (m in Mode.values()) {
            val mark = if (m.name == current) "✓  " else ""
            col.addView(button(mark + Layouts.modeName(m)) {
                prefs.edit().putString("mode", m.name).apply()
                render()
            })
        }

        col.addView(button("🎨 থিম ও কি-এর রঙ (নিজের রঙ বেছে নিন)") {
            startActivity(Intent(this, ThemeActivity::class.java))
        })

        col.addView(heading("থিম"))
        val currentTheme = prefs.getString("theme", "light")
        for (t in Themes.all) {
            val mark = if (t.id == currentTheme) "✓  " else ""
            val b = button(mark + t.name) {
                prefs.edit().putString("theme", t.id).apply()
                render()
            }
            b.setBackgroundColor(t.key)
            b.setTextColor(t.text)
            col.addView(b)
        }

        // ---------- ব্যাকগ্রাউন্ড ছবি ----------
        col.addView(heading("কিবোর্ডের ব্যাকগ্রাউন্ড ছবি"))
        val bgFile = File(filesDir, "bg.jpg")
        if (bgFile.exists()) {
            val preview = BitmapFactory.decodeFile(bgFile.path)
            if (preview != null) {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.setImageBitmap(preview)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(140))
                lp.topMargin = dp(6)
                col.addView(iv, lp)
            }
        }
        col.addView(button("গ্যালারি থেকে ছবি বাছুন") { pickImage() })
        if (bgFile.exists()) {
            col.addView(button("ছবি সরান") {
                bgFile.delete()
                render()
            })
            col.addView(body("ছবির অন্ধকার ভাব (বেশি দিলে লেখা পড়তে সুবিধা হয়)"))
            val sb = SeekBar(this)
            sb.max = 80
            sb.progress = prefs.getInt("bgDim", 35)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("bgDim", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb)
        }

        col.addView(heading("সেটিংস"))
        for ((i, pg) in SettingsSpecs.pages.withIndex()) {
            col.addView(button(pg.title) {
                val go = Intent(this, SettingsPageActivity::class.java)
                go.putExtra("page", i)
                startActivity(go)
            })
        }
        col.addView(button("পরিচিতি") {
            AlertDialog.Builder(this)
                .setTitle("পরিচিতি")
                .setMessage(SettingsSpecs.aboutText)
                .setPositiveButton("ঠিক আছে", null)
                .show()
        })

        col.addView(heading("এখানে টাইপ করে দেখুন"))
        val test = EditText(this)
        test.hint = "এখানে লিখুন..."
        test.minLines = 3
        test.gravity = Gravity.TOP
        col.addView(test)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "ছবি বাছুন"), pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == pickCode && resultCode == RESULT_OK && uri != null) {
            saveBackground(uri)
            render()
        }
    }

    // ছবি ছোট করে (সর্বোচ্চ ~১৪০০px) অ্যাপের নিজের ফোল্ডারে রাখা হয়, তাই কোনো স্টোরেজ পারমিশন লাগে না
    private fun saveBackground(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1400) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return

            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(File(filesDir, "bg.jpg")).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "ছবিটা নেওয়া গেল না, অন্য ছবি চেষ্টা করুন", Toast.LENGTH_LONG).show()
        }
    }

    private fun title(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        setTypeface(null, Typeface.BOLD)
    }

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun body(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setPadding(0, dp(6), 0, 0)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setAllCaps(false)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = dp(6) }
        setOnClickListener { onClick() }
    }
}

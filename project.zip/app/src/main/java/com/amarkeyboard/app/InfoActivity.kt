package com.amarkeyboard.app

import android.app.Activity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** রিলিজ নোট ও পরিচিতি */
class InfoActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        val about = intent.getStringExtra("kind") == "about"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        root.addView(Ui.appBar(this, if (about) "পরিচিতি" else "রিলিজ নোট"))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 24))

        if (about) {
            val c = Ui.card(this)
            val logo = ImageView(this)
            logo.setImageResource(R.drawable.logo)
            c.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96)))
            c.addView(Ui.text(this, "SmartBorno", 24f, Ui.ink, true))
            c.addView(Ui.text(this, "ভার্সন ২.০", 14f, Ui.sub))
            val d = Ui.text(
                this,
                "বাংলা-প্রথম, বহুভাষিক অ্যান্ড্রয়েড কিবোর্ড: ফোনেটিক, প্রভাত, English ও আরবি।\n\n" +
                        "• কোনো ইন্টারনেট পারমিশন নেই, আপনার লেখা ফোনের বাইরে যায় না।\n" +
                        "• কোনো বিজ্ঞাপন নেই, কোনো সাবস্ক্রিপশন নেই।\n" +
                        "• পাসওয়ার্ড ঘরে কিছুই শেখা বা জমানো হয় না।",
                15f, Ui.ink
            )
            d.setPadding(0, Ui.dp(this, 12), 0, 0)
            c.addView(d)
            col.addView(c, Ui.cardParams(this))
        } else {
            val versions = listOf(
                "২.০" to "নতুন নাম SmartBorno ও নতুন লোগো।\nনতুন ডিজাইন: সেটআপ উইজার্ড, হোম, টিউটোরিয়াল, সেটিংস।\nথিম গ্যালারি, থিম এডিটর (রঙের প্রিসেট, ব্যাকগ্রাউন্ড, বাটন, সাজেশন, ফাংশনাল বাটন), নিজের থিম সেভ করা।\nক্লিপবোর্ড পাতা: পিন, সময়সহ তালিকা, হাতে যোগ করা।\nলেআউট বাছাই (সর্বোচ্চ তিনটি)।",
                "১.২" to "থিম ও কি-এর রঙ, কী ব্যাকগ্রাউন্ড সুইচ, কি-এর স্বচ্ছতা।",
                "১.১" to "আরবি লেআউট, টুলবক্স, চিহ্ন প্যানেল, ইনকগনিটো মোড, স্নিপেট।",
                "১.০" to "ইংরেজি, ফোনেটিক ও প্রভাত লেআউট, ক্লিপবোর্ড, কপি-পেস্ট কি, ইমোজি, সাজেশন বার।"
            )
            for ((v, n) in versions) {
                val c = Ui.card(this)
                c.addView(Ui.text(this, "ভার্সন $v", 17f, Ui.ink, true))
                val t = Ui.text(this, n, 14f, Ui.sub)
                t.setPadding(0, Ui.dp(this, 6), 0, 0)
                c.addView(t)
                col.addView(c, Ui.cardParams(this))
            }
        }
        val sv = ScrollView(this)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
    }
}

package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File

/** একটি সেটিংস পাতা: SettingsSpecs-এর তালিকা থেকে নিজে নিজে সারি বানায় */
class SettingsPageActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var sv: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        render()
    }

    private fun render() {
        val page = SettingsSpecs.pages[intent.getIntExtra("page", 0).coerceIn(0, SettingsSpecs.pages.size - 1)]
        val keepY = sv?.scrollY ?: 0

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        root.addView(Ui.appBar(this, page.title))

        val card = Ui.card(this)
        card.setPadding(0, 0, 0, 0)
        page.items.forEachIndexed { i, item ->
            if (i > 0) card.addView(Ui.divider(this))
            card.addView(rowFor(item))
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 24))
        col.addView(card, Ui.cardParams(this))

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        root.addView(s, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun enabled(dep: String?): Boolean = dep == null || Defaults.b(prefs, dep)

    private fun rowFor(item: Item): View {
        var dep: String? = null
        val row: LinearLayout = when (item) {
            is Item.Toggle -> {
                dep = item.dep
                val sw = Ui.switchView(this, Defaults.b(prefs, item.key)) { on ->
                    prefs.edit().putBoolean(item.key, on).apply()
                    render()
                }
                Ui.row(this, item.title, item.desc, sw, null)
            }
            is Item.Seek -> {
                dep = item.dep
                val cur = Defaults.i(prefs, item.key)
                Ui.row(this, item.title, "$cur${item.unit}", Ui.chevron(this)) { showSeek(item) }
            }
            is Item.Choice -> {
                dep = item.dep
                val idx = item.values.indexOf(Defaults.i(prefs, item.key)).coerceAtLeast(0)
                Ui.row(this, item.title, item.labels[idx], Ui.chevron(this)) { showChoice(item, idx) }
            }
            is Item.Action -> Ui.row(this, item.title, item.desc, Ui.chevron(this)) { runAction(item) }
        }
        if (!enabled(dep)) {
            row.alpha = 0.4f
            row.setOnClickListener(null)
            row.isClickable = false
            disableChildren(row)
        }
        return row
    }

    private fun disableChildren(v: View) {
        v.isEnabled = false
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) disableChildren(v.getChildAt(i))
    }

    private fun showChoice(item: Item.Choice, checked: Int) {
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setSingleChoiceItems(item.labels.toTypedArray(), checked) { d, which ->
                prefs.edit().putInt(item.key, item.values[which]).apply()
                d.dismiss()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showSeek(item: Item.Seek) {
        val cur = Defaults.i(prefs, item.key).coerceIn(item.min, item.max)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 24), Ui.dp(this, 16), Ui.dp(this, 24), Ui.dp(this, 8))
        val value: TextView = Ui.text(this, "$cur${item.unit}", 18f, Ui.ink, true)
        val sb = SeekBar(this)
        sb.max = (item.max - item.min) / item.step
        sb.progress = (cur - item.min) / item.step
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "${item.min + p * item.step}${item.unit}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(value)
        box.addView(sb)
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setView(box)
            .setPositiveButton("ঠিক আছে") { _, _ ->
                prefs.edit().putInt(item.key, item.min + sb.progress * item.step).apply()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun runAction(item: Item.Action) {
        when (item.id) {
            "clearLearned" -> AlertDialog.Builder(this)
                .setTitle(item.title)
                .setMessage("কিবোর্ডের শেখা সব শব্দ মুছে ফেলা হবে। নিশ্চিত?")
                .setPositiveButton("মুছুন") { _, _ ->
                    try { File(filesDir, "learned.txt").delete() } catch (e: Exception) { }
                    prefs.edit().putLong("learnClear", System.currentTimeMillis()).apply()
                    Ui.toast(this, "শেখা শব্দ মুছে ফেলা হয়েছে")
                }
                .setNegativeButton("বাতিল", null)
                .show()

            "clearClips" -> AlertDialog.Builder(this)
                .setTitle(item.title)
                .setMessage("ক্লিপবোর্ডের সব লেখা (পিন করাগুলোসহ) মুছে যাবে। নিশ্চিত?")
                .setPositiveButton("মুছুন") { _, _ ->
                    prefs.edit().putString("clips", "[]")
                        .putLong("clipsClear", System.currentTimeMillis()).apply()
                    Ui.toast(this, "ক্লিপবোর্ড ইতিহাস মুছে গেছে")
                }
                .setNegativeButton("বাতিল", null)
                .show()

            "addSnippet" -> {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 4))
                val k = EditText(this)
                k.hint = "শর্টকাট (শুধু অক্ষর, যেমন: addr)"
                val v = EditText(this)
                v.hint = "পুরো লেখা"
                v.minLines = 2
                box.addView(k)
                box.addView(v)
                AlertDialog.Builder(this)
                    .setTitle("নতুন স্নিপেট")
                    .setView(box)
                    .setPositiveButton("সেভ") { _, _ ->
                        val key = k.text.toString().trim()
                        val value = v.text.toString()
                        if (!Regex("[\\p{L}\\p{M}]+").matches(key) || value.isEmpty()) {
                            Ui.toast(this, "শর্টকাট শুধু অক্ষর হতে হবে, আর লেখা ফাঁকা রাখা যাবে না")
                        } else {
                            Snippets.add(prefs, key, value)
                            Ui.toast(this, "সেভ হয়েছে")
                        }
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }

            "manageSnippets" -> {
                val list = Snippets.all(prefs)
                if (list.isEmpty()) {
                    Ui.toast(this, "কোনো স্নিপেট নেই")
                } else {
                    val labels = list.map { it.first + " → " + it.second.take(30) }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("যেটা মুছবেন সেটায় চাপুন")
                        .setItems(labels) { _, which ->
                            Snippets.remove(prefs, list[which].first)
                            Ui.toast(this, "মোছা হয়েছে")
                        }
                        .setNegativeButton("বন্ধ", null)
                        .show()
                }
            }

            "privacyInfo" -> AlertDialog.Builder(this)
                .setTitle("গোপনীয়তা")
                .setMessage(
                    "• অ্যাপে কোনো ইন্টারনেট পারমিশন নেই, তাই আপনার লেখা কোথাও যায় না।\n" +
                            "• পাসওয়ার্ড ঘরে কিছুই শেখা, সাজেস্ট বা জমানো হয় না।\n" +
                            "• শেখা শব্দ, ক্লিপবোর্ড তালিকা আর স্নিপেট শুধু এই ফোনের ভেতরে থাকে।\n" +
                            "• ইনকগনিটো মোডে কিছুই শেখা বা জমানো হয় না।\n" +
                            "• যেকোনো সময় সেটিংস থেকে শেখা শব্দ ও ক্লিপবোর্ড মুছে ফেলা যায়।"
                )
                .setPositiveButton("ঠিক আছে", null)
                .show()
        }
    }
}

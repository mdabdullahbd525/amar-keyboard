package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** একটি সেটিংস পাতা: SettingsSpecs-এর তালিকা থেকে নিজে নিজে সারি বানায় */
class SettingsPageActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var sv: ScrollView? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val page = SettingsSpecs.pages[intent.getIntExtra("page", 0)]
        val keepY = sv?.scrollY ?: 0

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(16), 0, dp(24))

        val head = TextView(this)
        head.text = page.title
        head.textSize = 22f
        head.setTypeface(null, Typeface.BOLD)
        head.setPadding(dp(18), dp(8), dp(18), dp(12))
        col.addView(head)

        for (item in page.items) col.addView(rowFor(item))

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun enabled(dep: String?): Boolean = dep == null || Defaults.b(prefs, dep)

    private fun rowFor(item: Item): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), dp(12), dp(18), dp(12))

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.textSize = 16f
        val sub = TextView(this)
        sub.textSize = 13f
        sub.alpha = 0.65f
        texts.addView(title)
        texts.addView(sub)
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        var dep: String? = null
        when (item) {
            is Item.Toggle -> {
                dep = item.dep
                title.text = item.title
                setSub(sub, item.desc)
                val sw = Switch(this)
                sw.isChecked = Defaults.b(prefs, item.key)
                sw.isClickable = false
                row.addView(sw)
                row.setOnClickListener {
                    prefs.edit().putBoolean(item.key, !Defaults.b(prefs, item.key)).apply()
                    render()
                }
            }
            is Item.Seek -> {
                dep = item.dep
                title.text = item.title
                val cur = Defaults.i(prefs, item.key)
                setSub(sub, "$cur${item.unit}")
                row.setOnClickListener { showSeek(item) }
            }
            is Item.Choice -> {
                dep = item.dep
                title.text = item.title
                val idx = item.values.indexOf(Defaults.i(prefs, item.key)).coerceAtLeast(0)
                setSub(sub, item.labels[idx])
                row.setOnClickListener { showChoice(item, idx) }
            }
            is Item.Action -> {
                title.text = item.title
                setSub(sub, item.desc)
                row.setOnClickListener { runAction(item) }
            }
        }

        if (!enabled(dep)) {
            row.alpha = 0.4f
            row.setOnClickListener(null)
            row.isClickable = false
        }
        return row
    }

    private fun setSub(tv: TextView, t: String?) {
        if (t.isNullOrEmpty()) tv.visibility = View.GONE else tv.text = t
    }

    private fun showChoice(item: Item.Choice, checked: Int) {
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setSingleChoiceItems(item.labels.toTypedArray(), checked) { d, which ->
                prefs.edit().putInt(item.key, item.values[which]).apply()
                d.dismiss()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showSeek(item: Item.Seek) {
        val cur = Defaults.i(prefs, item.key).coerceIn(item.min, item.max)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(8))
        val value = TextView(this)
        value.textSize = 18f
        value.text = "$cur${item.unit}"
        val sb = SeekBar(this)
        sb.max = (item.max - item.min) / item.step
        sb.progress = (cur - item.min) / item.step
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "${item.min + p * item.step}${item.unit}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(value)
        box.addView(sb)
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setView(box)
            .setPositiveButton("ঠিক আছে") { _, _ ->
                prefs.edit().putInt(item.key, item.min + sb.progress * item.step).apply()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun runAction(item: Item.Action) {
        when (item.id) {
            "clearLearned" -> AlertDialog.Builder(this)
                .setTitle(item.title)
                .setMessage("কিবোর্ডের শেখা সব শব্দ মুছে ফেলা হবে। নিশ্চিত?")
                .setPositiveButton("মুছুন") { _, _ ->
                    try { File(filesDir, "learned.txt").delete() } catch (e: Exception) { }
                    prefs.edit().putLong("learnClear", System.currentTimeMillis()).apply()
                    toast("শেখা শব্দ মুছে ফেলা হয়েছে")
                }
                .setNegativeButton("বাতিল", null)
                .show()

            "clearClips" -> AlertDialog.Builder(this)
                .setTitle(item.title)
                .setMessage("ক্লিপবোর্ডের সব লেখা (পিন করাগুলোসহ) মুছে যাবে। নিশ্চিত?")
                .setPositiveButton("মুছুন") { _, _ ->
                    prefs.edit().putString("clips", "[]")
                        .putLong("clipsClear", System.currentTimeMillis()).apply()
                    toast("ক্লিপবোর্ড ইতিহাস মুছে গেছে")
                }
                .setNegativeButton("বাতিল", null)
                .show()

            "addSnippet" -> {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding(dp(20), dp(12), dp(20), dp(4))
                val k = EditText(this)
                k.hint = "শর্টকাট (শুধু অক্ষর, যেমন: addr)"
                val v = EditText(this)
                v.hint = "পুরো লেখা"
                v.minLines = 2
                box.addView(k)
                box.addView(v)
                AlertDialog.Builder(this)
                    .setTitle("নতুন স্নিপেট")
                    .setView(box)
                    .setPositiveButton("সেভ") { _, _ ->
                        val key = k.text.toString().trim()
                        val value = v.text.toString()
                        if (!Regex("[\\p{L}\\p{M}]+").matches(key) || value.isEmpty()) {
                            toast("শর্টকাট শুধু অক্ষর হতে হবে, আর লেখা ফাঁকা রাখা যাবে না")
                        } else {
                            Snippets.add(prefs, key, value)
                            toast("সেভ হয়েছে")
                        }
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }

            "manageSnippets" -> {
                val list = Snippets.all(prefs)
                if (list.isEmpty()) {
                    toast("কোনো স্নিপেট নেই")
                } else {
                    val labels = list.map { it.first + " → " + it.second.take(30) }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("যেটা মুছবেন সেটায় চাপুন")
                        .setItems(labels) { _, which ->
                            Snippets.remove(prefs, list[which].first)
                            toast("মোছা হয়েছে")
                        }
                        .setNegativeButton("বন্ধ", null)
                        .show()
                }
            }

            "privacyInfo" -> AlertDialog.Builder(this)
                .setTitle("গোপনীয়তা")
                .setMessage(
                    "• অ্যাপে কোনো ইন্টারনেট পারমিশন নেই, তাই আপনার লেখা কোথাও যায় না।\n" +
                            "• পাসওয়ার্ড ঘরে কিছুই শেখা, সাজেস্ট বা জমানো হয় না।\n" +
                            "• শেখা শব্দ, ক্লিপবোর্ড তালিকা আর স্নিপেট শুধু এই ফোনের ভেতরে থাকে।\n" +
                            "• ইনকগনিটো মোডে কিছুই শেখা বা জমানো হয় না।\n" +
                            "• যেকোনো সময় সেটিংস থেকে শেখা শব্দ ও ক্লিপবোর্ড মুছে ফেলা যায়।"
                )
                .setPositiveButton("ঠিক আছে", null)
                .show()
        }
    }
}

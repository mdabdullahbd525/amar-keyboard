package com.amarkeyboard.app

/**
 * ফোনেটিক (Avro-ধাঁচের) ইঞ্জিন: ইংরেজি হরফে টাইপ করা লেখাকে বাংলায় বদলায়।
 * যেমন: ami -> আমি, bangla -> বাংলা, kotha -> কথা
 */
object AvroEngine {

    private sealed class Tok {
        class C(val s: String) : Tok()                    // ব্যঞ্জন
        class V(val full: String, val kar: String) : Tok() // স্বর (পূর্ণ রূপ, কার)
        class M(val s: String) : Tok()                    // অন্য চিহ্ন
        class Phola(val s: String) : Tok()                // য-ফলা
    }

    private val table: Map<String, Tok> = mapOf(
        // ---- ব্যঞ্জন (বড় প্যাটার্ন আগে মেলানো হয়) ----
        "kkh" to Tok.C("ক্ষ"), "GG" to Tok.C("জ্ঞ"), "chh" to Tok.C("ছ"),
        "kh" to Tok.C("খ"), "gh" to Tok.C("ঘ"), "Ng" to Tok.C("ঙ"), "NG" to Tok.C("ঞ"),
        "ch" to Tok.C("ছ"), "jh" to Tok.C("ঝ"), "Th" to Tok.C("ঠ"), "Dh" to Tok.C("ঢ"),
        "th" to Tok.C("থ"), "dh" to Tok.C("ধ"), "ph" to Tok.C("ফ"), "bh" to Tok.C("ভ"),
        "sh" to Tok.C("শ"), "Sh" to Tok.C("ষ"), "Rh" to Tok.C("\u09DD"),
        "k" to Tok.C("ক"), "g" to Tok.C("গ"), "c" to Tok.C("চ"), "j" to Tok.C("জ"),
        "T" to Tok.C("ট"), "D" to Tok.C("ড"), "N" to Tok.C("ণ"),
        "t" to Tok.C("ত"), "d" to Tok.C("দ"), "n" to Tok.C("ন"),
        "p" to Tok.C("প"), "f" to Tok.C("ফ"), "b" to Tok.C("ব"), "v" to Tok.C("ভ"),
        "m" to Tok.C("ম"), "z" to Tok.C("য"), "r" to Tok.C("র"), "l" to Tok.C("ল"),
        "s" to Tok.C("স"), "S" to Tok.C("শ"), "h" to Tok.C("হ"),
        "R" to Tok.C("\u09DC"), "y" to Tok.C("\u09DF"), "q" to Tok.C("ক"), "x" to Tok.C("ক্স"),
        "Z" to Tok.Phola("্য"),
        "w" to Tok.M("ও"),

        // ---- স্বর ----
        "rri" to Tok.V("ঋ", "ৃ"),
        "oi" to Tok.V("ঐ", "ৈ"), "OI" to Tok.V("ঐ", "ৈ"),
        "ou" to Tok.V("ঔ", "ৌ"), "OU" to Tok.V("ঔ", "ৌ"),
        "oo" to Tok.V("উ", "ু"), "uu" to Tok.V("ঊ", "ূ"),
        "ee" to Tok.V("ঈ", "ী"), "ii" to Tok.V("ঈ", "ী"),
        "o" to Tok.V("অ", ""),
        "a" to Tok.V("আ", "া"),
        "i" to Tok.V("ই", "ি"), "I" to Tok.V("ঈ", "ী"),
        "u" to Tok.V("উ", "ু"), "U" to Tok.V("ঊ", "ূ"),
        "e" to Tok.V("এ", "ে"),
        "O" to Tok.V("ও", "ো"),

        // ---- বিশেষ চিহ্ন ----
        "t``" to Tok.M("ৎ"),
        "^" to Tok.M("ঁ"),
        ":" to Tok.M("ঃ")
    )

    fun convert(src: String): String {
        val out = StringBuilder()
        var i = 0
        var joinable = false // শেষে বসানো অক্ষরটি ব্যঞ্জন, যাতে কার বা হসন্ত বসতে পারে

        while (i < src.length) {
            // "ng": স্বরের আগে ঙ্গ (ranga -> রাঙ্গা), নইলে ং (bangla -> বাংলা)
            if (src.startsWith("ng", i)) {
                val next = src.getOrNull(i + 2)
                if (next != null && "aeiouAEIOU".indexOf(next) >= 0) {
                    if (joinable) out.append('্')
                    out.append("ঙ্গ")
                    joinable = true
                } else {
                    out.append("ং")
                    joinable = false
                }
                i += 2
                continue
            }

            var tok: Tok? = null
            var len = 0
            for (l in 3 downTo 1) {
                if (i + l <= src.length) {
                    val t = table[src.substring(i, i + l)]
                    if (t != null) { tok = t; len = l; break }
                }
            }
            // বড় হাতের অক্ষর টেবিলে না থাকলে ছোট হাতেরটা ধরা হয় (Bangla -> বাংলা)
            if (tok == null && src[i].isUpperCase()) {
                val t = table[src[i].lowercaseChar().toString()]
                if (t != null) { tok = t; len = 1 }
            }

            val token = tok
            if (token == null) {
                out.append(src[i])
                joinable = false
                i++
                continue
            }

            when (token) {
                is Tok.C -> {
                    if (joinable) out.append('্')
                    out.append(token.s)
                    joinable = true
                }
                is Tok.Phola -> {
                    out.append(token.s)
                    joinable = true
                }
                is Tok.V -> {
                    if (token.kar.isEmpty()) {
                        // 'o': ব্যঞ্জনের পরে হলে কিছু বসে না, শুধু যুক্তাক্ষর ভাঙে
                        if (joinable) joinable = false else out.append(token.full)
                    } else {
                        out.append(if (joinable) token.kar else token.full)
                        joinable = false
                    }
                }
                is Tok.M -> {
                    out.append(token.s)
                    joinable = false
                }
            }
            i += len
        }
        return out.toString()
    }
}

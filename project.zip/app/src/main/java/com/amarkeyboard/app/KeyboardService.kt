package com.amarkeyboard.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class KeyboardService : InputMethodService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var learn: Learn
    private var audio: AudioManager? = null
    private var vibrator: Vibrator? = null
    private var root: LinearLayout? = null

    private var mode = Mode.AVRO
    private var theme: KbTheme = Themes.all[0]
    private var shift = Shift.OFF
    private var autoShift = false
    private var symbols = false
    private var emojiOpen = false
    private var emojiCat = 0
    private var latinDigits = false
    private var passwordField = false
    private var imeAction = EditorInfo.IME_ACTION_NONE
    private var oneHand = "OFF"
    private var lastWord: String? = null
    private var clearStamp = 0L

    private val buffer = StringBuilder() // ফোনেটিক মোডে এখনো-শেষ-না-হওয়া রোমান অক্ষর
    private val handler = Handler(Looper.getMainLooper())
    private var repeatRunnable: Runnable? = null
    private var lastShiftTap = 0L
    private var cursorMode = false
    private var popup: PopupWindow? = null

    private var clipboard: ClipboardManager? = null
    private lateinit var clips: ClipStore
    private var clipOpen = false       // ক্লিপবোর্ড প্যানেল খোলা আছে কি না
    private var toolbarOpen = false    // ওপরের আইকন-মেনু খোলা আছে কি না
    private var editMode = false       // ✂ মোড: c/x/v/a কি কপি-কাট-পেস্ট করে
    private var selectionActive = false // এডিটরে লেখা সিলেক্ট করা আছে কি না
    private var toolsOpen = false      // টুলবক্স প্যানেল
    private var symOpen = false        // চিহ্ন প্যানেল
    private var symCat = 0
    private var toolsTab = 0
    private var calcExpr = ""
    private var calcResult = ""
    private var pwLen = 12
    private var pwText = ""
    private var countText = ""
    private var clipsStamp = 0L
    private var slideDir = 0           // ভাষা বদলের সময় স্পেসবারের লেখা কোন দিক থেকে ঢুকবে

    private fun panelOpen(): Boolean = emojiOpen || clipOpen || toolsOpen || symOpen
    private fun closePanels() {
        emojiOpen = false
        clipOpen = false
        toolsOpen = false
        symOpen = false
    }

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (b("clipHistory") && !b("incognito")) {
            try {
                val sensitive = clipboard?.primaryClipDescription?.extras
                    ?.getBoolean("android.content.extra.IS_SENSITIVE", false) ?: false
                val t = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
                if (!sensitive && !t.isNullOrBlank()) clips.add(t)
            } catch (e: Exception) {
            }
        }
    }

    private var bgBitmap: Bitmap? = null // ব্যাকগ্রাউন্ড ছবি (না থাকলে null)
    private var bgStamp = 0L
    private var bgDim = 35
    private lateinit var style: Style

    private var sugViews: List<TextView> = emptyList()
    private var currentSuggestions: List<String> = emptyList()

    private fun b(k: String): Boolean = Defaults.b(prefs, k)
    private fun n(k: String): Int = Defaults.i(prefs, k)

    // ------------------------------------------------------------------
    // জীবনচক্র
    // ------------------------------------------------------------------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        clearStamp = prefs.getLong("learnClear", 0L)
        clipsStamp = prefs.getLong("clipsClear", 0L)
        learn = Learn(File(filesDir, "learned.txt"))
        learn.load()
        audio = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        clips = ClipStore(prefs)
        clips.load()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard?.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        loadPrefs()
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        root = r
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        buffer.setLength(0)
        lastWord = null
        closePanels()
        toolbarOpen = false
        editMode = false
        selectionActive = (info?.initialSelStart ?: 0) != (info?.initialSelEnd ?: 0)
        loadPrefs()

        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
                cls == InputType.TYPE_CLASS_PHONE ||
                cls == InputType.TYPE_CLASS_DATETIME
        passwordField =
            (cls == InputType.TYPE_CLASS_TEXT &&
                    (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                    (cls == InputType.TYPE_CLASS_NUMBER &&
                            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        val opts = info?.imeOptions ?: 0
        imeAction = if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) EditorInfo.IME_ACTION_NONE
        else opts and EditorInfo.IME_MASK_ACTION

        latinDigits = numeric
        symbols = numeric
        if (passwordField) mode = Mode.ENGLISH
        shift = Shift.OFF
        autoShift = false
        build()
        updateAutoCap()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopRepeat()
        dismissPopupNow()
        buffer.setLength(0)
        currentInputConnection?.finishComposingText()
        learn.save()
    }

    // ইউজার অন্য জায়গায় কার্সর নিলে চলমান শব্দ বাদ
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd
        )
        val sel = newSelStart != newSelEnd
        if (sel != selectionActive) {
            selectionActive = sel
            if (b("autoEdit")) build()
        }
        if (buffer.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            buffer.setLength(0)
            currentInputConnection?.finishComposingText()
        }
    }

    // ভলিউম বাটন দিয়ে কার্সর সরানো
    private fun volumeCursorActive(keyCode: Int): Boolean {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!isInputViewShown || !b("volCursor")) return false
        if (b("volCursorMusicOff") && audio?.isMusicActive == true) return false
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeCursorActive(keyCode)) {
            commitAvro()
            sendDownUpKeyEvents(
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) KeyEvent.KEYCODE_DPAD_LEFT
                else KeyEvent.KEYCODE_DPAD_RIGHT
            )
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeCursorActive(keyCode)) return true
        return super.onKeyUp(keyCode, event)
    }

    private fun loadPrefs() {
        mode = try {
            Mode.valueOf(prefs.getString("mode", "AVRO") ?: "AVRO")
        } catch (e: Exception) {
            Mode.AVRO
        }
        theme = Themes.byId(prefs.getString("theme", Themes.DEFAULT_ID) ?: Themes.DEFAULT_ID)
        bgDim = prefs.getInt("bgDim", 35)
        oneHand = prefs.getString("oneHand", "OFF") ?: "OFF"
        val enabledModes = LayoutPrefs.enabled(prefs)
        if (mode !in enabledModes) mode = enabledModes.first()

        val cs = prefs.getLong("learnClear", 0L)
        if (cs != clearStamp) {
            clearStamp = cs
            learn.clear()
        }

        clipsStamp = prefs.getLong("clipsClear", 0L)
        clips.load()

        val f = File(filesDir, "bg.jpg")
        val stamp = if (f.exists()) f.lastModified() else 0L
        if (stamp != bgStamp) {
            bgBitmap = if (stamp == 0L) null else try {
                BitmapFactory.decodeFile(f.path)
            } catch (e: Throwable) {
                null
            }
            bgStamp = stamp
        }
        style = KeyStyle.resolve(prefs, theme, photo)
    }

    private val photo: Boolean get() = bgBitmap != null
    // কিবোর্ডের পেছনের ওপর বসা লেখা (ওপরের সারি, প্যানেল): পেছনের রঙের সাথে মানানসই
    private fun textColor(): Int = when {
        photo -> Color.WHITE
        prefs.contains("ckBg") -> KeyStyle.contrast(style.bg)
        else -> theme.text
    }

    // কি-এর গায়ের লেখা
    private fun keyTextColor(): Int = style.text

    // ------------------------------------------------------------------
    // ইউআই তৈরি
    // ------------------------------------------------------------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun landscape(): Boolean =
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun splitActive(): Boolean =
        (landscape() && b("split")) ||
                (b("foldable") && resources.configuration.screenWidthDp >= 600)

    private fun bottomRow(row: List<Key>): List<Key> {
        val out = ArrayList<Key>()
        for (k in row) {
            out.add(k)
        }
        if (b("emojiBtn")) {
            var at = -1
            for ((i, k) in out.withIndex()) {
                if (k.type == KeyType.SYM || k.type == KeyType.LANG) at = i
            }
            out.add(at + 1, Key("", "", KeyType.EMOJI, 1.1f))
        }
        return out
    }

    private fun currentRows(): List<List<Key>> {
        if (symbols) return Layouts.symbolPage
        val base = when (mode) {
            Mode.PROBHAT -> Layouts.probhat
            Mode.ARABIC -> Layouts.arabic
            else -> Layouts.latin
        }
        val rows = ArrayList<List<Key>>()
        base.forEachIndexed { idx, row ->
            if (idx == 0 && !b("numRow")) return@forEachIndexed
            rows.add(if (idx == base.size - 1) bottomRow(row) else row)
        }
        return rows
    }

    private fun rowHeight(isNumberRow: Boolean): Int {
        val land = landscape()
        val pct = if (b("heightCustom")) (if (land) n("heightL") else n("heightP"))
        else (if (land) 100 else 85)
        var h = dp(52) * pct / 100f
        if (land) h *= 0.62f
        if (isNumberRow) h *= if (b("bigNumRow")) 1.12f else 0.85f
        return h.toInt()
    }

    private fun build() {
        val r = root ?: return
        r.removeAllViews()
        val bmp = bgBitmap
        if (bmp != null) r.background = BgDrawable(bmp, bgDim * 255 / 100)
        else r.setBackgroundColor(style.bg)

        var left = dp(4)
        var right = dp(4)
        if (oneHand != "OFF") {
            val screenW = resources.displayMetrics.widthPixels
            val pct = if (landscape()) n("ohL") else n("ohP")
            val extra = screenW - (screenW * pct / 100)
            if (oneHand == "RIGHT") left += extra else right += extra
        }
        r.setPadding(left, dp(2), right, dp(6))

        r.addView(topBar())
        if (emojiOpen) {
            r.addView(emojiPanel())
        } else if (clipOpen) {
            r.addView(clipPanel())
        } else if (toolsOpen) {
            r.addView(toolsPanel())
        } else if (symOpen) {
            r.addView(symbolPanel())
        } else {
            val hasNumberRow = symbols || b("numRow")
            currentRows().forEachIndexed { idx, row ->
                r.addView(rowView(row, rowHeight(idx == 0 && hasNumberRow)))
            }
        }
        updateSuggestions()
        slideDir = 0
    }

    private fun toolItem(icon: String, active: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = icon
        t.textSize = 19f
        t.gravity = Gravity.CENTER
        t.setTextColor(
            if (active) (if (photo) Color.parseColor("#FFD54F") else theme.accent) else textColor()
        )
        t.setOnClickListener { onClick() }
        return t
    }

    private fun topBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
        if (Color.alpha(style.sugBg) > 0) bar.setBackgroundColor(style.sugBg)

        // বাঁ কোণের বাটন: ওপরের আইকন-মেনু খোলে/বন্ধ করে
        val toggle = TextView(this)
        toggle.text = if (toolbarOpen) "✕" else "☰"
        toggle.textSize = 18f
        toggle.gravity = Gravity.CENTER
        toggle.setTextColor(textColor())
        toggle.setOnClickListener {
            toolbarOpen = !toolbarOpen
            build()
        }
        bar.addView(toggle, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))

        if (toolbarOpen) {
            sugViews = emptyList()
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val lpw = { LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.MATCH_PARENT) }

            row.addView(toolItem("😊", false) {
                commitAvro(); closePanels(); emojiOpen = true; toolbarOpen = false; build()
            }, lpw())
            row.addView(toolItem("📋", false) {
                commitAvro(); closePanels(); clipOpen = true; toolbarOpen = false; build()
            }, lpw())
            row.addView(toolItem("🧰", false) {
                commitAvro(); closePanels(); toolsOpen = true; toolbarOpen = false; build()
            }, lpw())
            row.addView(toolItem("Ω", false) {
                commitAvro(); closePanels(); symOpen = true; toolbarOpen = false; build()
            }, lpw())
            row.addView(toolItem("✂", editMode) {
                editMode = !editMode
                toolbarOpen = false
                toast(
                    if (editMode) "কপি-পেস্ট মোড চালু: c = কপি, x = কাট, v = পেস্ট, a = সব সিলেক্ট"
                    else "কপি-পেস্ট মোড বন্ধ"
                )
                build()
            }, lpw())
            row.addView(toolItem("🕶", b("incognito")) {
                prefs.edit().putBoolean("incognito", !b("incognito")).apply()
                toast(if (b("incognito")) "ইনকগনিটো চালু: কিছু শেখা বা জমানো হবে না" else "ইনকগনিটো বন্ধ")
                build()
            }, lpw())
            row.addView(toolItem(if (symbols) "ABC" else "?123", symbols) {
                commitAvro(); symbols = !symbols; toolbarOpen = false; build()
            }, lpw())
            val ohIcon = when (oneHand) {
                "LEFT" -> "⇦"
                "RIGHT" -> "⇨"
                else -> "⇄"
            }
            row.addView(toolItem(ohIcon, oneHand != "OFF") {
                oneHand = when (oneHand) {
                    "OFF" -> "RIGHT"
                    "RIGHT" -> "LEFT"
                    else -> "OFF"
                }
                prefs.edit().putString("oneHand", oneHand).apply()
                build()
            }, lpw())
            row.addView(toolItem("⌨", false) {
                toolbarOpen = false
                build()
                try {
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                } catch (e: Exception) {
                }
            }, lpw())
            row.addView(toolItem("⚙", false) { openSettings() }, lpw())
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(row)
            bar.addView(hs, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            return bar
        }

        if (b("showSuggest")) {
            val area = LinearLayout(this)
            area.orientation = LinearLayout.HORIZONTAL
            val views = ArrayList<TextView>()
            for (i in 0 until 3) {
                val tv = TextView(this)
                tv.gravity = Gravity.CENTER
                tv.textSize = 16f
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.setTextColor(style.sugText ?: textColor())
                tv.setOnClickListener {
                    currentSuggestions.getOrNull(i)?.let { pickSuggestion(it) }
                }
                area.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                views.add(tv)
            }
            sugViews = views
            bar.addView(area, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        } else {
            sugViews = emptyList()
            val title = TextView(this)
            title.text = Layouts.modeName(mode)
            title.gravity = Gravity.CENTER_VERTICAL
            title.setTextColor(if (photo) Color.WHITE else theme.accent)
            title.textSize = 13f
            title.setTypeface(null, Typeface.BOLD)
            bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }

        val gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 18f
        gear.gravity = Gravity.CENTER
        gear.setTextColor(textColor())
        gear.setOnClickListener { openSettings() }
        bar.addView(gear, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        return bar
    }

    private fun rowView(keys: List<Key>, height: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)

        val realCount = keys.count { it.type != KeyType.PAD }
        val splitHere = splitActive() && realCount >= 8
        val half = realCount / 2
        var seen = 0

        for (k in keys) {
            if (k.type == KeyType.PAD) {
                row.addView(View(this), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, k.weight))
                continue
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, k.weight)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            row.addView(keyView(k), lp)
            seen++
            if (splitHere && seen == half) {
                row.addView(View(this), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 2.5f))
            }
        }
        return row
    }

    private fun keyView(k: Key): View {
        val fl = FrameLayout(this)
        fl.background = keyBackground(k)

        val ed = editFor(k)
        val main = TextView(this)
        main.gravity = Gravity.CENTER
        main.textSize = if (ed != null) 13f else if (k.type == KeyType.CHAR) 20f else 15f
        main.text = styled(if (ed != null) edLabel(ed) else labelOf(k), main, true)
        main.setTextColor(
            when {
                ed != null -> if (photo) Color.parseColor("#FFD54F") else theme.accent
                k.type == KeyType.ENTER -> if (style.box) Color.WHITE else keyTextColor()
                k.type == KeyType.SHIFT && shift != Shift.OFF ->
                    if (photo) Color.parseColor("#FFD54F") else theme.accent
                k.isSpecial -> style.spText
                else -> keyTextColor()
            }
        )
        fl.addView(
            main,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // ভাষা বদলালে স্পেসবারের লেখা পাশ থেকে স্লাইড করে ঢোকে
        if (k.type == KeyType.SPACE && slideDir != 0 && b("keyAnim")) {
            val d = slideDir
            main.alpha = 0f
            main.translationX = d * dp(40).toFloat()
            main.animate().alpha(1f).translationX(0f).setDuration(200)
                .setInterpolator(DecelerateInterpolator()).start()
        }

        // কোণের ছোট হিন্ট; কি চেপে ধরলে এটাই লেখা হয়
        val hint = if (k.type == KeyType.CHAR && !symbols && ed == null) k.hint else null
        if (hint != null && !shiftOn() && !b("hideHints")) {
            val h = TextView(this)
            h.textSize = 10f
            h.text = styled(hint, h, false)
            h.setTextColor(style.hint)
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
            lp.setMargins(0, dp(2), dp(4), 0)
            fl.addView(h, lp)
        }

        attachTouch(fl, k, hint)
        return fl
    }

    private fun keyBackground(k: Key): StateListDrawable {
        val base = when {
            !style.box -> Color.TRANSPARENT // "কী ব্যাকগ্রাউন্ড" বন্ধ থাকলে বাক্স নেই
            k.type == KeyType.ENTER -> style.enter
            k.isSpecial -> style.special
            else -> style.key
        }
        fun shape(color: Int) = GradientDrawable().apply {
            cornerRadius = dp(7).toFloat()
            setColor(color)
        }
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), shape(style.pressed))
        sl.addState(intArrayOf(), shape(base))
        return sl
    }

    // ------------------------------------------------------------------
    // টাচ: চাপ, চেপে ধরা, স্পেসে কার্সর সরানো, পপআপ, ভাইব্রেশন, শব্দ
    // ------------------------------------------------------------------
    // কি চাপলে ছোট স্কেল অ্যানিমেশন: চাপলে একটু ছোট, ছাড়লে নরম করে আগের মাপে ফেরে
    private fun pressAnim(v: View, down: Boolean) {
        if (!b("keyAnim")) return
        val scale = when (n("animLevel")) {
            0 -> 0.96f
            2 -> 0.86f
            else -> 0.92f
        }
        v.animate().cancel()
        if (down) {
            v.animate().scaleX(scale).scaleY(scale).setDuration(55)
                .setInterpolator(DecelerateInterpolator()).start()
        } else {
            v.animate().scaleX(1f).scaleY(1f).setDuration(130)
                .setInterpolator(OvershootInterpolator(1.8f)).start()
        }
    }

    private fun attachTouch(fl: View, k: Key, hint: String?) {
        var down = false
        var longFired = false
        var cancelled = false
        var swiped = false
        var startX = 0f
        var startY = 0f
        var lastStepX = 0f
        var longRunnable: Runnable? = null

        fl.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true
                    longFired = false
                    cancelled = false
                    swiped = false
                    startX = e.rawX
                    startY = e.rawY
                    lastStepX = e.rawX
                    v.isPressed = true
                    pressAnim(v, true)
                    feedback(v, k)
                    showPopup(v, k)
                    val r = Runnable {
                        if (down && !swiped && handleLong(v, k, hint)) longFired = true
                    }
                    longRunnable = r
                    val delay = if (k.type == KeyType.SPACE) n("spaceDelay") else n("longPressMs")
                    handler.postDelayed(r, delay.toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    if (cursorMode && k.type == KeyType.SPACE) {
                        // স্পেস চেপে ধরার পর টানলে কার্সর সরে
                        val speed = n("spaceSpeed").coerceAtLeast(30)
                        val step = (dp(1) * 3000f / speed).coerceAtLeast(dp(6).toFloat())
                        var d = e.rawX - lastStepX
                        while (d >= step) {
                            sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT)
                            lastStepX += step
                            d -= step
                        }
                        while (d <= -step) {
                            sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT)
                            lastStepX -= step
                            d += step
                        }
                    } else if (k.type == KeyType.SPACE) {
                        // স্পেসবারে বাঁয়ে/ডানে সোয়াইপ করলে লেআউট (ভাষা) বদলায়; টান ছাড়া চাপলে স্পেস
                        val dx = e.rawX - startX
                        if (!swiped && Math.abs(dx) > dp(44) && Math.abs(e.rawY - startY) < dp(60)) {
                            swiped = true
                            longRunnable?.let { handler.removeCallbacks(it) }
                            if (LayoutPrefs.enabled(prefs).size > 1) {
                                slideDir = if (dx < 0) 1 else -1
                                v.isPressed = false
                                v.animate().cancel()
                                v.scaleX = 1f
                                v.scaleY = 1f
                                switchMode(dx < 0)
                            }
                        }
                    } else if (Math.abs(e.rawX - startX) > dp(70) || Math.abs(e.rawY - startY) > dp(70)) {
                        cancelled = true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    down = false
                    longRunnable?.let { handler.removeCallbacks(it) }
                    v.isPressed = false
                    pressAnim(v, false)
                    dismissPopupLater()
                    stopRepeat()
                    val wasCursor = cursorMode
                    cursorMode = false
                    if (!longFired && !cancelled && !wasCursor && !swiped) onKey(k) else afterKey()
                }
                MotionEvent.ACTION_CANCEL -> {
                    down = false
                    longRunnable?.let { handler.removeCallbacks(it) }
                    v.isPressed = false
                    pressAnim(v, false)
                    dismissPopupLater()
                    stopRepeat()
                    cursorMode = false
                }
            }
            true
        }
    }

    private fun handleLong(v: View, k: Key, hint: String?): Boolean {
        return when (k.type) {
            KeyType.DEL -> {
                startRepeat()
                true
            }
            KeyType.SPACE -> {
                commitAvro()
                cursorMode = true
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                true
            }
            KeyType.SHIFT -> {
                shift = Shift.CAPS
                autoShift = false
                build()
                true
            }
            KeyType.CHAR -> {
                if (hint != null) {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    dismissPopupNow()
                    onText(hint)
                    true
                } else false
            }
            else -> false
        }
    }

    @Suppress("DEPRECATION")
    private fun feedback(v: View, k: Key) {
        if (b("vibrate")) {
            val ms = n("vibMs")
            val vib = vibrator
            if (ms > 0 && vib != null) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    vib.vibrate(ms.toLong())
                }
            } else {
                v.performHapticFeedback(
                    HapticFeedbackConstants.KEYBOARD_TAP,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
            }
        }
        if (b("sound")) {
            val vol = n("soundVol")
            val fx = when (k.type) {
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.DEL -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio?.playSoundEffect(fx, if (vol == 0) -1f else vol / 100f)
        }
    }

    // কি চাপলে ওপরে ভেসে ওঠা বড় প্রিভিউ
    private fun showPopup(v: View, k: Key) {
        dismissPopupNow()
        if (!b("popup") || k.type != KeyType.CHAR) return
        try {
            val tv = TextView(this)
            tv.textSize = 28f
            tv.text = styled(labelOf(k), tv, true)
            tv.gravity = Gravity.CENTER
            tv.setTextColor(keyTextColor())
            val bg = GradientDrawable()
            bg.cornerRadius = dp(10).toFloat()
            bg.setColor(KeyStyle.opaque(style.key))
            bg.setStroke(dp(1), theme.accent)
            tv.background = bg
            val w = maxOf(v.width, dp(46))
            val h = dp(58)
            val p = PopupWindow(tv, w, h, false)
            p.isClippingEnabled = false
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            p.showAtLocation(v, Gravity.NO_GRAVITY, loc[0] + (v.width - w) / 2, loc[1] - h - dp(4))
            popup = p
        } catch (e: Exception) {
            popup = null
        }
    }

    private fun dismissPopupNow() {
        try { popup?.dismiss() } catch (e: Exception) { }
        popup = null
    }

    private fun dismissPopupLater() {
        val p = popup ?: return
        popup = null
        val ms = n("popupMs")
        handler.postDelayed({
            try { p.dismiss() } catch (e: Exception) { }
        }, if (ms == 0) 70L else ms.toLong())
    }

    // ------------------------------------------------------------------
    // লেবেল ও টেক্সট
    // ------------------------------------------------------------------
    private fun shiftOn() = shift != Shift.OFF && !symbols

    private fun enterLabel(): String {
        if (b("alwaysEnter")) return "↵"
        return when (imeAction) {
            EditorInfo.IME_ACTION_GO -> "যান"
            EditorInfo.IME_ACTION_SEARCH -> "খুঁজুন"
            EditorInfo.IME_ACTION_SEND -> "পাঠান"
            EditorInfo.IME_ACTION_NEXT -> "পরের"
            EditorInfo.IME_ACTION_DONE -> "শেষ"
            else -> "↵"
        }
    }

    private fun labelOf(k: Key): String = when (k.type) {
        KeyType.SHIFT -> if (shift == Shift.CAPS) "⇪" else "⇧"
        KeyType.DEL -> "⌫"
        KeyType.ENTER -> enterLabel()
        KeyType.SPACE ->
            if (LayoutPrefs.enabled(prefs).size > 1) "‹   ${Layouts.modeName(mode)}   ›"
            else Layouts.modeName(mode)
        KeyType.LANG -> "🌐"
        KeyType.EMOJI -> if (emojiOpen) "ABC" else "😊"
        KeyType.ABC -> "ABC"
        KeyType.SYM -> when {
            symbols -> "ABC"
            mode == Mode.PROBHAT -> "?১২৩"
            else -> "?123"
        }
        KeyType.PAD -> ""
        KeyType.CHAR -> display(outText(if (shiftOn()) k.s else k.n))
    }

    private fun display(t: String): String = t

    // ---- একা পড়ে থাকা বাংলা কার/চিহ্ন দেখানো ----
    // সমস্যার আসল কারণ: কার (ি ে ু ...) একা থাকলে ফোনের টেক্সট ইঞ্জিন নিজেই একটা ফাঁকা গোল (◌) বসিয়ে দেয়।
    // তাই কারের আগে একটা অদৃশ্য (স্বচ্ছ রঙের) ব্যঞ্জন বসানো হয়; ফলে কারটা স্বাভাবিকভাবে ব্যঞ্জনের সাথে
    // বসে আর কোনো গোল চিহ্ন আসে না। কির আসল আউটপুট (যে অক্ষর লেখা হয়) একটুও বদলায় না।
    private val markBefore = "িেৈ"          // ব্যঞ্জনের আগে বসে
    private val markAfter = "াীংঃ্"         // ব্যঞ্জনের পরে বসে
    private val markOther = "ুূৃঁোৌৗ"        // নিচে/ওপরে/দুই পাশে বসে

    private fun isBnMark(t: String): Boolean =
        t.length == 1 && (markBefore + markAfter + markOther).indexOf(t[0]) >= 0

    private fun styled(t: String, tv: TextView, center: Boolean): CharSequence {
        if (!isBnMark(t)) {
            if (center) tv.setPadding(0, 0, 0, 0)
            return t
        }
        val sp = SpannableString("ক" + t)
        sp.setSpan(ForegroundColorSpan(Color.TRANSPARENT), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (center) {
            // অদৃশ্য ব্যঞ্জনের জন্য জায়গা ছেড়ে কারটা কির মাঝামাঝি আনা
            val w = tv.paint.measureText("ক").toInt()
            when {
                markBefore.indexOf(t[0]) >= 0 -> tv.setPadding(w, 0, 0, 0)
                markAfter.indexOf(t[0]) >= 0 -> tv.setPadding(0, 0, w, 0)
                else -> tv.setPadding(0, 0, 0, 0)
            }
        }
        return sp
    }

    // বাংলা মোডে সংখ্যা ও ৳ চিহ্ন বাংলা হবে (নম্বর/ফোন ঘর ছাড়া)
    private fun outText(raw: String): String {
        if (mode == Mode.ENGLISH || latinDigits || raw.length != 1) return raw
        val c = raw[0]
        if (mode == Mode.ARABIC) return if (c in '0'..'9') ('٠' + (c - '0')).toString() else raw
        return when {
            c in '0'..'9' -> ('০' + (c - '0')).toString()
            c == '$' -> "৳"
            else -> raw
        }
    }

    // ------------------------------------------------------------------
    // কি চাপার কাজ
    // ------------------------------------------------------------------
    private fun onKey(k: Key) {
        handleKey(k)
        afterKey()
    }

    private fun afterKey() {
        updateAutoCap()
        updateSuggestions()
    }

    private fun handleKey(k: Key) {
        when (k.type) {
            KeyType.CHAR -> {
                val ed = editForPress(k)
                if (ed != null) {
                    editAction(ed)
                    return
                }
                onText(outText(if (shiftOn()) k.s else k.n))
                if (shift == Shift.ONE) {
                    shift = Shift.OFF
                    autoShift = false
                    build()
                }
            }
            KeyType.SHIFT -> toggleShift()
            KeyType.DEL -> doDelete()
            KeyType.ENTER -> doEnter()
            KeyType.SPACE -> doSpace()
            KeyType.LANG -> switchMode(true)
            KeyType.SYM -> {
                commitAvro()
                symbols = !symbols
                build()
            }
            KeyType.EMOJI -> {
                commitAvro()
                val was = emojiOpen
                closePanels()
                emojiOpen = !was
                toolbarOpen = false
                build()
            }
            KeyType.ABC -> {
                closePanels()
                build()
            }
            KeyType.PAD -> {}
        }
    }

    private fun onText(s: String) {
        val ic = currentInputConnection ?: return
        if (mode == Mode.AVRO && s.length == 1) {
            val ch = s[0]
            val isRoman = ch in 'a'..'z' || ch in 'A'..'Z'
            val isMod = ch == '^' || ch == ':' || ch == '`'
            if (isRoman || (isMod && buffer.isNotEmpty())) {
                buffer.append(ch)
                ic.setComposingText(AvroEngine.convert(buffer.toString()), 1)
                return
            }
            finishWord()
            ic.commitText(if (ch == '.') "।" else s, 1)
            return
        }
        ic.commitText(s, 1)
    }

    private fun commitAvro() {
        if (buffer.isEmpty()) return
        val word = AvroEngine.convert(buffer.toString())
        currentInputConnection?.commitText(word, 1)
        buffer.setLength(0)
        learnWord(word)
    }

    // শব্দ শেষ হলে (স্পেস/এন্টার/চিহ্ন) শব্দটা শিখে রাখা
    private fun finishWord() {
        val had = buffer.isNotEmpty()
        commitAvro()
        if (!had) {
            val w = currentWord()
            if (w.isNotEmpty()) learnWord(w)
        }
    }

    private fun learnWord(w: String) {
        if (w.length >= 2 && b("personal") && !b("incognito") && !passwordField) learn.add(w, lastWord)
        lastWord = w
    }

    private val wordRe = Regex("[\\p{L}\\p{M}]+$")

    private fun currentWord(): String {
        val t = currentInputConnection?.getTextBeforeCursor(32, 0) ?: return ""
        return wordRe.find(t)?.value ?: ""
    }

    private fun isWordChar(c: Char): Boolean =
        c.isLetterOrDigit() ||
                Character.getType(c) == Character.NON_SPACING_MARK.toInt() ||
                Character.getType(c) == Character.COMBINING_SPACING_MARK.toInt()

    private fun doSpace() {
        val ic0 = currentInputConnection
        if (ic0 != null && buffer.isEmpty() && !passwordField) {
            val w = currentWord()
            val exp = if (w.isNotEmpty()) Snippets.get(prefs, w) else null
            if (exp != null) {
                ic0.deleteSurroundingText(w.length, 0)
                ic0.commitText("$exp ", 1)
                lastWord = null
                return
            }
        }
        finishWord()
        val ic = currentInputConnection ?: return
        if (b("dblSpaceDot") || b("dblSpaceTab")) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' && isWordChar(before[0])) {
                ic.deleteSurroundingText(1, 0)
                if (b("dblSpaceDot")) {
                    ic.commitText(if (mode == Mode.PROBHAT || mode == Mode.AVRO) "। " else ". ", 1)
                } else {
                    ic.commitText("\t", 1)
                }
                lastWord = null
                return
            }
        }
        ic.commitText(" ", 1)
    }

    private fun doEnter() {
        finishWord()
        lastWord = null
        if (!sendDefaultEditorAction(true)) sendKeyChar('\n')
    }

    private fun doDelete() {
        val ic = currentInputConnection ?: return
        if (buffer.isNotEmpty()) {
            buffer.setLength(buffer.length - 1)
            if (buffer.isEmpty()) ic.commitText("", 1)
            else ic.setComposingText(AvroEngine.convert(buffer.toString()), 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun startRepeat() {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                doDelete()
                handler.postDelayed(this, 50)
            }
        }
        repeatRunnable = r
        handler.post(r)
    }

    private fun stopRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    private fun toggleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.ONE && now - lastShiftTap < 400 -> Shift.CAPS
            shift == Shift.OFF -> Shift.ONE
            else -> Shift.OFF
        }
        autoShift = false
        lastShiftTap = now
        build()
    }

    // forward = true: পরের লেআউট, false: আগের লেআউট (শুধু বেছে নেওয়া লেআউটগুলোর মধ্যে)
    private fun switchMode(forward: Boolean) {
        commitAvro()
        val list = LayoutPrefs.enabled(prefs)
        if (list.size < 2) return
        val idx = list.indexOf(mode).let { if (it < 0) 0 else it }
        val next = if (forward) (idx + 1) % list.size else (idx - 1 + list.size) % list.size
        mode = list[next]
        shift = Shift.OFF
        autoShift = false
        if (!passwordField) prefs.edit().putString("mode", mode.name).apply()
        build()
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ------------------------------------------------------------------
    // অটো-ক্যাপিটালাইজেশন (ইংরেজি মোডে)
    // ------------------------------------------------------------------
    private fun updateAutoCap() {
        if (mode != Mode.ENGLISH || symbols || panelOpen() || !b("autoCap") || shift == Shift.CAPS) return
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) != 0
        if (caps && shift == Shift.OFF) {
            shift = Shift.ONE
            autoShift = true
            build()
        } else if (!caps && shift == Shift.ONE && autoShift) {
            shift = Shift.OFF
            autoShift = false
            build()
        }
    }

    // ------------------------------------------------------------------
    // সাজেশন বার
    // ------------------------------------------------------------------
    private val exprRe = Regex("([0-9]+(?:\\.[0-9]+)?(?:[+\\-*/×÷][0-9]+(?:\\.[0-9]+)?)+)$")

    private fun calcSuggestion(): String? {
        if (!b("calcSuggest") || passwordField) return null
        val t = currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: return null
        val m = exprRe.find(t) ?: return null
        val r = Calc.eval(m.value) ?: return null
        return "= " + Calc.format(r)
    }

    private fun computeSuggestions(): List<String> {
        if (passwordField) return emptyList()
        val out = LinkedHashSet<String>()
        calcSuggestion()?.let { out.add(it) }
        val cur: String
        if (mode == Mode.AVRO && buffer.isNotEmpty()) {
            cur = AvroEngine.convert(buffer.toString())
            if (b("typedFirst")) out.add(cur)
        } else {
            cur = currentWord()
        }
        if (cur.isNotEmpty()) {
            if (b("personal") && !b("incognito")) out.addAll(learn.complete(cur, 3))
            out.addAll(Dict.complete(cur, mode == Mode.ENGLISH, 4))
        } else if (b("nextWord") && b("personal") && !b("incognito")) {
            lastWord?.let { out.addAll(learn.next(it, 3)) }
        }
        return out.take(3)
    }

    private fun updateSuggestions() {
        if (sugViews.isEmpty()) return
        val list = if (panelOpen()) emptyList() else try {
            computeSuggestions()
        } catch (e: Exception) {
            emptyList()
        }
        currentSuggestions = list
        for (i in sugViews.indices) {
            sugViews[i].text = when {
                i < list.size -> list[i]
                list.isEmpty() && i == 0 -> Layouts.modeName(mode)
                else -> ""
            }
        }
    }

    private fun pickSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        if (s.startsWith("= ")) {
            ic.commitText("=" + s.substring(2), 1)
            afterKey()
            return
        }
        if (mode == Mode.AVRO && buffer.isNotEmpty()) {
            buffer.setLength(0)
            ic.commitText("$s ", 1)
        } else {
            val cur = currentWord()
            if (cur.isNotEmpty()) ic.deleteSurroundingText(cur.length, 0)
            ic.commitText("$s ", 1)
        }
        learnWord(s)
        afterKey()
    }

    // ------------------------------------------------------------------
    // ইমোজি ও চিহ্ন প্যানেল
    // ------------------------------------------------------------------
    private fun emojiPanel(): View =
        gridPanel(Emojis.cats, emojiCat, { emojiCat = it }, 24f, Key("", "", KeyType.EMOJI, 1.5f))

    private fun symbolPanel(): View =
        gridPanel(SymbolSets.cats, symCat, { symCat = it }, 22f, Key("", "", KeyType.ABC, 1.5f))

    private fun gridPanel(
        cats: List<Pair<String, List<String>>>,
        cur: Int,
        setCur: (Int) -> Unit,
        size: Float,
        closeKey: Key
    ): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        cats.forEachIndexed { i, c ->
            val t = TextView(this)
            t.text = c.first
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.setTextColor(textColor())
            if (i == cur) t.setBackgroundColor(Color.argb(60, 128, 128, 128))
            t.setOnClickListener {
                setCur(i)
                build()
            }
            tabs.addView(t, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        col.addView(tabs)

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in cats[cur].second.chunked(8)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until 8) {
                val tv = TextView(this)
                tv.gravity = Gravity.CENTER
                tv.textSize = size
                tv.setTextColor(textColor())
                if (j < chunk.size) {
                    val e = chunk[j]
                    tv.text = e
                    tv.setOnClickListener {
                        commitAvro()
                        currentInputConnection?.commitText(e, 1)
                    }
                }
                row.addView(tv, LinearLayout.LayoutParams(0, dp(44), 1f))
            }
            grid.addView(row)
        }
        val sv = ScrollView(this)
        sv.addView(grid)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)))

        col.addView(
            rowView(
                listOf(closeKey, Key("", "", KeyType.SPACE, 5f), Key("", "", KeyType.DEL, 1.5f)),
                rowHeight(false)
            )
        )
        return col
    }

    // ------------------------------------------------------------------
    // কপি / কাট / পেস্ট ও ক্লিপবোর্ড
    // ------------------------------------------------------------------
    // এডিটরে এখন সত্যিই লেখা সিলেক্ট করা আছে কি না (সরাসরি জিজ্ঞেস করা, শুধু মনে রাখা অবস্থার ওপর নির্ভর নয়)
    private fun hasSelectionNow(): Boolean {
        val ic = currentInputConnection ?: return false
        return try {
            !ic.getSelectedText(0).isNullOrEmpty()
        } catch (e: Exception) {
            false
        }
    }

    private fun editActive(): Boolean =
        !passwordField && (editMode || (b("autoEdit") && selectionActive))

    // কি চাপার মুহূর্তে: লেখা সিলেক্ট থাকলে c/x/v/a কপি-কাট-পেস্ট-সব সিলেক্ট হয়
    private fun editFor(k: Key): String? {
        if (k.type != KeyType.CHAR || symbols || k.ed == null || passwordField) return null
        if (editActive()) return k.ed
        return null
    }

    private fun editForPress(k: Key): String? {
        val cached = editFor(k)
        if (cached != null) return cached
        if (k.type == KeyType.CHAR && !symbols && k.ed != null && !passwordField &&
            b("autoEdit") && hasSelectionNow()
        ) return k.ed
        return null
    }

    private fun edLabel(ed: String): String = when (ed) {
        "copy" -> "কপি"
        "cut" -> "কাট"
        "paste" -> "পেস্ট"
        else -> "সব"
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    private fun copyToClip(text: String) {
        try {
            clipboard?.setPrimaryClip(ClipData.newPlainText("text", text))
        } catch (e: Exception) {
        }
        if (b("clipHistory") && !b("incognito")) clips.add(text)
    }

    private fun editAction(ed: String) {
        val ic = currentInputConnection ?: return
        commitAvro()
        when (ed) {
            "selectAll" -> {
                if (!ic.performContextMenuAction(android.R.id.selectAll)) toast("এই জায়গায় সব সিলেক্ট করা যায়নি")
            }
            "paste" -> {
                var t: String? = null
                try {
                    t = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
                } catch (e: Exception) {
                }
                if (t.isNullOrEmpty()) t = clips.list().firstOrNull()?.text
                if (!t.isNullOrEmpty()) {
                    ic.commitText(t, 1)
                } else if (!ic.performContextMenuAction(android.R.id.paste)) {
                    toast("ক্লিপবোর্ড খালি")
                }
            }
            else -> {
                val sel = try { ic.getSelectedText(0)?.toString() } catch (e: Exception) { null }
                if (!sel.isNullOrEmpty()) {
                    copyToClip(sel)
                    if (ed == "cut") {
                        // প্রথমে এডিটরের নিজের কাট, না হলে সিলেক্ট করা অংশ মুছে ফেলা
                        if (!ic.performContextMenuAction(android.R.id.cut)) ic.commitText("", 1)
                    }
                    toast(if (ed == "cut") "কাট হয়েছে" else "কপি হয়েছে")
                } else {
                    // কিছু এডিটর (যেমন ব্রাউজার) লেখা ফেরত দেয় না, কিন্তু নিজে কপি-কাট করতে পারে
                    val id = if (ed == "cut") android.R.id.cut else android.R.id.copy
                    if (selectionActive && ic.performContextMenuAction(id)) {
                        toast(if (ed == "cut") "কাট হয়েছে" else "কপি হয়েছে")
                    } else {
                        toast("আগে লেখা সিলেক্ট করুন")
                    }
                }
            }
        }
    }

    private fun clipPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "ক্লিপবোর্ড · চাপলে পেস্ট হবে, 📌 দিয়ে পিন করুন"
        title.textSize = 12f
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        title.setTextColor(textColor())
        title.setPadding(dp(8), 0, 0, 0)
        head.addView(title, LinearLayout.LayoutParams(0, dp(34), 1f))
        val clear = TextView(this)
        clear.text = "সব মুছুন"
        clear.textSize = 12f
        clear.gravity = Gravity.CENTER
        clear.setTextColor(if (photo) Color.parseColor("#FFD54F") else theme.accent)
        clear.setPadding(dp(10), 0, dp(10), 0)
        clear.setOnClickListener {
            clips.clearUnpinned()
            build()
        }
        head.addView(clear, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        col.addView(head)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val list = clips.list()
        if (list.isEmpty()) {
            val empty = TextView(this)
            empty.text = "এখনো কিছু কপি করা হয়নি।\nকোনো লেখা কপি বা কাট করলে এখানে জমা হবে।"
            empty.textSize = 14f
            empty.gravity = Gravity.CENTER
            empty.setTextColor(textColor())
            empty.setPadding(dp(12), dp(36), dp(12), 0)
            box.addView(empty)
        }
        for (c in list) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable()
            bg.cornerRadius = dp(8).toFloat()
            bg.setColor(style.key)
            if (c.pinned) bg.setStroke(dp(1), theme.accent)
            row.background = bg

            val tv = TextView(this)
            tv.text = c.text
            tv.textSize = 14f
            tv.maxLines = 2
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setTextColor(keyTextColor())
            tv.setPadding(dp(10), dp(8), dp(6), dp(8))
            tv.setOnClickListener {
                commitAvro()
                currentInputConnection?.commitText(c.text, 1)
            }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val pin = TextView(this)
            pin.text = "📌"
            pin.textSize = 18f
            pin.alpha = if (c.pinned) 1f else 0.3f
            pin.setPadding(dp(8), dp(8), dp(8), dp(8))
            pin.setOnClickListener {
                clips.togglePin(c)
                build()
            }
            row.addView(pin)

            val del = TextView(this)
            del.text = "✕"
            del.textSize = 16f
            del.setTextColor(keyTextColor())
            del.setPadding(dp(8), dp(8), dp(12), dp(8))
            del.setOnClickListener {
                clips.delete(c)
                build()
            }
            row.addView(del)

            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            box.addView(row, lp)
        }
        val sv = ScrollView(this)
        sv.addView(box)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)))

        col.addView(
            rowView(
                listOf(
                    Key("", "", KeyType.ABC, 1.5f),
                    Key("", "", KeyType.SPACE, 5f),
                    Key("", "", KeyType.DEL, 1.5f)
                ),
                rowHeight(false)
            )
        )
        return col
    }

    // ------------------------------------------------------------------
    // টুলবক্স: সম্পাদনা, ক্যালকুলেটর, টেক্সট টুল, তারিখ-সময়, পাসওয়ার্ড, স্নিপেট
    // ------------------------------------------------------------------
    private fun sendKey(code: Int, meta: Int = 0) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun withIc(f: (InputConnection) -> Unit) {
        val ic = currentInputConnection ?: return
        commitAvro()
        f(ic)
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.setTextColor(keyTextColor())
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(style.key)
        t.background = bg
        t.setOnClickListener { onClick() }
        return t
    }

    private fun chipRow(vararg chips: TextView): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (c in chips) {
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            row.addView(c, lp)
        }
        return row
    }

    // কার্সরের আগের/পরের শব্দের দৈর্ঘ্য
    private fun wordSpan(forward: Boolean): Int {
        val ic = currentInputConnection ?: return 0
        if (!forward) {
            val t = ic.getTextBeforeCursor(80, 0)?.toString() ?: return 0
            var i = t.length
            while (i > 0 && t[i - 1].isWhitespace()) i--
            if (i > 0) {
                if (isWordChar(t[i - 1])) {
                    while (i > 0 && isWordChar(t[i - 1])) i--
                } else i--
            }
            return t.length - i
        }
        val t = ic.getTextAfterCursor(80, 0)?.toString() ?: return 0
        var i = 0
        while (i < t.length && t[i].isWhitespace()) i++
        if (i < t.length) {
            if (isWordChar(t[i])) {
                while (i < t.length && isWordChar(t[i])) i++
            } else i++
        }
        return i
    }

    private fun moveWord(forward: Boolean, select: Boolean) {
        commitAvro()
        val n = wordSpan(forward)
        val meta = if (select) KeyEvent.META_SHIFT_ON else 0
        val code = if (forward) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        repeat(n) { sendKey(code, meta) }
    }

    private fun deleteWord(forward: Boolean) {
        commitAvro()
        val ic = currentInputConnection ?: return
        val n = wordSpan(forward)
        if (n <= 0) return
        if (forward) ic.deleteSurroundingText(0, n) else ic.deleteSurroundingText(n, 0)
    }

    private fun targetText(): Pair<String, Boolean>? {
        val ic = currentInputConnection ?: return null
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) return Pair(sel, true)
        val all = ic.getExtractedText(ExtractedTextRequest(), 0)?.text?.toString()
        if (!all.isNullOrEmpty()) return Pair(all, false)
        return null
    }

    private fun transform(f: (String) -> String) {
        commitAvro()
        val ic = currentInputConnection ?: return
        val tgt = targetText()
        if (tgt == null) {
            toast("কোনো লেখা পাওয়া যায়নি। আগে লেখা সিলেক্ট করুন")
            return
        }
        val out = f(tgt.first)
        if (!tgt.second) ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText(out, 1)
    }

    private fun titleCase(t: String): String =
        t.split(" ").joinToString(" ") { w ->
            if (w.isEmpty()) w else w.substring(0, 1).uppercase() + w.substring(1).lowercase()
        }

    private fun sentenceCase(t: String): String {
        val sb = StringBuilder(t.lowercase())
        var cap = true
        for (i in sb.indices) {
            val c = sb[i]
            if (cap && c.isLetter()) {
                sb.setCharAt(i, c.uppercaseChar())
                cap = false
            }
            if (c == '.' || c == '!' || c == '?' || c == '\n') cap = true
        }
        return sb.toString()
    }

    private fun countStats() {
        val t = targetText()?.first ?: ""
        val words = t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val minutes = if (words == 0) 0 else maxOf(1, Math.ceil(words / 200.0).toInt())
        countText = "শব্দ: $words · অক্ষর: ${t.length} · পড়ার সময়: ~$minutes মিনিট"
        build()
    }

    private fun insertText(t: String) {
        commitAvro()
        currentInputConnection?.commitText(t, 1)
    }

    private fun insertDate() {
        val f = arrayOf("dd/MM/yyyy", "dd-MM-yyyy", "yyyy-MM-dd", "d MMMM yyyy")[n("dateFmt").coerceIn(0, 3)]
        insertText(SimpleDateFormat(f, Locale.getDefault()).format(Date()))
    }

    private fun insertTime() {
        val f = arrayOf("hh:mm a", "HH:mm")[n("timeFmt").coerceIn(0, 1)]
        insertText(SimpleDateFormat(f, Locale.getDefault()).format(Date()))
    }

    private fun genPassword(len: Int): String {
        val sets = listOf("abcdefghijkmnopqrstuvwxyz", "ABCDEFGHJKLMNPQRSTUVWXYZ", "23456789", "!@#\$%^&*-_=+?")
        val all = sets.joinToString("")
        val r = SecureRandom()
        val chars = ArrayList<Char>()
        for (st in sets) chars.add(st[r.nextInt(st.length)])
        while (chars.size < len) chars.add(all[r.nextInt(all.length)])
        chars.shuffle(r)
        return chars.joinToString("")
    }

    private fun calcPress(label: String) {
        when (label) {
            "C" -> {
                calcExpr = ""
                calcResult = ""
            }
            "⌫" -> {
                if (calcExpr.isNotEmpty()) calcExpr = calcExpr.dropLast(1)
                calcResult = ""
            }
            "=" -> {
                val r = Calc.eval(calcExpr)
                calcResult = if (r == null) "ভুল" else Calc.format(r)
            }
            else -> {
                if (calcResult.isNotEmpty() && label[0].isDigit()) calcExpr = ""
                calcResult = ""
                calcExpr += label
            }
        }
        build()
    }

    private fun toolsPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val names = listOf("✏ সম্পাদনা", "🧮 হিসাব", "Aa টেক্সট", "⚡ আরও")
        names.forEachIndexed { i, nm ->
            val t = TextView(this)
            t.text = nm
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.setTextColor(textColor())
            if (i == toolsTab) t.setBackgroundColor(Color.argb(60, 128, 128, 128))
            t.setOnClickListener {
                toolsTab = i
                build()
            }
            tabs.addView(t, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        col.addView(tabs)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        when (toolsTab) {
            0 -> fillEdit(box)
            1 -> fillCalc(box)
            2 -> fillText(box)
            else -> fillMore(box)
        }
        val sv = ScrollView(this)
        sv.addView(box)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)))

        col.addView(
            rowView(
                listOf(
                    Key("", "", KeyType.ABC, 1.5f),
                    Key("", "", KeyType.SPACE, 5f),
                    Key("", "", KeyType.DEL, 1.5f)
                ),
                rowHeight(false)
            )
        )
        return col
    }

    private fun fillEdit(box: LinearLayout) {
        box.addView(chipRow(
            chip("সব সিলেক্ট") { withIc { it.performContextMenuAction(android.R.id.selectAll) } },
            chip("কপি") { editAction("copy") },
            chip("কাট") { editAction("cut") },
            chip("পেস্ট") { editAction("paste") }
        ))
        box.addView(chipRow(
            chip("আনডু") {
                withIc { if (!it.performContextMenuAction(android.R.id.undo)) toast("এখানে আনডু সমর্থিত নয়") }
            },
            chip("রিডু") {
                withIc { if (!it.performContextMenuAction(android.R.id.redo)) toast("এখানে রিডু সমর্থিত নয়") }
            },
            chip("◀ কার্সর") { commitAvro(); sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT) },
            chip("কার্সর ▶") { commitAvro(); sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT) }
        ))
        box.addView(chipRow(
            chip("◀ শব্দ") { moveWord(false, false) },
            chip("শব্দ ▶") { moveWord(true, false) },
            chip("লাইনের শুরু") { commitAvro(); sendDownUpKeyEvents(KeyEvent.KEYCODE_MOVE_HOME) },
            chip("লাইনের শেষ") { commitAvro(); sendDownUpKeyEvents(KeyEvent.KEYCODE_MOVE_END) }
        ))
        box.addView(chipRow(
            chip("আগের শব্দ সিলেক্ট") { moveWord(false, true) },
            chip("পরের শব্দ সিলেক্ট") { moveWord(true, true) },
            chip("আগের শব্দ মুছুন") { deleteWord(false) },
            chip("পরের শব্দ মুছুন") { deleteWord(true) }
        ))
    }

    private fun fillCalc(box: LinearLayout) {
        val disp = TextView(this)
        disp.textSize = 20f
        disp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        disp.setTextColor(textColor())
        disp.setPadding(dp(10), dp(4), dp(10), dp(4))
        disp.text = if (calcExpr.isEmpty()) "0" else calcExpr + (if (calcResult.isNotEmpty()) "  = $calcResult" else "")
        box.addView(disp)

        fun key(label: String): TextView = chip(label) { calcPress(label) }
        box.addView(chipRow(key("C"), key("⌫"), key("%"), key("÷")))
        box.addView(chipRow(key("7"), key("8"), key("9"), key("×")))
        box.addView(chipRow(key("4"), key("5"), key("6"), key("−")))
        box.addView(chipRow(key("1"), key("2"), key("3"), key("+")))
        box.addView(chipRow(
            key("0"), key("."), key("="),
            chip("ঢোকান") {
                val r = if (calcResult.isNotEmpty() && calcResult != "ভুল") calcResult
                else Calc.eval(calcExpr)?.let { Calc.format(it) }
                if (r != null) insertText(r) else toast("আগে হিসাব করুন")
            }
        ))
    }

    private fun fillText(box: LinearLayout) {
        box.addView(chipRow(
            chip("ABC বড় হাতের") { transform { it.uppercase() } },
            chip("abc ছোট হাতের") { transform { it.lowercase() } },
            chip("Title Case") { transform { titleCase(it) } },
            chip("Sentence case") { transform { sentenceCase(it) } }
        ))
        box.addView(chipRow(
            chip("বাড়তি স্পেস সরান") {
                transform { it.replace(Regex("[ \\t]{2,}"), " ").replace(Regex(" +\\n"), "\n").trim() }
            },
            chip("ফাঁকা লাইন সরান") { transform { it.replace(Regex("\\n{2,}"), "\n") } },
            chip("গণনা করুন") { countStats() }
        ))
        val info = TextView(this)
        info.textSize = 13f
        info.setTextColor(textColor())
        info.setPadding(dp(10), dp(6), dp(10), dp(4))
        info.text = if (countText.isEmpty()) "সিলেক্ট করা লেখা (না থাকলে পুরো লেখা) নিয়ে কাজ হয়" else countText
        box.addView(info)
    }

    private fun fillMore(box: LinearLayout) {
        box.addView(chipRow(
            chip("আজকের তারিখ") { insertDate() },
            chip("এখনকার সময়") { insertTime() }
        ))
        val lens = listOf(8, 12, 16, 20)
        val lenChips = lens.map { l ->
            chip(if (l == pwLen) "✓ $l" else "$l") {
                pwLen = l
                build()
            }
        }
        box.addView(chipRow(*lenChips.toTypedArray()))
        box.addView(chipRow(
            chip("পাসওয়ার্ড তৈরি করুন") {
                pwText = genPassword(pwLen)
                build()
            },
            chip("ঢোকান") { if (pwText.isNotEmpty()) insertText(pwText) else toast("আগে তৈরি করুন") }
        ))
        if (pwText.isNotEmpty()) {
            val tv = TextView(this)
            tv.text = pwText
            tv.textSize = 16f
            tv.typeface = Typeface.MONOSPACE
            tv.gravity = Gravity.CENTER
            tv.setTextColor(textColor())
            tv.setPadding(dp(8), dp(4), dp(8), dp(4))
            box.addView(tv)
        }

        val head = TextView(this)
        head.text = "স্নিপেট (চাপলে বসে; শর্টকাট লিখে স্পেস দিলেও বসে)"
        head.textSize = 12f
        head.setTextColor(textColor())
        head.setPadding(dp(10), dp(8), dp(10), dp(2))
        box.addView(head)
        val list = Snippets.all(prefs)
        if (list.isEmpty()) {
            val e = TextView(this)
            e.text = "কোনো স্নিপেট নেই। সেটিংস → টুলবক্স ও গোপনীয়তা থেকে যোগ করুন।"
            e.textSize = 12f
            e.setTextColor(textColor())
            e.setPadding(dp(10), dp(2), dp(10), dp(6))
            box.addView(e)
        }
        for ((k, v) in list) {
            val c = chip("$k → ${v.take(24)}") { insertText(v) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            box.addView(c, lp)
        }
    }
}

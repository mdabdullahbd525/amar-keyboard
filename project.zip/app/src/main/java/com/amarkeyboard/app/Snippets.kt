package com.amarkeyboard.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** টেক্সট এক্সপ্যানশন: শর্টকাট লিখে স্পেস দিলে পুরো লেখা বসে যায় */
object Snippets {
    fun all(p: SharedPreferences): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val a = JSONArray(p.getString("snippets", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Pair(o.getString("k"), o.getString("v")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(p: SharedPreferences, list: List<Pair<String, String>>) {
        val a = JSONArray()
        for ((k, v) in list) {
            val o = JSONObject()
            o.put("k", k)
            o.put("v", v)
            a.put(o)
        }
        p.edit().putString("snippets", a.toString()).apply()
    }

    fun add(p: SharedPreferences, k: String, v: String) {
        save(p, all(p).filter { it.first != k } + Pair(k, v))
    }

    fun remove(p: SharedPreferences, k: String) {
        save(p, all(p).filter { it.first != k })
    }

    fun get(p: SharedPreferences, k: String): String? = all(p).firstOrNull { it.first == k }?.second
}

package com.amarkeyboard.app

sealed class Item {
    class Toggle(val key: String, val title: String, val desc: String? = null, val dep: String? = null) : Item()
    class Seek(
        val key: String, val title: String,
        val min: Int, val max: Int, val step: Int, val unit: String, val dep: String? = null
    ) : Item()
    class Choice(
        val key: String, val title: String,
        val labels: List<String>, val values: List<Int>, val dep: String? = null
    ) : Item()
    class Action(val id: String, val title: String, val desc: String? = null) : Item()
}

class Page(val title: String, val items: List<Item>)

object SettingsSpecs {
    val pages: List<Page> = listOf(
        Page(
            "পছন্দসমূহ", listOf(
                Item.Toggle("autoCap", "অটো-ক্যাপিটালাইজেশন", "ইংরেজিতে প্রতিটি বাক্যের প্রথম শব্দ বড় হাতের হবে"),
                Item.Toggle("dblSpaceDot", "দুইবার-স্পেসে ডট", "স্পেসবার দুইবার চাপলে স্পেসের পরিবর্তে ডট (বাংলায় দাঁড়ি) যুক্ত হবে"),
                Item.Toggle("dblSpaceTab", "দুইবার-স্পেসে ট্যাব", "স্পেসবার দুইবার চাপলে একটি ট্যাব বসবে"),
                Item.Toggle("vibrate", "কীপ্রেস এর সময় ভাইব্রেশন"),
                Item.Toggle("sound", "কীপ্রেস এর সময়ের শব্দ"),
                Item.Toggle("popup", "কীপ্রেস এর ফলে পপআপ", "কি চাপলে ওপরে বড় করে অক্ষর দেখাবে"),
                Item.Toggle("emojiBtn", "ইমোজি বাটন", "কিবোর্ডে ইমোজি বাটন দেখাবে"),
                Item.Toggle("globeBtn", "গ্লোব বাটন", "কিবোর্ডে গ্লোব বাটন দেখাবে যা দিয়ে কিবোর্ডের লেআউট পরিবর্তন করা যাবে"),
                Item.Toggle("otherKb", "অন্যান্য কিবোর্ডে যাওয়া", "শেষ লেআউটের পরে গ্লোব বাটন অন্য কিবোর্ডে পরিবর্তন করবে", dep = "globeBtn"),
                Item.Toggle(
                    "autoEdit", "লেখা সিলেক্ট থাকলে কপি-কাট-পেস্ট",
                    "লেখা সিলেক্ট করা থাকলে c = কপি, x = কাট, v = পেস্ট, a = সব সিলেক্ট। ওপরের মেনুর ✂ বাটনে এটা সবসময়ের জন্য চালু করা যায়"
                ),
                Item.Toggle(
                    "clipHistory", "কপি করা লেখা ক্লিপবোর্ডে জমানো",
                    "কপি বা কাট করা লেখা ক্লিপবোর্ড তালিকায় থাকবে। পাসওয়ার্ড-জাতীয় সংবেদনশীল লেখা জমানো হয় না"
                ),
                Item.Toggle("volCursor", "ভলিউম কার্সর", "কার্সর সরাতে ভলিউম বাটন ব্যবহার"),
                Item.Toggle("volCursorMusicOff", "অডিও চলাকালীন ভলিউম কার্সর বন্ধ", "গান বা ভিডিও চলার সময় ভলিউম কী দিয়ে কার্সর সরানো বন্ধ থাকবে", dep = "volCursor")
            )
        ),
        Page(
            "চেহারা ও লে-আউট", listOf(
                Item.Toggle("numRow", "নম্বর সারি চালু করুন", "একটি অতিরিক্ত সারি যোগ হবে"),
                Item.Toggle("bigNumRow", "বড় নম্বর সারি", dep = "numRow"),
                Item.Toggle("hideHints", "লং প্রেস হিন্ট লুকান", "পরিচ্ছন্ন চেহারার জন্য কি-এর কোণে থাকা ছোট লেখা লুকান"),
                Item.Toggle("heightCustom", "কিবোর্ড উচ্চতা পরিবর্তন"),
                Item.Seek("heightP", "কিবোর্ডের উচ্চতা (পোর্ট্রেট)", 50, 130, 5, "%", dep = "heightCustom"),
                Item.Seek("heightL", "কিবোর্ডের উচ্চতা (ল্যান্ডস্কেপ)", 50, 130, 5, "%", dep = "heightCustom"),
                Item.Seek("ohP", "এক হাতে কিবোর্ডের প্রস্থ (পোর্ট্রেট)", 40, 100, 5, "%"),
                Item.Seek("ohL", "এক হাতে কিবোর্ডের প্রস্থ (ল্যান্ডস্কেপ)", 30, 100, 5, "%"),
                Item.Toggle("split", "স্প্লিট কিবোর্ড চালু", "ল্যান্ডস্কেপে কিবোর্ড মাঝখানে ভাগ হবে"),
                Item.Toggle("foldable", "ভাঁজযোগ্য ফোনের জন্য স্প্লিট কিবোর্ড চালু করুন", "বড় স্ক্রিনে পোর্ট্রেটেও স্প্লিট হবে"),
                Item.Toggle("alwaysEnter", "সব সময় এন্টার বাটন", "এন্টার বাটনে কাজের নাম (যান, খুঁজুন ইত্যাদি) না দেখিয়ে সবসময় ↵ দেখাবে")
            )
        ),
        Page(
            "লেখা সংশোধন", listOf(
                Item.Toggle("showSuggest", "পরামর্শগুলো দেখাবে", "লেখার সময় প্রস্তাবিত শব্দের প্রদর্শন"),
                Item.Toggle("personal", "ব্যক্তিগতকৃত পরামর্শ", "আপনার টাইপ করা শব্দ থেকে শিখবে। সব ডেটা ফোনের ভেতরেই থাকে"),
                Item.Toggle("nextWord", "পরবর্তী-শব্দের জন্য পরামর্শ", "পূর্ববর্তী শব্দ অনুযায়ী পরবর্তী শব্দের পরামর্শ দেওয়া হবে", dep = "personal"),
                Item.Action("clearLearned", "শেখা শব্দ মুছে ফেলুন", "কিবোর্ডের শেখা সব শব্দ ও পরামর্শ মুছে যাবে")
            )
        ),
        Page(
            "টুলবক্স ও গোপনীয়তা", listOf(
                Item.Toggle("incognito", "ইনকগনিটো মোড", "চালু থাকলে কিছুই শেখা বা ক্লিপবোর্ডে জমানো হয় না। ☰ মেনুর 🕶 বাটনেও চালু করা যায়"),
                Item.Toggle("calcSuggest", "ক্যালকুলেটর সাজেশন", "250+350 লিখলে সাজেশন বারে উত্তর (= 600) দেখাবে"),
                Item.Choice(
                    "dateFmt", "তারিখের ধরন",
                    listOf("dd/MM/yyyy", "dd-MM-yyyy", "yyyy-MM-dd", "d MMMM yyyy"),
                    listOf(0, 1, 2, 3)
                ),
                Item.Choice("timeFmt", "সময়ের ধরন", listOf("hh:mm a (১২ ঘণ্টা)", "HH:mm (২৪ ঘণ্টা)"), listOf(0, 1)),
                Item.Action("addSnippet", "নতুন স্নিপেট যোগ করুন", "শর্টকাট লিখে স্পেস দিলে পুরো লেখা বসবে"),
                Item.Action("manageSnippets", "স্নিপেট মুছুন"),
                Item.Action("clearClips", "ক্লিপবোর্ড ইতিহাস মুছুন", "পিন করা লেখাসহ সব মুছে যাবে"),
                Item.Action("privacyInfo", "গোপনীয়তা: কী জমা থাকে?")
            )
        ),
        Page(
            "উচ্চতর সেটিংস", listOf(
                Item.Choice(
                    "popupMs", "কী পপআপ বন্ধ করার সময়",
                    listOf("স্বাভাবিক", "০.১ সেকেন্ড", "০.২ সেকেন্ড", "০.৪ সেকেন্ড", "০.৭ সেকেন্ড"),
                    listOf(0, 100, 200, 400, 700), dep = "popup"
                ),
                Item.Choice(
                    "vibMs", "কীপ্রেস ভাইব্রেশন সময়কাল",
                    listOf("সিস্টেম ডিফল্ট", "১০ মিলি.সে.", "২০ মিলি.সে.", "৩০ মিলি.সে.", "৫০ মিলি.সে.", "৮০ মিলি.সে."),
                    listOf(0, 10, 20, 30, 50, 80), dep = "vibrate"
                ),
                Item.Choice(
                    "soundVol", "কীপ্রেস সাউন্ড ভলিউম",
                    listOf("সিস্টেম ডিফল্ট", "২০%", "৪০%", "৬০%", "৮০%", "১০০%"),
                    listOf(0, 20, 40, 60, 80, 100), dep = "sound"
                ),
                Item.Seek("longPressMs", "লং কী-প্রেসের দীর্ঘতা", 150, 800, 50, " মিলি.সে."),
                Item.Seek("spaceDelay", "স্পেস কার্সর লং প্রেস বিলম্ব", 300, 2000, 100, " মিলি.সে."),
                Item.Seek("spaceSpeed", "স্পেস কার্সর গতি", 50, 300, 10, ""),
                Item.Toggle("typedFirst", "টাইপ করা শব্দ দেখান", "ফোনেটিক মোডে প্রথম সাজেশন হিসেবে টাইপ করা শব্দ দেখান")
            )
        )
    )

    val aboutText =
        "আমার কিবোর্ড\nভার্সন ১.০\n\n" +
                "ইংরেজি, ফোনেটিক (Avro-ধাঁচ) ও প্রভাত লেআউট।\n" +
                "কোনো বিজ্ঞাপন নেই, সাবস্ক্রিপশন নেই, ইন্টারনেট পারমিশনও নেই। আপনার টাইপ করা সব কিছু শুধু আপনার ফোনেই থাকে।"
}

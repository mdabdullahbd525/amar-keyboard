package com.amarkeyboard.app

enum class Mode { ENGLISH, AVRO, PROBHAT, ARABIC }
enum class Shift { OFF, ONE, CAPS }
enum class KeyType { CHAR, SHIFT, DEL, ENTER, SPACE, LANG, SYM, EMOJI, ABC, PAD }

/**
 * n = সাধারণ অবস্থায় যা লেখে
 * s = Shift চাপলে যা লেখে
 * weight = কির প্রস্থ
 * hint = কির ডান-ওপরের কোণে ছোট করে দেখায়; কি চেপে ধরলে এটাই লেখা হয়
 */
class Key(
    val n: String,
    val s: String = n,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val hint: String? = null,
    val ed: String? = null   // কপি-পেস্ট মোডে এই কি যা করে: copy, cut, paste, selectAll
) {
    val isSpecial: Boolean
        get() = type == KeyType.SHIFT || type == KeyType.DEL || type == KeyType.SYM ||
                type == KeyType.LANG || type == KeyType.EMOJI || type == KeyType.ABC
}

object Layouts {

    fun modeName(m: Mode): String = when (m) {
        Mode.ENGLISH -> "English"
        Mode.AVRO -> "বাংলা (ফোনেটিক)"
        Mode.PROBHAT -> "প্রভাত"
        Mode.ARABIC -> "العربية"
    }

    private fun special(t: KeyType, w: Float = 1f) = Key("", "", t, w)
    private fun pad(w: Float) = Key("", "", KeyType.PAD, w)
    private fun edFor(c: Char): String? = when (c) {
        'c' -> "copy"
        'x' -> "cut"
        'v' -> "paste"
        'a' -> "selectAll"
        else -> null
    }

    private fun letters(chars: String) =
        chars.map { Key(it.toString(), it.uppercaseChar().toString(), ed = edFor(it)) }

    // বাংলা কি: সাধারণ, Shift দিলে (এটাই কোণের ছোট হিন্ট), কির প্রস্থ
    private fun k(n: String, s: String, w: Float = 1f) = Key(n, s, KeyType.CHAR, w, s)

    // একই, তবে কপি-পেস্ট মোডে কাজ করা কি (QWERTY-র a, x, c, v-এর জায়গায়)
    private fun ke(n: String, s: String, ed: String, w: Float = 1f) = Key(n, s, KeyType.CHAR, w, s, ed)

    // সংখ্যার কি: বাংলা সংখ্যা, Shift-এ চিহ্ন, চেপে ধরলে ইংরেজি সংখ্যা
    private fun num(bn: String, shifted: String, latin: String) = Key(bn, shifted, KeyType.CHAR, 1.2f, latin)

    private const val SYMS = "!@#\$%^&*()"
    private val latinNumberRow = "1234567890".mapIndexed { i, c ->
        Key(c.toString(), SYMS[i].toString(), KeyType.CHAR, 1f, SYMS[i].toString())
    }

    // ---------- English এবং ফোনেটিক (দুটোর কি একই QWERTY) ----------
    val latin: List<List<Key>> = listOf(
        latinNumberRow,
        letters("qwertyuiop"),
        listOf(pad(0.5f)) + letters("asdfghjkl") + listOf(pad(0.5f)),
        listOf(special(KeyType.SHIFT, 1.5f)) + letters("zxcvbnm") + listOf(special(KeyType.DEL, 1.5f)),
        listOf(
            special(KeyType.SYM, 1.3f), Key(","),
            special(KeyType.SPACE, 5.2f), Key("."), special(KeyType.ENTER, 1.6f)
        )
    )

    // ---------- প্রভাত (Ekushey-র প্রকাশিত Probhat ম্যাপ অনুযায়ী) ----------
    // প্রতি সারির মোট প্রস্থ ১২ ধরে সাজানো
    val probhat: List<List<Key>> = listOf(
        listOf(
            num("১", "!", "1"), num("২", "@", "2"), num("৩", "#", "3"), num("৪", "৳", "4"),
            num("৫", "%", "5"), num("৬", "^", "6"), num("৭", "ঞ", "7"), num("৮", "ৎ", "8"),
            num("৯", "(", "9"), num("০", ")", "0")
        ),
        listOf( // q w e r t y u i o p [ ]
            k("দ", "ধ"), k("ূ", "ঊ"), k("ী", "ঈ"), k("র", "\u09DC"), k("ট", "ঠ"),
            k("এ", "ঐ"), k("ু", "উ"), k("ি", "ই"), k("ও", "ঔ"), k("প", "ফ"),
            k("ে", "ৈ"), k("ো", "ৌ")
        ),
        listOf( // a s d f g h j k l
            pad(0.6f),
            ke("া", "অ", "selectAll", 1.2f), k("স", "ষ", 1.2f), k("ড", "ঢ", 1.2f), k("ত", "থ", 1.2f),
            k("গ", "ঘ", 1.2f), k("হ", "ঃ", 1.2f), k("জ", "ঝ", 1.2f), k("ক", "খ", 1.2f),
            k("ল", "ং", 1.2f),
            pad(0.6f)
        ),
        listOf( // z x c v b n m + ৃ ্
            special(KeyType.SHIFT, 1.5f),
            k("\u09DF", "য"), ke("শ", "\u09DD", "cut"), ke("চ", "ছ", "copy"), ke("আ", "ঋ", "paste"),
            k("ব", "ভ"), k("ন", "ণ"), k("ম", "ঙ"),
            Key("ৃ"), k("্", "ঁ"),
            special(KeyType.DEL, 1.5f)
        ),
        listOf(
            special(KeyType.SYM, 1.6f),
            Key(",", "?", KeyType.CHAR, 1.2f, "?"),
            special(KeyType.SPACE, 5.6f),
            Key("।", "!", KeyType.CHAR, 1.2f, "!"),
            special(KeyType.ENTER, 1.6f)
        )
    )

    // ---------- আরবি (মানক Arabic 101 লেআউট) ----------
    private fun ak(n: String, s: String, w: Float = 1f) = Key(n, s, KeyType.CHAR, w, s)

    val arabic: List<List<Key>> = listOf(
        listOf(
            num("١", "!", "1"), num("٢", "@", "2"), num("٣", "#", "3"), num("٤", "\$", "4"),
            num("٥", "%", "5"), num("٦", "^", "6"), num("٧", "&", "7"), num("٨", "*", "8"),
            num("٩", "(", "9"), num("٠", ")", "0")
        ),
        listOf( // q w e r t y u i o p [ ]
            ak("ض", "\u064E"), ak("ص", "\u064B"), ak("ث", "\u064F"), ak("ق", "\u064C"),
            ak("ف", "لإ"), ak("غ", "إ"), ak("ع", "‘"), ak("ه", "÷"), ak("خ", "×"),
            ak("ح", "؛"), ak("ج", "<"), ak("د", ">")
        ),
        listOf( // a s d f g h j k l ; '
            pad(0.5f),
            ak("ش", "\u0650"), ak("س", "\u064D"), ak("ي", "]"), ak("ب", "["), ak("ل", "لأ"),
            ak("ا", "أ"), ak("ت", "ـ"), ak("ن", "،"), ak("م", "/"), ak("ك", ":"), ak("ط", "\""),
            pad(0.5f)
        ),
        listOf( // z x c v b n m , . /
            special(KeyType.SHIFT, 1.5f),
            ak("ئ", "~", 0.9f), ak("ء", "\u0652", 0.9f), ak("ؤ", "}", 0.9f), ak("ر", "{", 0.9f),
            ak("لا", "لآ", 0.9f), ak("ى", "آ", 0.9f), ak("ة", "’", 0.9f), ak("و", ",", 0.9f),
            ak("ز", ".", 0.9f), ak("ظ", "؟", 0.9f),
            special(KeyType.DEL, 1.5f)
        ),
        listOf(
            special(KeyType.SYM, 1.6f),
            Key("،", "؟", KeyType.CHAR, 1.2f, "؟"),
            special(KeyType.SPACE, 5.6f),
            Key(".", "!", KeyType.CHAR, 1.2f, "!"),
            special(KeyType.ENTER, 1.6f)
        )
    )

    // ---------- চিহ্নের পাতা (?123) ----------
    val symbolPage: List<List<Key>> = listOf(
        "1234567890".map { Key(it.toString()) },
        "@#\$_&-+()/".map { Key(it.toString()) },
        "*\"':;!?`^%".map { Key(it.toString()) },
        "<>~=[]{}".map { Key(it.toString()) } + listOf(special(KeyType.DEL, 1.5f)),
        listOf(
            special(KeyType.SYM, 1.5f), Key(","), special(KeyType.SPACE, 5f),
            Key("."), special(KeyType.ENTER, 1.6f)
        )
    )
}

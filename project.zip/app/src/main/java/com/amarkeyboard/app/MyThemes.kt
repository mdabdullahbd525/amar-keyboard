package com.amarkeyboard.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** ইউজারের নিজের সেভ করা থিম (নাম + বেস থিম + বেছে নেওয়া রঙগুলো) */
object MyThemes {
    class Saved(val name: String, val themeId: String, val map: Map<String, Int>)

    fun all(p: SharedPreferences): List<Saved> {
        val out = ArrayList<Saved>()
        try {
            val a = JSONArray(p.getString("myThemes", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val m = HashMap<String, Int>()
                val mo = o.optJSONObject("map")
                if (mo != null) {
                    val it = mo.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        m[k] = mo.getInt(k)
                    }
                }
                out.add(Saved(o.getString("name"), o.optString("theme", Themes.DEFAULT_ID), m))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(p: SharedPreferences, list: List<Saved>) {
        val a = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("name", s.name)
            o.put("theme", s.themeId)
            val mo = JSONObject()
            for ((k, v) in s.map) mo.put(k, v)
            o.put("map", mo)
            a.put(o)
        }
        p.edit().putString("myThemes", a.toString()).apply()
    }

    /** এখনকার থিম ও রঙগুলো এই নামে সেভ করে */
    fun saveCurrent(p: SharedPreferences, name: String) {
        val cur = Saved(name, p.getString("theme", Themes.DEFAULT_ID) ?: Themes.DEFAULT_ID, KeyStyle.fromPrefs(p))
        save(p, all(p).filter { it.name != name } + cur)
    }

    fun delete(p: SharedPreferences, name: String) {
        save(p, all(p).filter { it.name != name })
    }

    fun apply(p: SharedPreferences, s: Saved) {
        val e = p.edit()
        e.putString("theme", s.themeId)
        KeyStyle.writePrefs(e, s.map)
        e.apply()
    }

    fun style(s: Saved): Style = KeyStyle.resolveMap(s.map, Themes.byId(s.themeId), false)
}

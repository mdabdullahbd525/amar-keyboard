package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** থিম গ্যালারি: বর্তমান থিম, নিজের সেভ করা থিম, তৈরি করা বাটন, রেডিমেড কালার থিম */
class ThemeActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var sv: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun currentThemeId(): String = prefs.getString("theme", Themes.DEFAULT_ID) ?: Themes.DEFAULT_ID

    private fun render() {
        val keepY = sv?.scrollY ?: 0
        val bmp = BgImage.load(this)
        val dim = prefs.getInt("bgDim", 35)
        val st = KeyStyle.resolve(prefs, Themes.byId(currentThemeId()), bmp != null)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        val store = Ui.text(this, "🖌", 22f, Ui.ink)
        store.setOnClickListener { startActivity(android.content.Intent(this, ThemeEditorActivity::class.java)) }
        root.addView(Ui.appBar(this, "থিম", store))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 28))

        // বর্তমান থিম
        col.addView(heading("বর্তমান থিম"))
        col.addView(Ui.miniKeyboard(this, st, bmp, dim, true))
        val nm = Themes.byId(currentThemeId()).name + (if (KeyStyle.fromPrefs(prefs).isNotEmpty() || bmp != null) " (কাস্টম)" else "")
        val ntv = Ui.text(this, nm, 13f, Ui.sub)
        ntv.gravity = Gravity.CENTER
        ntv.setPadding(0, Ui.dp(this, 6), 0, 0)
        col.addView(ntv, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // তৈরি করা থিমগুলো
        col.addView(heading("তৈরি করা থিমগুলো"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val plus = Ui.text(this, "+", 34f, Ui.primary, true)
        plus.gravity = Gravity.CENTER
        plus.background = Ui.round(this, Ui.chipBg, 12)
        plus.setOnClickListener { startActivity(android.content.Intent(this, ThemeEditorActivity::class.java)) }
        val plusBox = LinearLayout(this)
        plusBox.orientation = LinearLayout.VERTICAL
        plusBox.addView(plus, LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.dp(this, 110)))
        val pt = Ui.text(this, "থিম তৈরি করুন", 12f, Ui.sub)
        pt.gravity = Gravity.CENTER
        plusBox.addView(pt, LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.WRAP))
        row.addView(plusBox)
        for (s in MyThemes.all(prefs)) {
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.setPadding(Ui.dp(this, 10), 0, 0, 0)
            val pv = Ui.miniKeyboard(this, MyThemes.style(s), null, 0, false)
            pv.setOnClickListener { applySaved(s) }
            tile.addView(pv, LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.WRAP))
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            val n = Ui.text(this, s.name, 12f, Ui.ink)
            n.maxLines = 1
            line.addView(n, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            val del = Ui.text(this, "🗑", 14f, Ui.sub)
            del.setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("\"${s.name}\" থিমটি মুছবেন?")
                    .setPositiveButton("মুছুন") { _, _ ->
                        MyThemes.delete(prefs, s.name)
                        render()
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }
            line.addView(del)
            tile.addView(line, LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.WRAP))
            row.addView(tile)
        }
        hs.addView(row)
        col.addView(hs)

        // কালার থিম
        col.addView(heading("কালার থিম"))
        val cur = currentThemeId()
        val noCustom = KeyStyle.fromPrefs(prefs).isEmpty() && bmp == null
        var rowL: LinearLayout? = null
        Themes.all.forEachIndexed { i, t ->
            if (i % 2 == 0) {
                rowL = LinearLayout(this)
                rowL!!.orientation = LinearLayout.HORIZONTAL
                col.addView(rowL)
            }
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6))
            val selected = t.id == cur && noCustom
            val pv = Ui.miniKeyboard(this, KeyStyle.forTheme(t), null, 0, false)
            val frame = LinearLayout(this)
            frame.setPadding(Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3))
            frame.background = Ui.round(this, Color.TRANSPARENT, 14, if (selected) Ui.primary else Color.TRANSPARENT, 3)
            frame.addView(pv, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            tile.addView(frame)
            val n = Ui.text(this, (if (selected) "✓ " else "") + t.name, 13f, if (selected) Ui.primary else Ui.ink, selected)
            n.gravity = Gravity.CENTER
            tile.addView(n, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            tile.setOnClickListener { applyBuiltIn(t) }
            rowL!!.addView(tile, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        root.addView(s, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun heading(t: String): TextView {
        val h = Ui.text(this, t, 16f, Ui.ink, true)
        h.setPadding(0, Ui.dp(this, 20), 0, Ui.dp(this, 8))
        return h
    }

    private fun applyBuiltIn(t: KbTheme) {
        val doApply = {
            val e = prefs.edit()
            KeyStyle.clearPrefs(e)
            e.putString("theme", t.id)
            e.apply()
            Ui.toast(this, "থিম প্রয়োগ হয়েছে")
            render()
        }
        if (BgImage.file(this).exists()) {
            AlertDialog.Builder(this)
                .setMessage("কিবোর্ডে এখন ব্যাকগ্রাউন্ড ছবি আছে। ছবিটা সরিয়ে এই থিম প্রয়োগ করবেন?")
                .setPositiveButton("সরিয়ে প্রয়োগ করুন") { _, _ ->
                    BgImage.remove(this)
                    doApply()
                }
                .setNegativeButton("বাতিল", null)
                .show()
        } else doApply()
    }

    private fun applySaved(s: MyThemes.Saved) {
        val doApply = {
            MyThemes.apply(prefs, s)
            Ui.toast(this, "থিম প্রয়োগ হয়েছে")
            render()
        }
        if (BgImage.file(this).exists()) {
            AlertDialog.Builder(this)
                .setMessage("কিবোর্ডে এখন ব্যাকগ্রাউন্ড ছবি আছে। ছবিটা সরিয়ে এই থিম প্রয়োগ করবেন?")
                .setPositiveButton("সরিয়ে প্রয়োগ করুন") { _, _ ->
                    BgImage.remove(this)
                    doApply()
                }
                .setNegativeButton("বাতিল", null)
                .show()
        } else doApply()
    }
}

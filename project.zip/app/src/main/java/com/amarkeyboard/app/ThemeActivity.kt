package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** থিম ও কি-এর রঙ: লাইভ প্রিভিউ, কী ব্যাকগ্রাউন্ড সুইচ, রঙের প্যালেট, কি-এর স্বচ্ছতা */
class ThemeActivity : Activity() {

    private val prefs: SharedPreferences by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private var sv: ScrollView? = null

    private val palette = listOf(
        "#FFFFFF", "#F5F5F5", "#E0E0E0", "#9E9E9E", "#424242", "#000000",
        "#FFCDD2", "#F44336", "#B71C1C", "#FFE0B2", "#FF9800", "#E65100",
        "#FFF9C4", "#FFEB3B", "#827717", "#C8E6C9", "#4CAF50", "#1B5E20",
        "#B3E5FC", "#03A9F4", "#01579B", "#E1BEE7", "#9C27B0", "#4A148C",
        "#B2DFDB", "#009688", "#004D40", "#F8BBD0", "#E91E63", "#880E4F"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun theme(): KbTheme = Themes.byId(prefs.getString("theme", "light") ?: "light")

    private fun photo(): Bitmap? {
        val f = File(filesDir, "bg.jpg")
        return if (f.exists()) try { BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null } else null
    }

    private fun render() {
        val keepY = sv?.scrollY ?: 0
        val bmp = photo()
        val st = KeyStyle.resolve(prefs, theme(), bmp != null)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(20), dp(18), dp(32))

        col.addView(text("থিম ও কি-এর রঙ", 24f, true))
        col.addView(preview(st, bmp))

        // ---- থিম ----
        col.addView(heading("থিম"))
        val circles = LinearLayout(this)
        circles.orientation = LinearLayout.HORIZONTAL
        val cur = prefs.getString("theme", "light")
        for (t in Themes.all) {
            val c = TextView(this)
            c.text = if (t.id == cur) "✓" else ""
            c.gravity = Gravity.CENTER
            c.setTextColor(t.text)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(t.bg)
            g.setStroke(dp(if (t.id == cur) 3 else 1), t.accent)
            c.background = g
            c.setOnClickListener {
                prefs.edit().putString("theme", t.id).apply()
                render()
            }
            val lp = LinearLayout.LayoutParams(dp(44), dp(44))
            lp.rightMargin = dp(10)
            circles.addView(c, lp)
        }
        col.addView(circles)

        // ---- কী ব্যাকগ্রাউন্ড ----
        col.addView(heading("কী ব্যাকগ্রাউন্ড"))
        val boxRow = LinearLayout(this)
        boxRow.orientation = LinearLayout.HORIZONTAL
        boxRow.gravity = Gravity.CENTER_VERTICAL
        val boxTxt = LinearLayout(this)
        boxTxt.orientation = LinearLayout.VERTICAL
        boxTxt.addView(text("কী ব্যাকগ্রাউন্ড", 16f, false))
        val sub = text("বন্ধ করলে কিগুলোর বাক্স থাকে না, শুধু অক্ষর দেখায়। ছবির ব্যাকগ্রাউন্ডে সুন্দর লাগে", 13f, false)
        sub.alpha = 0.65f
        boxTxt.addView(sub)
        boxRow.addView(boxTxt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean("keyBg", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("keyBg", on).apply()
            render()
        }
        boxRow.addView(sw)
        col.addView(boxRow)

        // ---- কি-এর রঙ ----
        col.addView(heading("কি-এর রঙ (প্যালেট থেকে বেছে নিন)"))
        col.addView(colorRow("সাধারণ কি-এর রঙ", "ckKey", KeyStyle.opaque(st.key)))
        col.addView(colorRow("বিশেষ কি-এর রঙ (Shift, ⌫, ?123)", "ckSpecial", KeyStyle.opaque(st.special)))
        col.addView(colorRow("এন্টার কি-এর রঙ", "ckEnter", st.enter))
        col.addView(colorRow("কি-এর লেখার রঙ", "ckText", st.text))
        col.addView(colorRow("কিবোর্ডের পেছনের রঙ (ছবি না থাকলে)", "ckBg", st.bg))

        // ---- স্বচ্ছতা ----
        col.addView(heading("কি-এর স্বচ্ছতা"))
        val alphaNow = if (prefs.contains("keyAlpha")) prefs.getInt("keyAlpha", 100).toString() + "%" else "স্বয়ংক্রিয়"
        col.addView(row("কি কতটা স্বচ্ছ হবে", alphaNow) { showAlphaDialog() })

        // ---- রিসেট ----
        val reset = TextView(this)
        reset.text = "সব রঙ ডিফল্টে ফেরান"
        reset.gravity = Gravity.CENTER
        reset.textSize = 15f
        reset.setTextColor(Color.parseColor("#B71C1C"))
        reset.setPadding(0, dp(24), 0, dp(8))
        reset.setOnClickListener {
            val e = prefs.edit()
            for (k in listOf("ckKey", "ckSpecial", "ckEnter", "ckText", "ckBg", "keyAlpha")) e.remove(k)
            e.putBoolean("keyBg", true).apply()
            Toast.makeText(this, "রঙ ডিফল্টে ফিরেছে", Toast.LENGTH_SHORT).show()
            render()
        }
        col.addView(reset)

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, keepY) }
    }

    // ---- ছোট কিবোর্ড প্রিভিউ (আসল কিবোর্ডের মতোই রঙের হিসাব) ----
    private fun preview(st: Style, bmp: Bitmap?): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(6), dp(4), dp(6))
        if (bmp != null) box.background = BgDrawable(bmp, prefs.getInt("bgDim", 35) * 255 / 100)
        else box.setBackgroundColor(st.bg)

        val rows = listOf(
            listOf("q", "w", "e", "r", "t", "y", "u", "i"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k"),
            listOf("⇧", "z", "x", "c", "v", "b", "⌫", "↵")
        )
        for (r in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in r) {
                val t = TextView(this)
                t.text = k
                t.gravity = Gravity.CENTER
                t.textSize = 18f
                val special = k == "⇧" || k == "⌫"
                val enter = k == "↵"
                t.setTextColor(if (enter && st.box) Color.WHITE else st.text)
                val g = GradientDrawable()
                g.cornerRadius = dp(7).toFloat()
                g.setColor(
                    when {
                        !st.box -> Color.TRANSPARENT
                        enter -> st.enter
                        special -> st.special
                        else -> st.key
                    }
                )
                t.background = g
                val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                lp.setMargins(dp(2), dp(3), dp(2), dp(3))
                line.addView(t, lp)
            }
            box.addView(line)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        box.layoutParams = lp
        return box
    }

    private fun colorRow(title: String, key: String, shown: Int): View {
        val isCustom = prefs.contains(key)
        val swatch = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(shown)
        g.setStroke(dp(1), Color.GRAY)
        swatch.background = g
        val r = row(title, if (isCustom) "আপনার বেছে নেওয়া" else "ডিফল্ট") { showColorDialog(title, key) }
        r.addView(swatch, LinearLayout.LayoutParams(dp(32), dp(32)))
        return r
    }

    private fun row(title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(text(title, 16f, false))
        val s = text(sub, 13f, false)
        s.alpha = 0.65f
        tx.addView(s)
        r.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.setOnClickListener { onClick() }
        return r
    }

    private fun showColorDialog(title: String, key: String) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(4))

        var dlg: AlertDialog? = null
        for (chunk in palette.chunked(6)) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (hex in chunk) {
                val c = View(this)
                val g = GradientDrawable()
                g.cornerRadius = dp(8).toFloat()
                g.setColor(Color.parseColor(hex))
                g.setStroke(dp(1), Color.GRAY)
                c.background = g
                c.setOnClickListener {
                    prefs.edit().putInt(key, Color.parseColor(hex)).apply()
                    dlg?.dismiss()
                    render()
                }
                val lp = LinearLayout.LayoutParams(0, dp(42), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                line.addView(c, lp)
            }
            col.addView(line)
        }
        val hex = EditText(this)
        hex.hint = "নিজের রঙের কোড, যেমন #FF5722"
        col.addView(hex)

        val sc = ScrollView(this)
        sc.addView(col)
        dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sc)
            .setPositiveButton("কোড থেকে নিন") { _, _ ->
                try {
                    var t = hex.text.toString().trim()
                    if (!t.startsWith("#")) t = "#$t"
                    prefs.edit().putInt(key, Color.parseColor(t)).apply()
                    render()
                } catch (e: Exception) {
                    Toast.makeText(this, "রঙের কোডটা ঠিক নেই (যেমন #FF5722)", Toast.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("ডিফল্ট") { _, _ ->
                prefs.edit().remove(key).apply()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showAlphaDialog() {
        val cur = if (prefs.contains("keyAlpha")) prefs.getInt("keyAlpha", 100) else 100
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(8))
        val value = text("$cur%", 18f, false)
        val sb = SeekBar(this)
        sb.max = 18
        sb.progress = (cur - 10) / 5
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "${10 + p * 5}%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(value)
        box.addView(sb)
        AlertDialog.Builder(this)
            .setTitle("কি-এর স্বচ্ছতা")
            .setView(box)
            .setPositiveButton("ঠিক আছে") { _, _ ->
                prefs.edit().putInt("keyAlpha", 10 + sb.progress * 5).apply()
                render()
            }
            .setNeutralButton("স্বয়ংক্রিয়") { _, _ ->
                prefs.edit().remove("keyAlpha").apply()
                render()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun text(t: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun heading(t: String) = text(t, 17f, true).apply { setPadding(0, dp(22), 0, dp(8)) }
}

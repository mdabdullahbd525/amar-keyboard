package com.amarkeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ক্লিপবোর্ড পাতা: পিন করা ও সাম্প্রতিক লেখা। চাপলে কপি হয়, 📌 দিয়ে পিন, 🗑 দিয়ে মোছা */
class ClipboardActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private lateinit var store: ClipStore
    private var sv: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.primaryDark
        store = ClipStore(prefs)
        render()
    }

    override fun onResume() {
        super.onResume()
        store.load()
        render()
    }

    private fun render() {
        val keepY = sv?.scrollY ?: 0
        store.load()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bg)
        val plus = Ui.text(this, "＋", 26f, Ui.primary, true)
        plus.setOnClickListener { addDialog() }
        root.addView(Ui.appBar(this, "ক্লিপবোর্ড", plus))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 28))

        val list = store.list()
        val pinned = list.filter { it.pinned }
        val recent = list.filter { !it.pinned }

        if (list.isEmpty()) {
            val e = Ui.text(this, "এখনো কিছু কপি করা হয়নি।\nকোনো লেখা কপি বা কাট করলে এখানে জমা হবে। ＋ চেপে নিজেও লেখা যোগ করতে পারেন।", 15f, Ui.sub)
            e.gravity = Gravity.CENTER
            e.setPadding(Ui.dp(this, 12), Ui.dp(this, 60), Ui.dp(this, 12), 0)
            col.addView(e)
        }
        if (pinned.isNotEmpty()) {
            col.addView(heading("পিন করা"))
            for (c in pinned) col.addView(clipCard(c))
        }
        if (recent.isNotEmpty()) {
            col.addView(heading("সাম্প্রতিক"))
            for (c in recent) col.addView(clipCard(c))
            val clear = Ui.text(this, "সাম্প্রতিক সব মুছুন (পিন করা থাকবে)", 14f, android.graphics.Color.parseColor("#B71C1C"), true)
            clear.gravity = Gravity.CENTER
            clear.setPadding(0, Ui.dp(this, 20), 0, 0)
            clear.setOnClickListener {
                store.clearUnpinned()
                render()
            }
            col.addView(clear)
        }

        val s = ScrollView(this)
        s.addView(col)
        sv = s
        root.addView(s, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun heading(t: String) = Ui.text(this, t, 13f, Ui.sub, true).also {
        it.setPadding(Ui.dp(this, 4), Ui.dp(this, 14), 0, Ui.dp(this, 4))
    }

    private fun clipCard(c: ClipStore.Clip): LinearLayout {
        val card = Ui.card(this)
        val body = Ui.text(this, c.text, 15f, Ui.ink)
        body.maxLines = 5
        body.ellipsize = TextUtils.TruncateAt.END
        card.addView(body)

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.setPadding(0, Ui.dp(this, 8), 0, 0)
        val whenTxt = if (c.time > 0) SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(c.time)) else ""
        foot.addView(Ui.text(this, whenTxt, 12f, Ui.sub), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        val pin = Ui.text(this, "📌", 20f, Ui.ink)
        pin.alpha = if (c.pinned) 1f else 0.3f
        pin.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        pin.setOnClickListener {
            store.togglePin(c)
            render()
        }
        foot.addView(pin)
        val del = Ui.text(this, "🗑", 18f, Ui.ink)
        del.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4))
        del.setOnClickListener {
            store.delete(c)
            render()
        }
        foot.addView(del)
        card.addView(foot)

        card.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", c.text))
            Ui.toast(this, "কপি হয়েছে")
        }
        val lp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        lp.setMargins(0, Ui.dp(this, 4), 0, Ui.dp(this, 4))
        card.layoutParams = lp
        return card
    }

    private fun addDialog() {
        val et = EditText(this)
        et.hint = "যে লেখা রেখে দিতে চান"
        et.minLines = 3
        et.gravity = Gravity.TOP
        val box = LinearLayout(this)
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), 0)
        box.addView(et, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        AlertDialog.Builder(this)
            .setTitle("নতুন লেখা যোগ করুন")
            .setView(box)
            .setPositiveButton("পিন করে রাখুন") { _, _ ->
                val t = et.text.toString()
                if (t.isBlank()) Ui.toast(this, "লেখা ফাঁকা রাখা যাবে না")
                else {
                    store.add(t, true)
                    render()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}

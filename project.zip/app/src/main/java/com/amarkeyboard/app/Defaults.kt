package com.amarkeyboard.app

import android.content.SharedPreferences

/** সব সেটিংসের ডিফল্ট মান এক জায়গায়। সার্ভিস আর সেটিংস স্ক্রিন দুটোই এখান থেকে পড়ে। */
object Defaults {
    val bool: Map<String, Boolean> = mapOf(
        "autoCap" to true,
        "dblSpaceDot" to false,
        "dblSpaceTab" to false,
        "vibrate" to false,
        "sound" to false,
        "popup" to true,
        "emojiBtn" to true,
        "globeBtn" to true,
        "otherKb" to false,
        "volCursor" to false,
        "volCursorMusicOff" to false,
        "autoEdit" to true,
        "clipHistory" to true,
        "incognito" to false,
        "calcSuggest" to true,
        "numRow" to true,
        "bigNumRow" to true,
        "hideHints" to false,
        "heightCustom" to true,
        "split" to true,
        "foldable" to false,
        "alwaysEnter" to true,
        "showSuggest" to true,
        "typedFirst" to true,
        "personal" to true,
        "nextWord" to true
    )

    val int: Map<String, Int> = mapOf(
        "heightP" to 85,
        "heightL" to 100,
        "ohP" to 85,
        "ohL" to 40,
        "popupMs" to 0,
        "vibMs" to 0,
        "soundVol" to 0,
        "longPressMs" to 300,
        "spaceDelay" to 1000,
        "spaceSpeed" to 150,
        "dateFmt" to 0,
        "timeFmt" to 0
    )

    fun b(p: SharedPreferences, k: String): Boolean = p.getBoolean(k, bool[k] ?: false)
    fun i(p: SharedPreferences, k: String): Int = p.getInt(k, int[k] ?: 0)
}

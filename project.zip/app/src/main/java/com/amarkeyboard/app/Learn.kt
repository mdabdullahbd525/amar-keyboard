package com.amarkeyboard.app

import java.io.File

/** ইউজারের টাইপ করা শব্দ ও পরের-শব্দের জোড়া শেখে। সব ডেটা ফোনের ভেতরেই থাকে, কোথাও পাঠানো হয় না। */
class Learn(private val file: File) {

    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, HashMap<String, Int>>()
    private var dirty = false

    fun load() {
        uni.clear()
        bi.clear()
        try {
            if (!file.exists()) return
            file.forEachLine { line ->
                val p = line.split("\t")
                if (p.size == 3 && p[0] == "U") {
                    uni[p[1]] = p[2].toIntOrNull() ?: 1
                } else if (p.size == 4 && p[0] == "B") {
                    bi.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toIntOrNull() ?: 1
                }
            }
        } catch (e: Exception) {
        }
    }

    fun add(word: String, prev: String?) {
        uni[word] = (uni[word] ?: 0) + 1
        if (prev != null) {
            val m = bi.getOrPut(prev) { HashMap() }
            m[word] = (m[word] ?: 0) + 1
        }
        dirty = true
    }

    fun complete(prefix: String, max: Int): List<String> =
        uni.entries
            .filter { it.key.startsWith(prefix) && it.key != prefix }
            .sortedByDescending { it.value }
            .take(max)
            .map { it.key }

    fun next(prev: String, max: Int): List<String> =
        (bi[prev] ?: return emptyList()).entries
            .sortedByDescending { it.value }
            .take(max)
            .map { it.key }

    fun clear() {
        uni.clear()
        bi.clear()
        dirty = false
        try { file.delete() } catch (e: Exception) { }
    }

    fun save() {
        if (!dirty) return
        try {
            if (uni.size > 3000) {
                val it = uni.entries.iterator()
                while (it.hasNext() && uni.size > 2500) {
                    if (it.next().value <= 1) it.remove()
                }
            }
            val sb = StringBuilder()
            for ((w, c) in uni) sb.append("U\t").append(w).append('\t').append(c).append('\n')
            for ((a, m) in bi) for ((b, c) in m) {
                if (uni.containsKey(a) && uni.containsKey(b)) {
                    sb.append("B\t").append(a).append('\t').append(b).append('\t').append(c).append('\n')
                }
            }
            file.writeText(sb.toString())
            dirty = false
        } catch (e: Exception) {
        }
    }
}

package com.amarkeyboard.app

import android.content.SharedPreferences

/** কোন কোন লেআউট চালু আছে (সর্বোচ্চ তিনটি) */
object LayoutPrefs {
    val all = listOf(Mode.ENGLISH, Mode.AVRO, Mode.PROBHAT, Mode.ARABIC)
    const val MAX = 3

    fun enabled(p: SharedPreferences): List<Mode> {
        val s = p.getString("enabledModes", null)
            ?: return listOf(Mode.ENGLISH, Mode.AVRO, Mode.PROBHAT)
        val l = s.split(",").mapNotNull {
            try { Mode.valueOf(it) } catch (e: Exception) { null }
        }
        return if (l.isEmpty()) listOf(Mode.ENGLISH) else all.filter { it in l }
    }

    fun save(p: SharedPreferences, l: List<Mode>) {
        p.edit().putString("enabledModes", all.filter { it in l }.joinToString(",") { it.name }).apply()
    }

    fun summary(p: SharedPreferences): String =
        enabled(p).joinToString(", ") { Layouts.modeName(it) }
}

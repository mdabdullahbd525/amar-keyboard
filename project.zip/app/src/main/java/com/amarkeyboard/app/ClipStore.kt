package com.amarkeyboard.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** কপি/কাট করা লেখার তালিকা। পিন করা লেখা কখনো নিজে থেকে মোছা হয় না। সব ফোনের ভেতরেই থাকে। */
class ClipStore(private val prefs: SharedPreferences) {

    class Clip(val text: String, var pinned: Boolean)

    private val items = ArrayList<Clip>()
    private val maxUnpinned = 30

    fun load() {
        items.clear()
        try {
            val arr = JSONArray(prefs.getString("clips", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(Clip(o.getString("t"), o.optBoolean("p", false)))
            }
        } catch (e: Exception) {
        }
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (c in items) {
                val o = JSONObject()
                o.put("t", c.text)
                o.put("p", c.pinned)
                arr.put(o)
            }
            prefs.edit().putString("clips", arr.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun add(text: String) {
        val t = if (text.length > 5000) text.substring(0, 5000) else text
        if (t.isBlank()) return
        val at = items.indexOfFirst { it.text == t }
        if (at >= 0) {
            val c = items.removeAt(at)
            items.add(0, c)
        } else {
            items.add(0, Clip(t, false))
        }
        while (items.count { !it.pinned } > maxUnpinned) {
            val idx = items.indexOfLast { !it.pinned }
            if (idx < 0) break
            items.removeAt(idx)
        }
        save()
    }

    /** পিন করা আগে, তারপর নতুন থেকে পুরোনো */
    fun list(): List<Clip> = items.filter { it.pinned } + items.filter { !it.pinned }

    fun togglePin(c: Clip) {
        c.pinned = !c.pinned
        save()
    }

    fun delete(c: Clip) {
        items.remove(c)
        save()
    }

    fun clearUnpinned() {
        items.removeAll { !it.pinned }
        save()
    }
}

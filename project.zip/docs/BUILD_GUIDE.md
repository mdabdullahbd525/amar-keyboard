# বিল্ড গাইড

পুরো ধাপ (ফোন থেকে, GitHub দিয়ে) আলাদা `README_BN.md` ফাইলে আছে।
সংক্ষেপে: GitHub রিপোজিটরিতে `project.zip` আপলোড করুন, `.github/workflows/build.yml` যোগ করুন, Actions ট্যাবে বিল্ড শেষ হলে `AmarKeyboard-apk` নামান, তারপর APK ইনস্টল করুন।
